﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //---Monsters---
            // A (6)
            comboBox1.Items.Add("Aarakocra");
            comboBox1.Items.Add("Aboleth");
            comboBox1.Items.Add("Angels");
            comboBox1.Items.Add("Animated Objects");
            comboBox1.Items.Add("Ankheg");
            comboBox1.Items.Add("Azer");
            // B (8)
            comboBox1.Items.Add("Banshee");
            comboBox1.Items.Add("Basilisk");
            comboBox1.Items.Add("Behir");
            comboBox1.Items.Add("Beholders");
            comboBox1.Items.Add("Blights");
            comboBox1.Items.Add("Bugbears");
            comboBox1.Items.Add("Bulette");
            comboBox1.Items.Add("Bullywug");
            // C (10)
            comboBox1.Items.Add("Cambion");
            comboBox1.Items.Add("Carrion Crawler");
            comboBox1.Items.Add("Centaur");
            comboBox1.Items.Add("Chimera");
            comboBox1.Items.Add("Chuul");
            comboBox1.Items.Add("Cloaker");
            comboBox1.Items.Add("Cockatrice");
            comboBox1.Items.Add("Couatl");
            comboBox1.Items.Add("Crawling Claw");
            comboBox1.Items.Add("Cyclops");
            // D (15)
            comboBox1.Items.Add("Darkmantle");
            comboBox1.Items.Add("Death Knight");
            comboBox1.Items.Add("Demlich");
            comboBox1.Items.Add("Demons");
            comboBox1.Items.Add("Devils");
            comboBox1.Items.Add("Dinosaurs");
            comboBox1.Items.Add("Displacer Beast");
            comboBox1.Items.Add("Doppelganger");
            comboBox1.Items.Add("Dracolich");
            comboBox1.Items.Add("Dragon, Shadow");
            comboBox1.Items.Add("Dragons");
            comboBox1.Items.Add("Dragon Turtle");
            comboBox1.Items.Add("Drider");
            comboBox1.Items.Add("Dryad");
            comboBox1.Items.Add("Duergar");
            // E (5)
            comboBox1.Items.Add("Elementals");
            comboBox1.Items.Add("Elves: Drow");
            comboBox1.Items.Add("Empyrean");
            comboBox1.Items.Add("Ettercap");
            comboBox1.Items.Add("Ettin");
            // F (5)
            comboBox1.Items.Add("Faerie Dragon");
            comboBox1.Items.Add("Flameskull");
            comboBox1.Items.Add("Flumph");
            comboBox1.Items.Add("Fomorian");
            comboBox1.Items.Add("Fungi");
            // G (17)
            comboBox1.Items.Add("Galeb Duhr");
            comboBox1.Items.Add("Gargoyle");
            comboBox1.Items.Add("Genies");
            comboBox1.Items.Add("Ghost");
            comboBox1.Items.Add("Ghouls");
            comboBox1.Items.Add("Giants");
            comboBox1.Items.Add("Gibbering Mouther");
            comboBox1.Items.Add("Gith");
            comboBox1.Items.Add("Gnolls");
            comboBox1.Items.Add("Gnome, Deep");
            comboBox1.Items.Add("Goblins");
            comboBox1.Items.Add("Golems");
            comboBox1.Items.Add("Gorgon");
            comboBox1.Items.Add("Grell");
            comboBox1.Items.Add("Grick");
            comboBox1.Items.Add("Griffon");
            comboBox1.Items.Add("Grimlock");
            // H (10)
            comboBox1.Items.Add("Hags");
            comboBox1.Items.Add("Half-Dragon");
            comboBox1.Items.Add("Harpy");
            comboBox1.Items.Add("Hell Hound");
            comboBox1.Items.Add("Helmed Horror");
            comboBox1.Items.Add("Hippogriff");
            comboBox1.Items.Add("Hobgoblins");
            comboBox1.Items.Add("Hounculus");
            comboBox1.Items.Add("Hook Horror");
            comboBox1.Items.Add("Hydra");
            // I (2)
            comboBox1.Items.Add("Intellect Devourer");
            comboBox1.Items.Add("Invisible Stalker");
            // J (1)
            comboBox1.Items.Add("Jackalwere");
            // K (4)
            comboBox1.Items.Add("Kenku");
            comboBox1.Items.Add("Kobolds");
            comboBox1.Items.Add("Kraken");
            comboBox1.Items.Add("Kuo-toa");
            // L (4)
            comboBox1.Items.Add("Lamia");
            comboBox1.Items.Add("Lich");
            comboBox1.Items.Add("Lizardfolk");
            comboBox1.Items.Add("Lycanthropes");
            // M (12)
            comboBox1.Items.Add("Magmin");
            comboBox1.Items.Add("Manticore");
            comboBox1.Items.Add("Medusa");
            comboBox1.Items.Add("Mephits");
            comboBox1.Items.Add("Merfolk");
            comboBox1.Items.Add("Merrow");
            comboBox1.Items.Add("Mimic");
            comboBox1.Items.Add("Mind Flayer");
            comboBox1.Items.Add("Minotaur");
            comboBox1.Items.Add("Modrons");
            comboBox1.Items.Add("Mummies");
            comboBox1.Items.Add("Myconids");
            // N (3)
            comboBox1.Items.Add("Nagas");
            comboBox1.Items.Add("Nightmare");
            comboBox1.Items.Add("Nothic");
            // O (6)
            comboBox1.Items.Add("Ogres");
            comboBox1.Items.Add("Oni");
            comboBox1.Items.Add("Oozes");
            comboBox1.Items.Add("Orcs");
            comboBox1.Items.Add("Otyugh");
            comboBox1.Items.Add("Owlbear");
            // P (6)
            comboBox1.Items.Add("Pegasus");
            comboBox1.Items.Add("Peryton");
            comboBox1.Items.Add("Piercer");
            comboBox1.Items.Add("Pixie");
            comboBox1.Items.Add("Pseudodragon");
            comboBox1.Items.Add("Purple Worm");
            // Q (1)
            comboBox1.Items.Add("Quaggoth");
            // R (6)
            comboBox1.Items.Add("Rakshsa");
            comboBox1.Items.Add("Remorhazes");
            comboBox1.Items.Add("Revenant");
            comboBox1.Items.Add("Roc");
            comboBox1.Items.Add("Roper");
            comboBox1.Items.Add("Rust Monster");
            // S (14)
            comboBox1.Items.Add("Sahuagin");
            comboBox1.Items.Add("Salamanders");
            comboBox1.Items.Add("Satyr");
            comboBox1.Items.Add("Scarecrow");
            comboBox1.Items.Add("Shadow");
            comboBox1.Items.Add("Shambling Mound");
            comboBox1.Items.Add("Shield Guardian");
            comboBox1.Items.Add("Skeletons");
            comboBox1.Items.Add("Slaadi");
            comboBox1.Items.Add("Specter");
            comboBox1.Items.Add("Sphinxes");
            comboBox1.Items.Add("Sprite");
            comboBox1.Items.Add("Stirge");
            comboBox1.Items.Add("Succubus/Incubus");
            // T (5)
            comboBox1.Items.Add("Tarrasque");
            comboBox1.Items.Add("Thri-kreen");
            comboBox1.Items.Add("Treant");
            comboBox1.Items.Add("Troglodyte");
            comboBox1.Items.Add("Troll");
            // U (2)
            comboBox1.Items.Add("Umber Hulk");
            comboBox1.Items.Add("Unicorn");
            // V (1)
            comboBox1.Items.Add("Vampires");
            // W (5)
            comboBox1.Items.Add("Water Weird");
            comboBox1.Items.Add("Wight");
            comboBox1.Items.Add("Will-o'wisp");
            comboBox1.Items.Add("Wraith");
            comboBox1.Items.Add("Wyvern");
            // X (1)
            comboBox1.Items.Add("Xorn");
            // Y (3)
            comboBox1.Items.Add("Yetis");
            comboBox1.Items.Add("Yuan-ti");
            comboBox1.Items.Add("Yugoloths");
            // Z (1)
            comboBox1.Items.Add("Zombies");
            //--Challenge Rating-------
            comboBox3.Items.Add("0");
            comboBox3.Items.Add("1/8");
            comboBox3.Items.Add("1/4");
            comboBox3.Items.Add("1/2");
            comboBox3.Items.Add("1");
            comboBox3.Items.Add("2");
            comboBox3.Items.Add("3");
            comboBox3.Items.Add("4");
            comboBox3.Items.Add("5");
            comboBox3.Items.Add("6");
            comboBox3.Items.Add("7");
            comboBox3.Items.Add("8");
            comboBox3.Items.Add("9");
            comboBox3.Items.Add("10");
            comboBox3.Items.Add("11");
            comboBox3.Items.Add("12");
            comboBox3.Items.Add("13");
            comboBox3.Items.Add("14");
            comboBox3.Items.Add("15");
            comboBox3.Items.Add("16");
            comboBox3.Items.Add("17");
            comboBox3.Items.Add("18");
            comboBox3.Items.Add("19");
            comboBox3.Items.Add("20");
            comboBox3.Items.Add("21");
            comboBox3.Items.Add("22");
            comboBox3.Items.Add("23");
            comboBox3.Items.Add("24");
            comboBox3.Items.Add("25");
            comboBox3.Items.Add("26");
            comboBox3.Items.Add("27");
            comboBox3.Items.Add("28");
            comboBox3.Items.Add("29");
            comboBox3.Items.Add("30");
  // Misc. Creatures ----------------------------------
            miscCreateComboBox.Items.Add("Ape");
            miscCreateComboBox.Items.Add("Awakened Shrub");
            miscCreateComboBox.Items.Add("Awakened Tree");
            miscCreateComboBox.Items.Add("Axe Beak");
            miscCreateComboBox.Items.Add("Baboon");
            miscCreateComboBox.Items.Add("Badger");
            miscCreateComboBox.Items.Add("Bat");
            miscCreateComboBox.Items.Add("Black Bear");
            miscCreateComboBox.Items.Add("Blink Dog");
            miscCreateComboBox.Items.Add("Blood Hawk");
            miscCreateComboBox.Items.Add("Boar");
            miscCreateComboBox.Items.Add("Brown Bear");
            miscCreateComboBox.Items.Add("Camel");
            miscCreateComboBox.Items.Add("Cat");
            miscCreateComboBox.Items.Add("Constrictor Snake");
            miscCreateComboBox.Items.Add("Crab");
            miscCreateComboBox.Items.Add("Crocodile");
            miscCreateComboBox.Items.Add("Death Dog");
            miscCreateComboBox.Items.Add("Deer");
            miscCreateComboBox.Items.Add("Dire Wolf");
            miscCreateComboBox.Items.Add("Draft Horse");
            miscCreateComboBox.Items.Add("Elephant");
            miscCreateComboBox.Items.Add("Elk");
            miscCreateComboBox.Items.Add("Flying Snake");
            miscCreateComboBox.Items.Add("Frog");
            miscCreateComboBox.Items.Add("Giant Ape");
            miscCreateComboBox.Items.Add("Giant Badger");
            miscCreateComboBox.Items.Add("Giant Bat");
            miscCreateComboBox.Items.Add("Giant Boar");
            miscCreateComboBox.Items.Add("Giant Centipede");
            miscCreateComboBox.Items.Add("Giant Constrictor Snake");
            miscCreateComboBox.Items.Add("Giant Crab");
            miscCreateComboBox.Items.Add("Giant Crocodile");
            miscCreateComboBox.Items.Add("Giant Eagle");
            miscCreateComboBox.Items.Add("Giant Elk");
            miscCreateComboBox.Items.Add("Giant Fire Beetle");
            miscCreateComboBox.Items.Add("Giant Frog");
            miscCreateComboBox.Items.Add("Giant Goat");
            miscCreateComboBox.Items.Add("Giant Hyena");
            miscCreateComboBox.Items.Add("Giant Lizard");
            miscCreateComboBox.Items.Add("Giant Octopus");
            miscCreateComboBox.Items.Add("Giant Owl");
            miscCreateComboBox.Items.Add("Giant Poisonous Snake");
            miscCreateComboBox.Items.Add("Giant Rat");
            miscCreateComboBox.Items.Add("Giant Scorpion");
            miscCreateComboBox.Items.Add("Giant Sea Horse");
            miscCreateComboBox.Items.Add("Giant Shark");
            miscCreateComboBox.Items.Add("Giant Spider");
            miscCreateComboBox.Items.Add("Giant Toad");
            miscCreateComboBox.Items.Add("Giant Vulture");
            miscCreateComboBox.Items.Add("Giant Wasp");
            miscCreateComboBox.Items.Add("Giant Weasel");
            miscCreateComboBox.Items.Add("Giant Wolf Spider");
            miscCreateComboBox.Items.Add("Goat");
            miscCreateComboBox.Items.Add("Hawk");
            miscCreateComboBox.Items.Add("Hunter Shark");
            miscCreateComboBox.Items.Add("Hyena");
            miscCreateComboBox.Items.Add("Jackal");
            miscCreateComboBox.Items.Add("Killer Whale");
            miscCreateComboBox.Items.Add("Lion");
            miscCreateComboBox.Items.Add("Lizard");
            miscCreateComboBox.Items.Add("Mammoth");
            miscCreateComboBox.Items.Add("Mastiff");
            miscCreateComboBox.Items.Add("Mule");
            miscCreateComboBox.Items.Add("Octopus");
            miscCreateComboBox.Items.Add("Owl");
            miscCreateComboBox.Items.Add("Panther");
            miscCreateComboBox.Items.Add("Phase Spider");
            miscCreateComboBox.Items.Add("Poisonous Snake");
            miscCreateComboBox.Items.Add("Polar Bear");
            miscCreateComboBox.Items.Add("Pony");
            miscCreateComboBox.Items.Add("Quipper");
            miscCreateComboBox.Items.Add("Rat");
            miscCreateComboBox.Items.Add("Raven");
            miscCreateComboBox.Items.Add("Reef Shark");
            miscCreateComboBox.Items.Add("Rhinoceros");
            miscCreateComboBox.Items.Add("Riding Horse");
            miscCreateComboBox.Items.Add("Saber-Toothed Tiger");
            miscCreateComboBox.Items.Add("Scorpion");
            miscCreateComboBox.Items.Add("Sea Horse");
            miscCreateComboBox.Items.Add("Spider");
            miscCreateComboBox.Items.Add("Swarm of Bats");
            miscCreateComboBox.Items.Add("Swarm of Insects");
            miscCreateComboBox.Items.Add("Swarm of Posonous Snakes");
            miscCreateComboBox.Items.Add("Swarm of Quippers");
            miscCreateComboBox.Items.Add("Swarm of Rats");
            miscCreateComboBox.Items.Add("Swarm of Ravens");
            miscCreateComboBox.Items.Add("Tiger");
            miscCreateComboBox.Items.Add("Vulture");
            miscCreateComboBox.Items.Add("Warhorse");
            miscCreateComboBox.Items.Add("Weasel");
            miscCreateComboBox.Items.Add("Winter Wolf");
            miscCreateComboBox.Items.Add("Wolf");
            miscCreateComboBox.Items.Add("Worg");
    // Npc Characters ----------------------------------
            npcComboBox.Items.Add("Acolyte");
            npcComboBox.Items.Add("Archmage");
            npcComboBox.Items.Add("Assassin");
            npcComboBox.Items.Add("Bandit");
            npcComboBox.Items.Add("Bandit Captain");
            npcComboBox.Items.Add("Berserker");
            npcComboBox.Items.Add("Commoner");
            npcComboBox.Items.Add("Cultist");
            npcComboBox.Items.Add("Cult Fanatic");
            npcComboBox.Items.Add("Druid");
            npcComboBox.Items.Add("Gladiator");
            npcComboBox.Items.Add("Guard");
            npcComboBox.Items.Add("Knight");
            npcComboBox.Items.Add("Mage");
            npcComboBox.Items.Add("Noble");
            npcComboBox.Items.Add("Priest");
            npcComboBox.Items.Add("Scout");
            npcComboBox.Items.Add("Spy");
            npcComboBox.Items.Add("Thug");
            npcComboBox.Items.Add("Tribal Warrior");
            npcComboBox.Items.Add("Veteran");
        // Angel Sub Menu ----------------------------------
            angelSubcomboBox.Items.Add("Deva");
            angelSubcomboBox.Items.Add("Planetar");
            angelSubcomboBox.Items.Add("Solar");
       // Animated Objects Sub Menu ------------------------
            animatedObjectcomboBox.Items.Add("Animated Armor");
            animatedObjectcomboBox.Items.Add("Flying Sword");
            animatedObjectcomboBox.Items.Add("Rug of Smothering");
      // Beholder Sub Menu ---------------------------------------
            beHoldercomboBox.Items.Add("Beholder");
            beHoldercomboBox.Items.Add("Death Tyrant");
            beHoldercomboBox.Items.Add("Spectator");
     // Blight Sub Menu ---------------------------------------
            blightComboBox.Items.Add("Needle Blight");
            blightComboBox.Items.Add("Twig Blight");
            blightComboBox.Items.Add("Vine Blight");
      // BugBear Sub Menu
            bugBearComboBox.Items.Add("Bugbear");
            bugBearComboBox.Items.Add("Bugbear Chief");
     // Demon Sub Menu
            demonComboBox.Items.Add("Balor");
            demonComboBox.Items.Add("Barlgura");
            demonComboBox.Items.Add("Chasme");
            demonComboBox.Items.Add("Dretch");
            demonComboBox.Items.Add("Glabrezu");
            demonComboBox.Items.Add("Goristro");
            demonComboBox.Items.Add("Hezrou");
            demonComboBox.Items.Add("Manes");
            demonComboBox.Items.Add("Marilith");
            demonComboBox.Items.Add("Nalfeshnee");
            demonComboBox.Items.Add("Quasit");
            demonComboBox.Items.Add("Shadow Demon");
            demonComboBox.Items.Add("Vrock");
            demonComboBox.Items.Add("Yochlol");
    // Devil Sub Menu -------------------------
            devilComboBox.Items.Add("Barbed Devil");
            devilComboBox.Items.Add("Bearded Devil");
            devilComboBox.Items.Add("Bone Devil");
            devilComboBox.Items.Add("Chain Devil");
            devilComboBox.Items.Add("Erinyes");
            devilComboBox.Items.Add("Horned Devil");
            devilComboBox.Items.Add("Ice Devil");
            devilComboBox.Items.Add("Imp");
            devilComboBox.Items.Add("Lemure");
            devilComboBox.Items.Add("Pit Fiend");
            devilComboBox.Items.Add("Spined Devil");
      // Dinosaurs Sub Menu ---------------------------
            dinoComboBox.Items.Add("Allosaurus");
            dinoComboBox.Items.Add("Ankylosaurus");
            dinoComboBox.Items.Add("Plesiosaurus");
            dinoComboBox.Items.Add("Pteranodon");
            dinoComboBox.Items.Add("Triceratops");
            dinoComboBox.Items.Add("Tyrannosaurus Rex");
            // Dragon Sub Menu One ---------------------------
            dragon1ComboBox.Items.Add("Ancient Black Dragon");
            dragon1ComboBox.Items.Add("Adult Black Dragon");
            dragon1ComboBox.Items.Add("Young Black Dragon");
            dragon1ComboBox.Items.Add("Black Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Blue Dragon");
            dragon1ComboBox.Items.Add("Adult Blue Dragon");
            dragon1ComboBox.Items.Add("Young Blue Dragon");
            dragon1ComboBox.Items.Add("Blue Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Green Dragon");
            dragon1ComboBox.Items.Add("Adult Green Dragon");
            dragon1ComboBox.Items.Add("Young Green Dragon");
            dragon1ComboBox.Items.Add("Green Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Red Dragon");
            dragon1ComboBox.Items.Add("Adult Red Dragon");
            dragon1ComboBox.Items.Add("Young Red Dragon");
            dragon1ComboBox.Items.Add("Red Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient White Dragon");
            dragon1ComboBox.Items.Add("Adult White Dragon");
            dragon1ComboBox.Items.Add("Young White Dragon");
            dragon1ComboBox.Items.Add("White Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Brass Dragon");
            dragon1ComboBox.Items.Add("Adult Brass Dragon");
            dragon1ComboBox.Items.Add("Young Brass Dragon");
            dragon1ComboBox.Items.Add("Brass Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Bronze Dragon");
            dragon1ComboBox.Items.Add("Adult Bronze Dragon");
            dragon1ComboBox.Items.Add("Young Bronze Dragon");
            dragon1ComboBox.Items.Add("Bronze Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Copper Dragon");
            dragon1ComboBox.Items.Add("Adult Copper Dragon");
            dragon1ComboBox.Items.Add("Young Copper Dragon");
            dragon1ComboBox.Items.Add("Copper Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Gold Dragon");
            dragon1ComboBox.Items.Add("Adult Gold Dragon");
            dragon1ComboBox.Items.Add("Young Gold Dragon");
            dragon1ComboBox.Items.Add("Gold Dragon Wyrmling");
            dragon1ComboBox.Items.Add("Ancient Silver Dragon");
            dragon1ComboBox.Items.Add("Adult Silver Dragon");
            dragon1ComboBox.Items.Add("Young Silver Dragon");
            dragon1ComboBox.Items.Add("Silver Dragon Wyrmling");
    // Elementals Sub Menu ----------------------------
            elementsComboBox.Items.Add("Air Elemental");
            elementsComboBox.Items.Add("Earth Elemental");
            elementsComboBox.Items.Add("Fire Elemental");
            elementsComboBox.Items.Add("Water Elemental");
     // Drow Sub Menu
            drowComboBox.Items.Add("Drow");
            drowComboBox.Items.Add("Drow Elite  Warrior");
            drowComboBox.Items.Add("Drow Priestess of Lolth");
    // Fungi Sub Menu
            fungiComboBox.Items.Add("Gas Spore");
            fungiComboBox.Items.Add("Shrieker");
            fungiComboBox.Items.Add("Violet Fungus");
    // Giants Sub Menu
            giantsComboBox.Items.Add("The Ordning");
            giantsComboBox.Items.Add("Cloud Giant");
            giantsComboBox.Items.Add("Fire Giant");
            giantsComboBox.Items.Add("Frost Giant");
            giantsComboBox.Items.Add("Hill Giant");
            giantsComboBox.Items.Add("Stone Giant");
            giantsComboBox.Items.Add("Storm Giant");
     // Genies Sub Menu
            genieComboBox.Items.Add("Dao");
            genieComboBox.Items.Add("Djinni");
            genieComboBox.Items.Add("Efreeti");
            genieComboBox.Items.Add("Marid");
       // Ghouls Sub Menu
            ghoulComboBox.Items.Add("Ghast");
            ghoulComboBox.Items.Add("Ghoul");
     // Gith Sub Menu
            githComboBox.Items.Add("Githyanki Knight");
            githComboBox.Items.Add("Githyanki Warrior");
            githComboBox.Items.Add("Githzerai Monk");
            githComboBox.Items.Add("Githzerai Zerth");
    // Gnolls Sub Menu
            gnollComboBox.Items.Add("Gnoll");
            gnollComboBox.Items.Add("Gnoll Fang of Yeenoghu");
            gnollComboBox.Items.Add("Gnoll Pack Lord");
    // Golems Sub Menu
            golemComboBox.Items.Add("Clay Golem");
            golemComboBox.Items.Add("Flesh Golem");
            golemComboBox.Items.Add("Iron Golem");
            golemComboBox.Items.Add("Stone Golem");
      // Goblin Sub Menu
            goblinComboBox.Items.Add("Goblin");
            goblinComboBox.Items.Add("Goblin Boss");
       // Grick Sub Menu
            grickComboBox.Items.Add("Grick");
            grickComboBox.Items.Add("Grick Alpha");
     // Hag Sub Menu
            hagComboBox.Items.Add("Green Hag");
            hagComboBox.Items.Add("Night Hag");
            hagComboBox.Items.Add("Sea Hag");
     // Hobgoblin Sub Menu
            hobgoblinComboBox.Items.Add("Hobgoblin");
            hobgoblinComboBox.Items.Add("Hobgoblin Captain");
            hobgoblinComboBox.Items.Add("Hobgoblin Warlord");
      // Kobold Sub Menu
            koboldComboBox.Items.Add("Kobold");
            koboldComboBox.Items.Add("Winged Kobold");
      // Kuo-toa Sub Menu
            kuoComboBox.Items.Add("Kuo-Toa");
            kuoComboBox.Items.Add("Kuo-Toa Archpriest");
            kuoComboBox.Items.Add("Kuo-Toa Whip");
     // Lizardfolk Sub Menu
            lizardFolkComboBox.Items.Add("Lizardfolk");
            lizardFolkComboBox.Items.Add("Lizardfolk Shaman");
            lizardFolkComboBox.Items.Add("Lizard King/Queen");
     // Lycanthorpe Sub Menu
            lycanthropeComboBox.Items.Add("Werebear");
            lycanthropeComboBox.Items.Add("Wereboar");
            lycanthropeComboBox.Items.Add("Wererat");
            lycanthropeComboBox.Items.Add("Weretiger");
            lycanthropeComboBox.Items.Add("Werewolf");
     // Mephits Sub Menu
            mephitesComboBox.Items.Add("Dust Mephit");
            mephitesComboBox.Items.Add("Ice Mephit");
            mephitesComboBox.Items.Add("Magma Mephit");
            mephitesComboBox.Items.Add("Mud Mephit");
            mephitesComboBox.Items.Add("Smoke Mephit");
            mephitesComboBox.Items.Add("Steam Mephit");
     //  Modrones Sub Menu
            mondroneComboBox.Items.Add("Monodrone");
            mondroneComboBox.Items.Add("Duodrone");
            mondroneComboBox.Items.Add("Tridone");
            mondroneComboBox.Items.Add("Quadrone");
            mondroneComboBox.Items.Add("Pentadrone");
            // Myconid Sub Menu
            myconoidComboBox.Items.Add("Myconid Sprout");
            myconoidComboBox.Items.Add("Quaggoth Spore Servant");
            myconoidComboBox.Items.Add("Myconid Adult");
            myconoidComboBox.Items.Add("Myconid Sovereign");
        // Mummy Sub Menu
            mummyComboBox.Items.Add("Mummy");
            mummyComboBox.Items.Add("Mummy Lord");
      // Naga Sub Menu
            nagaComboBox.Items.Add("Bone Naga");
            nagaComboBox.Items.Add("Spirit Naga");
            nagaComboBox.Items.Add("Guardian Naga");
      // Ogre Sub Menu
            ogreComboBox.Items.Add("Ogre");
            ogreComboBox.Items.Add("Half-Ogre");
      // Ooze Sub Menu
            oozeComboBox.Items.Add("Black Pudding");
            oozeComboBox.Items.Add("Gelatinous Cube");
            oozeComboBox.Items.Add("Gray Ooze");
            oozeComboBox.Items.Add("Ochre Jelly");
      // Orc Sub Menu
            orcComboBox.Items.Add("Orc");
            orcComboBox.Items.Add("Orc War Chief");
            orcComboBox.Items.Add("Orc Eye of Gruumsh");
            orcComboBox.Items.Add("Orog");
      // Remorhaze Sub Menu
            remorhazComboBox.Items.Add("Young Remorhaz");
            remorhazComboBox.Items.Add("Remorhaz");
      // Sahuagin Sub Menu
            sahuaginComboBox.Items.Add("Sahuagin");
            sahuaginComboBox.Items.Add("Sahuagin Priestess");
            sahuaginComboBox.Items.Add("Sahuagin Baron");
       // Salamander Sub Menu
            salamanderComboBox.Items.Add("Fire Snake");
            salamanderComboBox.Items.Add("Salamnder");
      // Skeleton Sub Menu
            skeletonComboBox.Items.Add("Skeleton");
            skeletonComboBox.Items.Add("Minotaur Skeleton");
            skeletonComboBox.Items.Add("Warhorse Skeleton");
       // Slaadi Sub Menu
            slaadiComboBox.Items.Add("Red Slaad");
            slaadiComboBox.Items.Add("Slaad Tadpole");
            slaadiComboBox.Items.Add("Blue Slaad");
            slaadiComboBox.Items.Add("Green Slaad");
            slaadiComboBox.Items.Add("Gray Slaad");
            slaadiComboBox.Items.Add("Death Slaad");
      // Sphinx Sub Menu
            sphinxesComboBox.Items.Add("Androsphinx");
            sphinxesComboBox.Items.Add("Gynosphinx");
      // Vampire Sub Menu
            vampireComboBox.Items.Add("Vampire");
            vampireComboBox.Items.Add("Vampires Spawn");
       // Yeti Sub Menu
            yetiComboBox.Items.Add("Yeti");
            yetiComboBox.Items.Add("Abominable Yeti");
      // Yuan-Ti Sub Menu
            yuanTiComboBox.Items.Add("Yuan-ti Abomination");
            yuanTiComboBox.Items.Add("Yuan-ti Malison");
            yuanTiComboBox.Items.Add("Yuan-ti Pureblood");
     // Yugoloth Sub Menu
            yugolothComboBox.Items.Add("Arcanaloth");
            yugolothComboBox.Items.Add("Mezzoloth");
            yugolothComboBox.Items.Add("Nycaloth");
            yugolothComboBox.Items.Add("Ultroloth");
        // Zombie Sub Menu
            zombieComboBox.Items.Add("Zombie");
            zombieComboBox.Items.Add("Ogre Zombie");
            zombieComboBox.Items.Add("Beholder Zombie");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        { //---Monster List---
          //-- A --
          // Aarakocra
            if (comboBox1.SelectedIndex == 0)
            {
                pageNumLabel.Text = "12)";
            }
            // Aboleth
            if(comboBox1.SelectedIndex == 1)
            {
                pageNumLabel.Text = "13)";
            }
            // Angels
            if(comboBox1.SelectedIndex == 2)
            {
                pageNumLabel.Text = "15)";
                angelSubcomboBox.Visible = true;
                angelArrowPictureBox.Visible = true;
                angelLeftLabel.Visible = true;
                angelRightLabel.Visible = true;
            }
            else
            {
                angelArrowPictureBox.Visible = false;
                angelSubcomboBox.Visible = false;
                angelLeftLabel.Visible = false;
                angelRightLabel.Visible = false;
            }

            // Animated Objects
            if(comboBox1.SelectedIndex == 3)
            {
                pageNumLabel.Text = "19)";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = true;
                animatedObjArrowPictureBox.Visible = true;
                animatedObjLeftLabel.Visible = true;
                animatedObjectRightLabel.Visible = true;
            }
            else
            {
                animatedObjectcomboBox.Visible = false;
                animatedObjArrowPictureBox.Visible = false;
                animatedObjLeftLabel.Visible = false;
                animatedObjectRightLabel.Visible = false;
            }
            // Ankheg
            if(comboBox1.SelectedIndex == 4)
            {
                pageNumLabel.Text = "21)";
            }
            // Azer
            if(comboBox1.SelectedIndex == 5)
            {
                pageNumLabel.Text = "22)";
            }
        //-- B --
            // Banshee
            if(comboBox1.SelectedIndex == 6)
            {
                pageNumLabel.Text = "23)";
            }
            // Basilisk
            if(comboBox1.SelectedIndex == 7)
            {
                pageNumLabel.Text = "24)";
            }
            // Behir
            if(comboBox1.SelectedIndex == 8)
            {
                pageNumLabel.Text = "25)";
            }
            // Beholders
            if(comboBox1.SelectedIndex == 9)
            {
                pageNumLabel.Text = "26)";
                beHoldercomboBox.Visible = true;
                beholderArrowPictureBox.Visible = true;
                beholderLeftLabel.Visible = true;
                beholderRightLabel.Visible = true;
            }
            else
            {
                beHoldercomboBox.Visible = false;
                beholderArrowPictureBox.Visible = false;
                beholderLeftLabel.Visible = false;
                beholderRightLabel.Visible = false;
            }
            // Blights
            if(comboBox1.SelectedIndex == 10)
            {
                pageNumLabel.Text = "31)";
                blightComboBox.Visible = true;
                blightArrowBox.Visible = true;
                blightLeftLabel.Visible = true;
                blightRightLabel.Visible = true;
            }
            else
            {
                blightComboBox.Visible = false;
                blightArrowBox.Visible = false;
                blightLeftLabel.Visible = false;
                blightRightLabel.Visible = false;
            }
            // Bugbears
            if(comboBox1.SelectedIndex == 11)
            {
                pageNumLabel.Text = "33)";
                bugBearComboBox.Visible = true;
                bugbearArrowBox.Visible = true;
                bugbearLeftLabel.Visible = true;
                bugbearRightLabel.Visible = true;
            }
            else
            {
                bugBearComboBox.Visible = false;
                bugbearArrowBox.Visible = false;
                bugbearLeftLabel.Visible = false;
                bugbearRightLabel.Visible = false;
            }
            // Bulette
            if(comboBox1.SelectedIndex == 12)
            {
                pageNumLabel.Text = "34)";
            }
            // Bullywug
            if(comboBox1.SelectedIndex == 13)
            {
                pageNumLabel.Text = "35)";
            }
        //-- C --
            // Cambion
            if(comboBox1.SelectedIndex == 14)
            {
                pageNumLabel.Text = "36)";
            }
            // Carrion Crawler
            if(comboBox1.SelectedIndex == 15)
            {
                pageNumLabel.Text = "37)";
            }
            // Centaur
            if(comboBox1.SelectedIndex == 16)
            {
                pageNumLabel.Text = "38)";
            }
            // Chimera
            if(comboBox1.SelectedIndex == 17)
            {
                pageNumLabel.Text = "39)";
            }
            // Chuul
            if(comboBox1.SelectedIndex == 18)
            {
                pageNumLabel.Text = "40)";
            }
            // Cloaker
            if(comboBox1.SelectedIndex == 19)
            {
                pageNumLabel.Text = "41)";
            }
            // Cockatrice
            if(comboBox1.SelectedIndex == 20)
            {
                pageNumLabel.Text = "42)";
            }
            // Couatl
            if(comboBox1.SelectedIndex == 21)
            {
                pageNumLabel.Text = "43)";
            }
            // Crawling Claw
            if(comboBox1.SelectedIndex == 22)
            {
                pageNumLabel.Text = "44)";
            }
            // Cyclops
            if(comboBox1.SelectedIndex == 23)
            {
                pageNumLabel.Text = "45)";
            }
        //-- D --
            // Darkmantle
            if(comboBox1.SelectedIndex == 24)
            {
                pageNumLabel.Text = "46)";
            }
            // Death Knight
            if(comboBox1.SelectedIndex == 25)
            {
                pageNumLabel.Text = "47)";
            }
            // Demilich
            if(comboBox1.SelectedIndex == 26)
            {
                pageNumLabel.Text = "48)";
            }
            // Demons
            if(comboBox1.SelectedIndex == 27)
            {
                pageNumLabel.Text = "50)";
                demonComboBox.Visible = true;
                demonArrowBox.Visible = true;
                demonLeftLabel.Visible = true;
                demonRightLabel.Visible = true;
            }
            else
            {
                demonComboBox.Visible = false;
                demonArrowBox.Visible = false;
                demonLeftLabel.Visible = false;
                demonRightLabel.Visible = false;
            }
            // Devils
            if(comboBox1.SelectedIndex == 28)
            {
                pageNumLabel.Text = "66)";
                devilComboBox.Visible = true;
                devilArrowBox.Visible = true;
                devilLeftLabel.Visible = true;
                devilRightLabel.Visible = true;
            }
            else
            {
                devilComboBox.Visible = false;
                devilArrowBox.Visible = false;
                devilLeftLabel.Visible = false;
                devilRightLabel.Visible = false;
            }
            // Dinosaurs
            if(comboBox1.SelectedIndex == 29)
            {
                pageNumLabel.Text = "79)";
                dinoComboBox.Visible = true;
                dinoArrowBox.Visible = true;
                dinoLeftLabel.Visible = true;
                dinoRightLabel.Visible = true;
            }
            else
            {
                dinoComboBox.Visible = false;
                dinoArrowBox.Visible = false;
                dinoLeftLabel.Visible = false;
                dinoRightLabel.Visible = false;
            }
            // Displacer Beast
            if(comboBox1.SelectedIndex == 30)
            {
                pageNumLabel.Text = "81)";
            }
            // Doppelganger
            if(comboBox1.SelectedIndex == 31)
            {
                pageNumLabel.Text = "82)";
            }
            // Dracolich
            if(comboBox1.SelectedIndex == 32)
            {
                pageNumLabel.Text = "83)";
            }
            // Dragon, Shadow
            if(comboBox1.SelectedIndex == 33)
            {
                pageNumLabel.Text = "84)";
            }
            // Dragons
            if(comboBox1.SelectedIndex == 34)
            {
                pageNumLabel.Text = "86)";
                dragon1ComboBox.Visible = true;
                dragArrowBox.Visible = true;
                dragLeftLabel.Visible = true;
                dragRightLabel.Visible = true;
            }
            else
            {
                dragon1ComboBox.Visible = false;
                dragArrowBox.Visible = false;
                dragLeftLabel.Visible = false;
                dragRightLabel.Visible = false;
            }
            // Dragon Turtle
            if (comboBox1.SelectedIndex == 35)
            {
                pageNumLabel.Text = "119)";
            }
            // Drider
            if(comboBox1.SelectedIndex == 36)
            {
                pageNumLabel.Text = "120)";
            }
            // Dryad
            if(comboBox1.SelectedIndex == 37)
            {
                pageNumLabel.Text = "121)";
            }
            // Duergar
            if(comboBox1.SelectedIndex == 38)
            {
                pageNumLabel.Text = "122)";
            }
        //-- E --
            // Elementals
            if(comboBox1.SelectedIndex == 39)
            {
                pageNumLabel.Text = "123)";
                elementsComboBox.Visible = true;
                elemArrowBox.Visible = true;
                elemLeftLabel.Visible = true;
                elemRightLabel.Visible = true;
            }
            else
            {
                elementsComboBox.Visible = false;
                elemArrowBox.Visible = false;
                elemLeftLabel.Visible = false;
                elemRightLabel.Visible = false;
            }
            // Elves: Drow
            if(comboBox1.SelectedIndex == 40)
            {
                pageNumLabel.Text = "126)";
                drowComboBox.Visible = true;
                drowArrowBox.Visible = true;
                drowLeftLabel.Visible = true;
                drowRightLabel.Visible = true;
            }
            else
            {
                drowComboBox.Visible = false;
                drowArrowBox.Visible = false;
                drowLeftLabel.Visible = false;
                drowRightLabel.Visible = false;
            }
            // Empyrean
            if(comboBox1.SelectedIndex == 41)
            {
                pageNumLabel.Text = "130)";
            }
            // Ettercap
            if(comboBox1.SelectedIndex == 42)
            {
                pageNumLabel.Text = "131)";
            }
            // Ettin
            if(comboBox1.SelectedIndex == 43)
            {
                pageNumLabel.Text = "132)";
            }
        //-- F --
            // Faerie Dragon
            if(comboBox1.SelectedIndex == 44)
            {
                pageNumLabel.Text = "133)";
            }
            // Flameskull
            if(comboBox1.SelectedIndex == 45)
            {
                pageNumLabel.Text = "134)";
            }
            // Flumph
            if(comboBox1.SelectedIndex == 46)
            {
                pageNumLabel.Text = "135)";
            }
            // Fomorian
            if(comboBox1.SelectedIndex == 47)
            {
                pageNumLabel.Text = "136)";
            }
            // Fungi
            if(comboBox1.SelectedIndex == 48)
            {
                pageNumLabel.Text = "137)";
                fungiComboBox.Visible = true;
                fungiArrowBox.Visible = true;
                fungiLeftLabel.Visible = true;
                fungiRightLabel.Visible = true;
            }
            else
            {
                fungiComboBox.Visible = false;
                fungiArrowBox.Visible = false;
                fungiLeftLabel.Visible = false;
                fungiRightLabel.Visible = false;

            }
        //-- G --
            // Galeb Duhr
            if(comboBox1.SelectedIndex == 49)
            {
                pageNumLabel.Text = "139)";
            }
            // Gargoyle
            if(comboBox1.SelectedIndex == 50)
            {
                pageNumLabel.Text = "140)";
            }
            // Genies
            if(comboBox1.SelectedIndex == 51)
            {
                pageNumLabel.Text = "141)";
                genieComboBox.Visible = true;
                genieArrowBox.Visible = true;
                genieLeftLabel.Visible = true;
                genieRightLabel.Visible = true;
            }
            else
            {
                genieComboBox.Visible = false;
                genieArrowBox.Visible = false;
                genieLeftLabel.Visible = false;
                genieRightLabel.Visible = false;
            }
            // Ghost
            if(comboBox1.SelectedIndex == 52)
            {
                pageNumLabel.Text = "147)";
            }
            // Ghouls
            if(comboBox1.SelectedIndex == 53)
            {
                pageNumLabel.Text = "148)";
                ghoulComboBox.Visible = true;
                ghoulArrowBox.Visible = true;
                ghoulLeftLabel.Visible = true;
                ghoulRightLabel.Visible = true;
            }
            else
            {
                ghoulComboBox.Visible = false;
                ghoulArrowBox.Visible = false;
                ghoulLeftLabel.Visible = false;
                ghoulRightLabel.Visible = false;
            }
            // Giants
            if(comboBox1.SelectedIndex == 54)
            {
                pageNumLabel.Text = "149)";
                giantsComboBox.Visible = true;
                giantsArrowBox.Visible = true;
                giantsLeftLabel.Visible = true;
                giantsRightLabel.Visible = true;
            }
            else
            {
                giantsComboBox.Visible = false;
                giantsArrowBox.Visible = false;
                giantsLeftLabel.Visible = false;
                giantsRightLabel.Visible = false;
            }
            // Gibbering Mouther
            if(comboBox1.SelectedIndex == 55)
            {
                pageNumLabel.Text = "157)";
            }
            // Gith 
            if(comboBox1.SelectedIndex == 56)
            {
                pageNumLabel.Text = "158)";
                githComboBox.Visible = true;
                githArrowBox.Visible = true;
                githLeftLabel.Visible = true;
                githRightLabel.Visible = true;
            }
            else
            {
                githComboBox.Visible = false;
                githArrowBox.Visible = false;
                githLeftLabel.Visible = false;
                githRightLabel.Visible = false;
            }
            // Gnolls
            if(comboBox1.SelectedIndex == 57)
            {
                pageNumLabel.Text = "162)";
                gnollComboBox.Visible = true;
                gnollArrowBox.Visible = true;
                gnollLeftLabel.Visible = true;
                gnollRightLabel.Visible = true;
            }
            else
            {
                gnollComboBox.Visible = false;
                gnollArrowBox.Visible = false;
                gnollLeftLabel.Visible = false;
                gnollRightLabel.Visible = false;
            }
            // Gnome, Deep
            if(comboBox1.SelectedIndex == 58)
            {
                pageNumLabel.Text = "164)";
            }
            // Goblins
            if(comboBox1.SelectedIndex == 59)
            {
                pageNumLabel.Text = "165)";
                goblinComboBox.Visible = true;
                goblinArrowBox.Visible = true;
                goblinLeftLabel.Visible = true;
                goblinRightLabel.Visible = true;
            }
            else
            {
                goblinComboBox.Visible = false;
                goblinArrowBox.Visible = false;
                goblinLeftLabel.Visible = false;
                goblinRightLabel.Visible = false;
            }
            // Golems 
            if(comboBox1.SelectedIndex == 60)
            {
                pageNumLabel.Text = "167)";
                golemComboBox.Visible = true;
                golemArrowBox.Visible = true;
                golemLeftLabel.Visible = true;
                golemRightLabel.Visible = true;
            }
            else
            {
                golemComboBox.Visible = false;
                golemArrowBox.Visible = false;
                golemLeftLabel.Visible = false;
                golemRightLabel.Visible = false;
            }
            // Gorgon
            if(comboBox1.SelectedIndex == 61)
            {
                pageNumLabel.Text = "171)";
            }
            // Grell
            if(comboBox1.SelectedIndex == 62)
            {
                pageNumLabel.Text = "172)";
            }
            // Grick
            if(comboBox1.SelectedIndex == 63)
            {
                pageNumLabel.Text = "173)";
                grickComboBox.Visible = true;
                grickArrowBox.Visible = true;
                grickLeftLabel.Visible = true;
                grickRightLabel.Visible = true;
            }
            else
            {
                grickComboBox.Visible = false;
                grickArrowBox.Visible = false;
                grickLeftLabel.Visible = false;
                grickRightLabel.Visible = false;
            }
            // Griffon
            if(comboBox1.SelectedIndex == 64)
            {
                pageNumLabel.Text = "174)";
            }
            // Grimlock
            if(comboBox1.SelectedIndex == 65)
            {
                pageNumLabel.Text = "175)";
            }
       //-- H --
            // Hags
            if(comboBox1.SelectedIndex == 66)
            {
                pageNumLabel.Text = "176)";
                hagComboBox.Visible = true;
                hagArrowBox.Visible = true;
                hagLeftLabel.Visible = true;
                hagRightLabel.Visible = true;
            }
            else
            {
                hagComboBox.Visible = false;
                hagArrowBox.Visible = false;
                hagLeftLabel.Visible = false;
                hagRightLabel.Visible = false;
            }
            // Half-Dragon
            if(comboBox1.SelectedIndex == 67)
            {
                pageNumLabel.Text = "180)";
            }
            // Harpy
            if(comboBox1.SelectedIndex == 68)
            {
                pageNumLabel.Text = "181)";
            }
            // Hell Hound
            if(comboBox1.SelectedIndex == 69)
            {
                pageNumLabel.Text = "182)";
            }
            // Helmed Horror 
            if(comboBox1.SelectedIndex == 70)
            {
                pageNumLabel.Text = "183)";
            }
            // Hippogrif
            if(comboBox1.SelectedIndex == 71)
            {
                pageNumLabel.Text = "184)";
            }
            // Hobgoblins
            if(comboBox1.SelectedIndex == 72)
            {
                pageNumLabel.Text = "185)";
                hobgoblinComboBox.Visible = true;
                hobgoblinArrowBox.Visible = true;
                hobgoblinLeftLabel.Visible = true;
                hobgoblinRightLabel.Visible = true; 
            }
            else
            {
                hobgoblinComboBox.Visible = false;
                hobgoblinArrowBox.Visible = false;
                hobgoblinLeftLabel.Visible = false;
                hobgoblinRightLabel.Visible = false;
            }
            // Homunculus
            if(comboBox1.SelectedIndex == 73)
            {
                pageNumLabel.Text = "188)";
            }
            // Hook Horror
            if(comboBox1.SelectedIndex == 74)
            {
                pageNumLabel.Text = "189)";
            }
            // Hydra
            if(comboBox1.SelectedIndex == 75)
            {
                pageNumLabel.Text = "190)";
            }
       //-- I --
            // Intellect Devourer
            if(comboBox1.SelectedIndex == 76)
            {
                pageNumLabel.Text = "191)";
            }
            // Invisible Stalker
            if(comboBox1.SelectedIndex == 77)
            {
                pageNumLabel.Text = "192)";
            }
        //-- J --
            // Jackalwere
            if(comboBox1.SelectedIndex == 78)
            {
                pageNumLabel.Text = "193)";
            }
        //-- K --
            // Kenku
            if(comboBox1.SelectedIndex == 79)
            {
                pageNumLabel.Text = "194)";
            }
            // Kobolds
            if(comboBox1.SelectedIndex == 80)
            {
                pageNumLabel.Text = "195)";
                koboldComboBox.Visible = true;
                koboldArrowBox.Visible = true;
                koboldLeftLabel.Visible = true;
                koboldRightLabel.Visible = true;
            }
            else
            {
                koboldComboBox.Visible = false;
                koboldArrowBox.Visible = false;
                koboldLeftLabel.Visible = false;
                koboldRightLabel.Visible = false;
            }
            // Kraken
            if(comboBox1.SelectedIndex == 81)
            {
                pageNumLabel.Text = "196)";
            }
            // Kuo-toa
            if(comboBox1.SelectedIndex == 82)
            {
                pageNumLabel.Text = "198)";
                kuoComboBox.Visible = true;
                kuoArrowBox.Visible = true;
                kuoLeftLabel.Visible = true;
                kuoRightLabel.Visible = true;
            }
            else
            {
                kuoComboBox.Visible = false;
                kuoArrowBox.Visible = false;
                kuoLeftLabel.Visible = false;
                kuoRightLabel.Visible = false;
            }
      //-- L --
            // Lamia
            if(comboBox1.SelectedIndex == 83)
            {
                pageNumLabel.Text = "201)";
            }
            // Lich
            if(comboBox1.SelectedIndex == 84)
            {
                pageNumLabel.Text = "202)";
            }
            // Lizardfolk
            if(comboBox1.SelectedIndex == 85)
            {
                pageNumLabel.Text = "204)";
                lizardFolkComboBox.Visible = true;
                lizardfolkArrowBox.Visible = true;
                lizardfolkLeftLabel.Visible = true;
                lizardfolkRightLabel.Visible = true;
            }
            else
            {
                lizardFolkComboBox.Visible = false;
                lizardfolkArrowBox.Visible = false;
                lizardfolkLeftLabel.Visible = false;
                lizardfolkRightLabel.Visible = false;
            }
            // Lycanthropes
            if(comboBox1.SelectedIndex == 86)
            {
                pageNumLabel.Text = "206)";
                lycanthropeComboBox.Visible = true;
                lycanArrowBox.Visible = true;
                lycanLeftLabel.Visible = true;
                lycanRightLabel.Visible = true;
            }
            else
            {
                lycanthropeComboBox.Visible = false;
                lycanArrowBox.Visible = false;
                lycanLeftLabel.Visible = false;
                lycanRightLabel.Visible = false;
            }
        //-- M --
            // Magmin
            if(comboBox1.SelectedIndex == 87)
            {
                pageNumLabel.Text = "212)";
            }
            // Manticore
            if(comboBox1.SelectedIndex == 88)
            {
                pageNumLabel.Text = "213)";
            }
            // Medusa
            if(comboBox1.SelectedIndex == 89)
            {
                pageNumLabel.Text = "214)";
            }
            // Mephits
            if(comboBox1.SelectedIndex == 90)
            {
                pageNumLabel.Text = "215)";
                mephitesComboBox.Visible = true;
                mephitArrowBox.Visible = true;
                mephitLeftLabel.Visible = true;
                mephitRightLabel.Visible = true;
            }
            else
            {
                mephitesComboBox.Visible = false;
                mephitArrowBox.Visible = false;
                mephitLeftLabel.Visible = false;
                mephitRightLabel.Visible = false;
            }
            // Merfolk
            if(comboBox1.SelectedIndex == 91)
            {
                pageNumLabel.Text = "218)";
                angelSubcomboBox.Visible = false;
            }
            // Merrow
            if (comboBox1.SelectedIndex == 92)
            {
                pageNumLabel.Text = "219)"; 
            }
            // Mimic
            if(comboBox1.SelectedIndex == 93)
            {
                pageNumLabel.Text = "220)";
            }
            // Mind Flayer
            if(comboBox1.SelectedIndex == 94)
            {
                pageNumLabel.Text = "221)";
            }
            // Minotaur
            if(comboBox1.SelectedIndex == 95)
            {
                pageNumLabel.Text = "223)";
            }
            // Modrons
            if(comboBox1.SelectedIndex == 96)
            {
                pageNumLabel.Text = "224)";
                mondroneComboBox.Visible = true;
                modroneArrowBox.Visible = true;
                modroneLeftLabel.Visible = true;
                modroneRightLabel.Visible = true;
            }
            else
            {
                mondroneComboBox.Visible = false;
                modroneArrowBox.Visible = false;
                modroneLeftLabel.Visible = false;
                modroneRightLabel.Visible = false;
            }
            // Mummies
            if(comboBox1.SelectedIndex == 97)
            {
                pageNumLabel.Text = "227)";
                mummyComboBox.Visible = true;
                mummyArrowBox.Visible = true;
                mummyLeftLabel.Visible = true;
                mummyRightLabel.Visible = true;
            }
            else
            {
                mummyComboBox.Visible = false;
                mummyArrowBox.Visible = false;
                mummyLeftLabel.Visible = false;
                mummyRightLabel.Visible = false;
            }
            // Myconids
            if(comboBox1.SelectedIndex == 98)
            {
                pageNumLabel.Text = "230)";
                myconoidComboBox.Visible = true;
                myconidArrowBox.Visible = true;
                myconidLeftLabel.Visible = true;
                myconidRightLabel.Visible = true;
            }
            else
            {
                myconoidComboBox.Visible = false;
                myconidArrowBox.Visible = false;
                myconidLeftLabel.Visible = false;
                myconidRightLabel.Visible = false;
            }
        //-- N --
            // Nagas
            if(comboBox1.SelectedIndex == 99)
            {
                pageNumLabel.Text = "233)";
                nagaComboBox.Visible = true;
                nagaArrowBox.Visible = true;
                nagaLeftLabel.Visible = true;
                nagaRightLabel.Visible = true;
            }
            else
            {
                nagaComboBox.Visible = false;
                nagaArrowBox.Visible = false;
                nagaLeftLabel.Visible = false;
                nagaRightLabel.Visible = false;
            }
            // Nightmare
            if(comboBox1.SelectedIndex == 100)
            {
                pageNumLabel.Text = "235)";
            }
            // Nothic
            if(comboBox1.SelectedIndex == 101)
            {
                pageNumLabel.Text = "236)";
            }
        //-- O --
            // Ogres
            if(comboBox1.SelectedIndex == 102)
            {
                pageNumLabel.Text = "237)";
                ogreComboBox.Visible = true;
                ogreArrowBox.Visible = true;
                ogreLeftLabel.Visible = true;
                ogreRightLabel.Visible = true;
            }
            else
            {
                ogreComboBox.Visible = false;
                ogreArrowBox.Visible = false;
                ogreLeftLabel.Visible = false;
                ogreRightLabel.Visible = false;
            }
            // Oni
            if(comboBox1.SelectedIndex == 103)
            {
                pageNumLabel.Text = "239)";
            }
            // Oozes
            if(comboBox1.SelectedIndex == 104)
            {
                pageNumLabel.Text = "240)";
                oozeComboBox.Visible = true;
                oozeArrowBox.Visible = true;
                oozeLeftLabel.Visible = true;
                oozeRightLabel.Visible = true;
            }
            else
            {
                oozeComboBox.Visible = false;
                oozeArrowBox.Visible = false;
                oozeLeftLabel.Visible = false;
                oozeRightLabel.Visible = false;
            }
            // Orcs
            if(comboBox1.SelectedIndex == 105)
            {
                pageNumLabel.Text = "244)";
                orcComboBox.Visible = true;
                orcArrowBox.Visible = true;
                orcLeftLabel.Visible = true;
                orcRightLabel.Visible = true;
            }
            else
            {
                orcComboBox.Visible = false;
                orcArrowBox.Visible = false;
                orcLeftLabel.Visible = false;
                orcRightLabel.Visible = false;
            }
            // Otyugh
            if(comboBox1.SelectedIndex == 106)
            {
                pageNumLabel.Text = "248)";
            }
            // Owlbear
            if(comboBox1.SelectedIndex == 107)
            {
                pageNumLabel.Text = "249)";
            }
        //-- P --
            // Pegasus
            if(comboBox1.SelectedIndex == 108)
            {
                pageNumLabel.Text = "250)";
            }
            // Peryton
            if(comboBox1.SelectedIndex == 109)
            {
                pageNumLabel.Text = "251)";
            }
            // Piercer
            if(comboBox1.SelectedIndex == 110)
            {
                pageNumLabel.Text = "252)";
            }
            // Pixie
            if(comboBox1.SelectedIndex == 111)
            {
                pageNumLabel.Text = "253)";
            }
            // Pseudodragon
            if(comboBox1.SelectedIndex == 112)
            {
                pageNumLabel.Text = "254)";
            }
            // Purple Worm
            if(comboBox1.SelectedIndex == 113)
            {
                pageNumLabel.Text = "255)";
            }
        //-- Q --
            // Quaggoth
            if(comboBox1.SelectedIndex == 114)
            {
                pageNumLabel.Text = "256)";
            }
        //-- R --
            // Rakshasha
            if(comboBox1.SelectedIndex == 115)
            {
                pageNumLabel.Text = "257)";
            }
            // Remorhazes
            if(comboBox1.SelectedIndex == 116)
            {
                pageNumLabel.Text = "258)";
                remorhazComboBox.Visible = true;
                remorhazeArrowBox.Visible = true;
                remorhazLeftLabel.Visible = true;
                remorhazRightLabel.Visible = true;
            }
            else
            {
                remorhazComboBox.Visible = false;
                remorhazeArrowBox.Visible = false;
                remorhazLeftLabel.Visible = false;
                remorhazRightLabel.Visible = false;
            }
            // Revenant
            if(comboBox1.SelectedIndex == 117)
            {
                pageNumLabel.Text = "259)";
            }
            // Roc
            if(comboBox1.SelectedIndex == 118)
            {
                pageNumLabel.Text = "260)";
            }
            // Roper
            if(comboBox1.SelectedIndex == 119)
            {
                pageNumLabel.Text = "261)";
            }
            // Rust Monster
            if(comboBox1.SelectedIndex == 120)
            {
                pageNumLabel.Text = "262)";
            }
        //-- S --
            // Sahuagin
            if(comboBox1.SelectedIndex == 121)
            {
                pageNumLabel.Text = "263)";
                sahuaginComboBox.Visible = true;
                sahuginArrowBox.Visible = true;
                sahuginLeftLabel.Visible = true;
                sahuginRightLabel.Visible = true;
            }
            else
            {
                sahuaginComboBox.Visible = false;
                sahuginArrowBox.Visible = false;
                sahuginLeftLabel.Visible = false;
                sahuginRightLabel.Visible = false;
            }
            // Salamanders
            if(comboBox1.SelectedIndex == 122)
            {
                pageNumLabel.Text = "265)";
                salamanderComboBox.Visible = true;
                salamanderArrowBox.Visible = true;
                salamanderLeftLabel.Visible = true;
                salamanderRightLabel.Visible = true;
            }
            else
            {
                salamanderComboBox.Visible = false;
                salamanderArrowBox.Visible = false;
                salamanderLeftLabel.Visible = false;
                salamanderRightLabel.Visible = false;
            }
            // Satyr
            if(comboBox1.SelectedIndex == 123)
            {
                pageNumLabel.Text = "267)";
            }
            // Scarecrow
            if(comboBox1.SelectedIndex == 124)
            {
                pageNumLabel.Text = "268)";
            }
            // Shadow
            if(comboBox1.SelectedIndex == 125)
            {
                pageNumLabel.Text = "269)";
            }
            // Shambling Mound
            if(comboBox1.SelectedIndex == 126)
            {
                pageNumLabel.Text = "270)";
            }
            // Shield Guardian
            if(comboBox1.SelectedIndex == 127)
            {
                pageNumLabel.Text = "271)";
            }
            // Skeletons
            if(comboBox1.SelectedIndex == 128)
            {
                pageNumLabel.Text = "272)";
                skeletonComboBox.Visible = true;
                skeletonArrowBox.Visible = true;
                skeletonLeftLabel.Visible = true;
                skeletonRightLabel.Visible = true;
            }
            else
            {
                skeletonComboBox.Visible = false;
                skeletonArrowBox.Visible = false;
                skeletonLeftLabel.Visible = false;
                skeletonRightLabel.Visible = false;
            }
            // Slaadi
            if(comboBox1.SelectedIndex == 129)
            {
                pageNumLabel.Text = "274)";
                slaadiComboBox.Visible = true;
                sladdiArrowBox.Visible = true;
                slaadiLeftLabel.Visible = true;
                slaadiRightLabel.Visible = true;
            }
            else
            {
                slaadiComboBox.Visible = false;
                sladdiArrowBox.Visible = false;
                slaadiLeftLabel.Visible = false;
                slaadiRightLabel.Visible = false;
            }
            // Specter
            if(comboBox1.SelectedIndex == 130)
            {
                pageNumLabel.Text = "279)";
            }
            // Sphinxes
            if(comboBox1.SelectedIndex == 131)
            {
                pageNumLabel.Text = "280)";
                sphinxesComboBox.Visible = true;
                sphinxArrowBox.Visible = true;
                sphinxLeftLabel.Visible = true;
                sphinxRightLabel.Visible = true;
            }
            else
            {
                sphinxesComboBox.Visible = false;
                sphinxArrowBox.Visible = false;
                sphinxLeftLabel.Visible = false;
                sphinxRightLabel.Visible = false;
            }
            // Sprite
            if(comboBox1.SelectedIndex == 132)
            {
                pageNumLabel.Text = "283)";
            }
            // Stirge
            if(comboBox1.SelectedIndex == 133)
            {
                pageNumLabel.Text = "284)";
            }
            // Succubus/Incubus
            if(comboBox1.SelectedIndex == 134)
            {
                pageNumLabel.Text = "285)";
            }
        //-- T --
            // Tarrasque
            if(comboBox1.SelectedIndex == 135)
            {
                pageNumLabel.Text = "286)";
            }
            // Thri-kreen
            if(comboBox1.SelectedIndex == 136)
            {
                pageNumLabel.Text = "288)";
            }
            // Treant
            if(comboBox1.SelectedIndex == 137)
            {
                pageNumLabel.Text = "289)";
            }
            // Troglodyte
            if(comboBox1.SelectedIndex == 138)
            {
                pageNumLabel.Text = "290)";
            }
            // Troll
            if(comboBox1.SelectedIndex == 139)
            {
                pageNumLabel.Text = "291)";
            }
        //-- U --
            // Umber Hulk
            if(comboBox1.SelectedIndex == 140)
            {
                pageNumLabel.Text = "292)";
            }
            // Unicorn
            if(comboBox1.SelectedIndex == 141)
            {
                pageNumLabel.Text = "293)";
            }
        //-- V --
            // Vampires
            if(comboBox1.SelectedIndex == 142)
            {
                pageNumLabel.Text = "295)";
                vampireComboBox.Visible = true;
                vampireArrowBox.Visible = true;
                vampireLeftLabel.Visible = true;
                vampireRightLabel.Visible = true;
            }
            else
            {
                vampireComboBox.Visible = false;
                vampireArrowBox.Visible = false;
                vampireLeftLabel.Visible = false;
                vampireRightLabel.Visible = false;
            }
        //-- W --
            // Water Weird
            if(comboBox1.SelectedIndex == 143)
            {
                pageNumLabel.Text = "299)";
            }
            // Wight
            if(comboBox1.SelectedIndex == 144)
            {
                pageNumLabel.Text = "300)";
            }
            // Will-o'-wisp
            if(comboBox1.SelectedIndex == 145)
            {
                pageNumLabel.Text = "301)";
            }
            // Wraith
            if(comboBox1.SelectedIndex == 146)
            {
                pageNumLabel.Text = "302)";
            }
            // Wyvern
            if(comboBox1.SelectedIndex == 147)
            {
                pageNumLabel.Text = "303)";
            }
       //-- X --
            // Xorn
            if(comboBox1.SelectedIndex == 148)
            {
                pageNumLabel.Text = "304)";
            }
       //-- Y --
            // Yetis
            if(comboBox1.SelectedIndex == 149)
            {
                pageNumLabel.Text = "305)";
                yetiComboBox.Visible = true;
                yetiArrowBox.Visible = true;
                yetiLeftLabel.Visible = true;
                yetiRightLabel.Visible = true;
            }
            else
            {
                yetiComboBox.Visible = false;
                yetiArrowBox.Visible = false;
                yetiLeftLabel.Visible = false;
                yetiRightLabel.Visible = false;
            }
            // Yuan-ti
            if(comboBox1.SelectedIndex == 150)
            {
                pageNumLabel.Text = "307)";
                yuanTiComboBox.Visible = true;
                yuanArrowBox.Visible = true;
                yuanLeftLabel.Visible = true;
                yuanRightLabel.Visible = true; 
            }
            else
            {
                yuanTiComboBox.Visible = false;
                yuanArrowBox.Visible = false;
                yuanLeftLabel.Visible = false;
                yuanRightLabel.Visible = false;
            }
            // Yugoloths
            if(comboBox1.SelectedIndex == 151)
            {
                pageNumLabel.Text = "311)";
                yugolothComboBox.Visible = true;
                yugoArrowBox.Visible = true;
                yugoLeftLabel.Visible = true;
                yugoRightLabel.Visible = true; 
            }
            else
            {
                yugolothComboBox.Visible = false;
                yugoArrowBox.Visible = false;
                yugoLeftLabel.Visible = false;
                yugoRightLabel.Visible = false;
            }
        //-- Z --
            // Zombies
            if(comboBox1.SelectedIndex == 152)
            {
                pageNumLabel.Text = "315)";
                zombieComboBox.Visible = true;
                zombieArrowBox.Visible = true;
                zombieLeftLabel.Visible = true;
                zombieRightLabel.Visible = true;
            }
            else
            {
                zombieComboBox.Visible = false;
                zombieArrowBox.Visible = false;
                zombieLeftLabel.Visible = false;
                zombieRightLabel.Visible = false;
            }

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {//--Challenge Rating:
            // 0
            if(comboBox3.SelectedIndex == 0)
            {
                lvlLabel.Text = "0";
                acLabel.Text = "< 13";
                profLabel.Text = "+2";
                hpLabel.Text = "1-6";
                attackBLabel.Text = "< +3";
                damageLabel.Text = "0-1";
                saveThrowLabel.Text = "< 13";
                expLabel.Text = "0 or 10";
            }
            // 1/8
            if (comboBox3.SelectedIndex == 1)
            {
                lvlLabel.Text = "1/8";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "7-35";
                attackBLabel.Text = "+3";
                damageLabel.Text = "2-3";
                saveThrowLabel.Text = "13";
                expLabel.Text = "25";
            }
            // 1/4
            if (comboBox3.SelectedIndex == 2)
            {
                lvlLabel.Text = "1/4";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "36-49";
                attackBLabel.Text = "+3";
                damageLabel.Text = "4-5";
                saveThrowLabel.Text = "13";
                expLabel.Text = "50";
            }
            // 1/2
            if (comboBox3.SelectedIndex == 3)
            {
                lvlLabel.Text = "1/2";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "50-70";
                attackBLabel.Text = "+3";
                damageLabel.Text = "6-8";
                saveThrowLabel.Text = "13";
                expLabel.Text = "100";
            }
            // 1
            if (comboBox3.SelectedIndex == 4)
            {
                lvlLabel.Text = "1";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "71-85";
                attackBLabel.Text = "+3";
                damageLabel.Text = "9-14";
                saveThrowLabel.Text = "13";
                expLabel.Text = "200";
            }
            // 2
            if (comboBox3.SelectedIndex == 5)
            {
                lvlLabel.Text = "2";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "86-100";
                attackBLabel.Text = "+3";
                damageLabel.Text = "15-20";
                saveThrowLabel.Text = "13";
                expLabel.Text = "450";
            }
            // 3
            if (comboBox3.SelectedIndex == 6)
            {
                lvlLabel.Text = "3";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "101-115";
                attackBLabel.Text = "+4";
                damageLabel.Text = "21-26";
                saveThrowLabel.Text = "13";
                expLabel.Text = "700";
            }
            // 4
            if (comboBox3.SelectedIndex == 7)
            {
                lvlLabel.Text = "4";
                acLabel.Text = "14";
                profLabel.Text = "+2";
                hpLabel.Text = "116-130";
                attackBLabel.Text = "+5";
                damageLabel.Text = "27-32";
                saveThrowLabel.Text = "14";
                expLabel.Text = "1,100";
            }
            // 5
            if (comboBox3.SelectedIndex == 8)
            {
                lvlLabel.Text = "5";
                acLabel.Text = "15";
                profLabel.Text = "+3";
                hpLabel.Text = "131-145";
                attackBLabel.Text = "+6";
                damageLabel.Text = "33-38";
                saveThrowLabel.Text = "15";
                expLabel.Text = "1,800";
            }
            // 6
            if (comboBox3.SelectedIndex == 9)
            {
                lvlLabel.Text = "6";
                acLabel.Text = "15";
                profLabel.Text = "+3";
                hpLabel.Text = "146-160";
                attackBLabel.Text = "+6";
                damageLabel.Text = "39-44";
                saveThrowLabel.Text = "15";
                expLabel.Text = "2,300";
            }
            // 7
            if (comboBox3.SelectedIndex == 10)
            {
                lvlLabel.Text = "7";
                acLabel.Text = "15";
                profLabel.Text = "+3";
                hpLabel.Text = "161-175";
                attackBLabel.Text = "+6";
                damageLabel.Text = "45-50";
                saveThrowLabel.Text = "15";
                expLabel.Text = "2,900";
            }
            // 8
            if (comboBox3.SelectedIndex == 11)
            {
                lvlLabel.Text = "8";
                acLabel.Text = "16";
                profLabel.Text = "+3";
                hpLabel.Text = "176-190";
                attackBLabel.Text = "+7";
                damageLabel.Text = "51-56";
                saveThrowLabel.Text = "16";
                expLabel.Text = "3,900";
            }
            // 9
            if (comboBox3.SelectedIndex == 12)
            {
                lvlLabel.Text = "9";
                acLabel.Text = "16";
                profLabel.Text = "+4";
                hpLabel.Text = "191-205";
                attackBLabel.Text = "+7";
                damageLabel.Text = "57-62";
                saveThrowLabel.Text = "16";
                expLabel.Text = "5,000";
                
            }
            // 10
            if (comboBox3.SelectedIndex == 13)
            {
                lvlLabel.Text = "10";
                acLabel.Text = "17";
                profLabel.Text = "+4";
                hpLabel.Text = "206-220";
                attackBLabel.Text = "+7";
                damageLabel.Text = "63-68";
                saveThrowLabel.Text = "16";
                expLabel.Text = "5,900";
            }
            // 11
            if (comboBox3.SelectedIndex == 14)
            {
                lvlLabel.Text = "11";
                acLabel.Text = "17";
                profLabel.Text = "+4";
                hpLabel.Text = "221-235";
                attackBLabel.Text = "+8";
                damageLabel.Text = "69-74";
                saveThrowLabel.Text = "17";
                expLabel.Text = "7,200";
            }
            // 12
            if (comboBox3.SelectedIndex == 15)
            {
                lvlLabel.Text = "12";
                acLabel.Text = "17";
                profLabel.Text = "+4";
                hpLabel.Text = "236-250";
                attackBLabel.Text = "+8";
                damageLabel.Text = "75-80";
                saveThrowLabel.Text = "17";
                expLabel.Text = "8,400";
            }
            // 13
            if (comboBox3.SelectedIndex == 16)
            {
                lvlLabel.Text = "13";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "251-265";
                attackBLabel.Text = "+8";
                damageLabel.Text = "81-86";
                saveThrowLabel.Text = "18";
                expLabel.Text = "10,000";
            }
            // 14
            if (comboBox3.SelectedIndex == 17)
            {
                lvlLabel.Text = "14";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "266-280";
                attackBLabel.Text = "+8";
                damageLabel.Text = "87-92";
                saveThrowLabel.Text = "18";
                expLabel.Text = "11,500";
            }
            // 15
            if (comboBox3.SelectedIndex == 18)
            {
                lvlLabel.Text = "15";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "281-295";
                attackBLabel.Text = "+8";
                damageLabel.Text = "93-98";
                saveThrowLabel.Text = "18";
                expLabel.Text = "13,000";
            }
            // 16
            if (comboBox3.SelectedIndex == 19)
            {
                lvlLabel.Text = "16";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "296-310";
                attackBLabel.Text = "+9";
                damageLabel.Text = "99-104";
                saveThrowLabel.Text = "18";
                expLabel.Text = "15,000";
            }
            // 17
            if (comboBox3.SelectedIndex == 20)
            {
                lvlLabel.Text = "17";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "311-325";
                attackBLabel.Text = "+10";
                damageLabel.Text = "105-110";
                saveThrowLabel.Text = "19";
                expLabel.Text = "18,000";
            }
            // 18 
            if (comboBox3.SelectedIndex == 21)
            {
                lvlLabel.Text = "18";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "326-340";
                attackBLabel.Text = "+10";
                damageLabel.Text = "111-116";
                saveThrowLabel.Text = "19";
                expLabel.Text = "20,000";
            }
            // 19
            if (comboBox3.SelectedIndex == 22)
            {
                lvlLabel.Text = "19";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "341-355";
                attackBLabel.Text = "+10";
                damageLabel.Text = "117-122";
                saveThrowLabel.Text = "19";
                expLabel.Text = "22,000";
            }
            // 20
            if (comboBox3.SelectedIndex == 23)
            {
                lvlLabel.Text = "20";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "356-400";
                attackBLabel.Text = "+10";
                damageLabel.Text = "123-140";
                saveThrowLabel.Text = "19";
                expLabel.Text = "25,000";
            }
            // 21
            if (comboBox3.SelectedIndex == 24)
            {
                lvlLabel.Text = "21";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "401-445";
                attackBLabel.Text = "+11";
                damageLabel.Text = "141-158";
                saveThrowLabel.Text = "20";
                expLabel.Text = "33,000";
            }
            // 22
            if (comboBox3.SelectedIndex == 25)
            {
                lvlLabel.Text = "22";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "446-490";
                attackBLabel.Text = "+11";
                damageLabel.Text = "159-176";
                saveThrowLabel.Text = "20";
                expLabel.Text = "41,000";
            }
            // 23
            if (comboBox3.SelectedIndex == 26)
            {
                lvlLabel.Text = "23";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "491-535";
                attackBLabel.Text = "+11";
                damageLabel.Text = "177-194";
                saveThrowLabel.Text = "20";
                expLabel.Text = "50,000";
            }
            // 24
            if (comboBox3.SelectedIndex == 27)
            {
                lvlLabel.Text = "24";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "536-580";
                attackBLabel.Text = "+12";
                damageLabel.Text = "195-212";
                saveThrowLabel.Text = "21";
                expLabel.Text = "62,000";
            }
            // 25
            if (comboBox3.SelectedIndex == 28)
            {
                lvlLabel.Text = "25";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "581-625";
                attackBLabel.Text = "+12";
                damageLabel.Text = "213-230";
                saveThrowLabel.Text = "21";
                expLabel.Text = "75,000";
            }
            // 26
            if (comboBox3.SelectedIndex == 29)
            {
                lvlLabel.Text = "26";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "626-670";
                attackBLabel.Text = "+12";
                damageLabel.Text = "231-248";
                saveThrowLabel.Text = "21";
                expLabel.Text = "90,000";
            }
            // 27
            if (comboBox3.SelectedIndex == 30)
            {
                lvlLabel.Text = "27";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "671-715";
                attackBLabel.Text = "+13";
                damageLabel.Text = "249-266";
                saveThrowLabel.Text = "22";
                expLabel.Text = "105,000";
            }
            // 28
            if (comboBox3.SelectedIndex == 31)
            {
                lvlLabel.Text = "28";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "716-760";
                attackBLabel.Text = "+13";
                damageLabel.Text = "267-284";
                saveThrowLabel.Text = "22";
                expLabel.Text = "120,000";
            }
            // 29
            if (comboBox3.SelectedIndex == 32)
            {
                lvlLabel.Text = "29";
                acLabel.Text = "19";
                profLabel.Text = "+9";
                hpLabel.Text = "761-805";
                attackBLabel.Text = "+13";
                damageLabel.Text = "285-302";
                saveThrowLabel.Text = "22";
                expLabel.Text = "135,000";
            }
            // 30
            if (comboBox3.SelectedIndex == 33)
            {
                lvlLabel.Text = "30";
                acLabel.Text = "19";
                profLabel.Text = "+9";
                hpLabel.Text = "806-850";
                attackBLabel.Text = "+14";
                damageLabel.Text = "303-320";
                saveThrowLabel.Text = "23";
                expLabel.Text = "155,000";
            }


        }

        private void miscCreateComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
        //-- A --
            // Ape
            if(miscCreateComboBox.SelectedIndex == 0)
            {
                miscCreatureLabel.Text = "317)";
            }
            // Awakened Shrub
            if(miscCreateComboBox.SelectedIndex == 1)
            {
                miscCreatureLabel.Text = "317)";
            }
            // Awakened Tree
            if(miscCreateComboBox.SelectedIndex == 2)
            {
                miscCreatureLabel.Text = "317)";
            }
            // Axe Beak
            if(miscCreateComboBox.SelectedIndex == 3)
            {
                miscCreatureLabel.Text = "317)";
            }
        //-- B --
            // Baboon
            if(miscCreateComboBox.SelectedIndex == 4)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Badger
            if(miscCreateComboBox.SelectedIndex == 5)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Bat
            if(miscCreateComboBox.SelectedIndex == 6)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Black Bear
            if(miscCreateComboBox.SelectedIndex == 7)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Blink Dog
            if(miscCreateComboBox.SelectedIndex == 8)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Blood Hawk
            if(miscCreateComboBox.SelectedIndex == 9)
            {
                miscCreatureLabel.Text = "319)";
            }
            // Boar
            if(miscCreateComboBox.SelectedIndex == 10)
            {
                miscCreatureLabel.Text = "319)";
            }
            // Brown Bear
            if(miscCreateComboBox.SelectedIndex == 11)
            {
                miscCreatureLabel.Text = "319)";
            }
        //-- C --
            // Camel
            if(miscCreateComboBox.SelectedIndex == 12)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Cat
            if(miscCreateComboBox.SelectedIndex == 13)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Constrictor Snake
            if(miscCreateComboBox.SelectedIndex == 14)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Crab
            if(miscCreateComboBox.SelectedIndex == 15)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Crocodile
            if(miscCreateComboBox.SelectedIndex == 16)
            {
                miscCreatureLabel.Text = "320)";
            }
        //-- D --
            // Death Dog
            if(miscCreateComboBox.SelectedIndex == 17)
            {
                miscCreatureLabel.Text = "321)";
            }
            // Deer
            if(miscCreateComboBox.SelectedIndex == 18)
            {
                miscCreatureLabel.Text = "321)";
            }
            // Dire Wolf
            if(miscCreateComboBox.SelectedIndex == 19)
            {
                miscCreatureLabel.Text = "321)";
            }
            // Draft Horse
            if(miscCreateComboBox.SelectedIndex == 20)
            {
                miscCreatureLabel.Text = "321)";
            }
        //-- E --
            // Eagle
            if(miscCreateComboBox.SelectedIndex == 21)
            {
                miscCreatureLabel.Text = "322)";
            }
            // Elephant
            if(miscCreateComboBox.SelectedIndex == 22)
            {
                miscCreatureLabel.Text = "322)";
            }
            // Elk
            if(miscCreateComboBox.SelectedIndex == 23)
            {
                miscCreatureLabel.Text = "322)";
            }
        //-- F --
            // Flying Snake
            if(miscCreateComboBox.SelectedIndex == 24)
            {
                miscCreatureLabel.Text = "322)";
            }
            // Frog
            if(miscCreateComboBox.SelectedIndex == 25)
            {
                miscCreatureLabel.Text = "322)";
            }
       //-- G --
            // Giant Ape
            if(miscCreateComboBox.SelectedIndex == 26)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Badger
            if(miscCreateComboBox.SelectedIndex == 27)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Bat
            if(miscCreateComboBox.SelectedIndex == 28)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Boar
            if(miscCreateComboBox.SelectedIndex == 29)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Centipede
            if(miscCreateComboBox.SelectedIndex == 30)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Constrictor Snake
            if(miscCreateComboBox.SelectedIndex == 31)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Crab
            if(miscCreateComboBox.SelectedIndex == 32)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Crocodile
            if(miscCreateComboBox.SelectedIndex == 33)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Eagle
            if(miscCreateComboBox.SelectedIndex == 36)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Elk
            if(miscCreateComboBox.SelectedIndex == 37)
            {
                miscCreatureLabel.Text = "325)";
            }
            // Giant Fire Beetle
            if(miscCreateComboBox.SelectedIndex == 38)
            {
                miscCreatureLabel.Text = "325)";
            }
            // Giant Frog
            if(miscCreateComboBox.SelectedIndex== 39)
            {
                miscCreatureLabel.Text = "325)";
            }
            // Giant Goat
            if(miscCreateComboBox.SelectedIndex == 40)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Hyena
            if(miscCreateComboBox.SelectedIndex == 41)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Lizard
            if(miscCreateComboBox.SelectedIndex == 42)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Octopus
            if(miscCreateComboBox.SelectedIndex == 43)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Owl
            if(miscCreateComboBox.SelectedIndex == 44)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Poisonous Snake
            if(miscCreateComboBox.SelectedIndex == 45)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Rat
            if(miscCreateComboBox.SelectedIndex == 46)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Scorpion
            if(miscCreateComboBox.SelectedIndex == 47)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Sea Horse
            if(miscCreateComboBox.SelectedIndex == 48)
            {
                miscCreatureLabel.Text = "328)";
            }
            // Giant Shark
            if(miscCreateComboBox.SelectedIndex == 49)
            {
                miscCreatureLabel.Text = "328)";
            }
            // Giant Spider
            if(miscCreateComboBox.SelectedIndex == 50)
            {
                miscCreatureLabel.Text = "328)";
            }
            // Giant Toad
            if(miscCreateComboBox.SelectedIndex == 51)
            {
                miscCreatureLabel.Text = "329)";
            }
            // Giant Vulture
            if(miscCreateComboBox.SelectedIndex == 52)
            {
                miscCreatureLabel.Text = "329)";
            }
            // Giant Wasp
            if(miscCreateComboBox.SelectedIndex == 53)
            {
                miscCreatureLabel.Text = "329)";
            }
            // Giant Weasel
            if(miscCreateComboBox.SelectedIndex == 54)
            {
                miscCreatureLabel.Text = "329)";
            }
            //Giant Wolf Spider
            if(miscCreateComboBox.SelectedIndex == 55)
            {
                miscCreatureLabel.Text = "330)";
            }
            // Goat
            if(miscCreateComboBox.SelectedIndex == 56)
            {
                miscCreatureLabel.Text = "330)";
            }
        //-- H --
            // Hawk
            if(miscCreateComboBox.SelectedIndex == 57)
            {
                miscCreatureLabel.Text = "330)";
            }
            // Hunter Shark
            if(miscCreateComboBox.SelectedIndex == 58)
            {
                miscCreatureLabel.Text = "330)";
            }
            // Hyena
            if(miscCreateComboBox.SelectedIndex == 59)
            {
                miscCreatureLabel.Text = "331)";
            }
        //-- J --
            // Jackal
            if(miscCreateComboBox.SelectedIndex == 60)
            {
                miscCreatureLabel.Text = "331)";
            }
        //-- K --
            // Killer Whale
            if(miscCreateComboBox.SelectedIndex == 61)
            {
                miscCreatureLabel.Text = "331)";
            }
        //-- L --
            // Lion
            if(miscCreateComboBox.SelectedIndex == 62)
            {
                miscCreatureLabel.Text = "331)";
            }
            // Lizard
            if(miscCreateComboBox.SelectedIndex == 63)
            {
                miscCreatureLabel.Text = "332)";
            }
        //-- M --
            // Mammoth
            if(miscCreateComboBox.SelectedIndex == 64)
            {
                miscCreatureLabel.Text = "332)";
            }
            // Mastiff
            if(miscCreateComboBox.SelectedIndex == 65)
            {
                miscCreatureLabel.Text = "332)";
            }
            // Mule
            if(miscCreateComboBox.SelectedIndex == 66)
            {
                miscCreatureLabel.Text = "333)";
            }
        //-- O --
            // Octopus
            if(miscCreateComboBox.SelectedIndex == 67)
            {
                miscCreatureLabel.Text = "333)";
            }
            // Owl
            if(miscCreateComboBox.SelectedIndex == 68)
            {
                miscCreatureLabel.Text = "333)";
            }
        //-- P --
            // Panther
            if(miscCreateComboBox.SelectedIndex == 69)
            {
                miscCreatureLabel.Text = "333)";
            }
            // Phase Spider
            if(miscCreateComboBox.SelectedIndex == 70)
            {
                miscCreatureLabel.Text = "334)";
            }
            // Poisonous Snake
            if(miscCreateComboBox.SelectedIndex == 71)
            {
                miscCreatureLabel.Text = "334)";
            }
            // Polar Bear
            if(miscCreateComboBox.SelectedIndex == 72)
            {
                miscCreatureLabel.Text = "334)";
            }
            // Pony
            if(miscCreateComboBox.SelectedIndex == 73)
            {
                miscCreatureLabel.Text = "335)";
            }
        //-- Q --
            // Quipper
            if(miscCreateComboBox.SelectedIndex == 74)
            {
                miscCreatureLabel.Text = "335)";
            }
        //-- R --
            // Rat
            if(miscCreateComboBox.SelectedIndex == 75)
            {
                miscCreatureLabel.Text = "335)";
            }
            // Raven
            if(miscCreateComboBox.SelectedIndex == 76)
            {
                miscCreatureLabel.Text = "335)";
            }
            // Reef Shark
            if(miscCreateComboBox.SelectedIndex == 77)
            {
                miscCreatureLabel.Text = "336)";
            }
            // Rhinoceros
            if(miscCreateComboBox.SelectedIndex == 78)
            {
                miscCreatureLabel.Text = "336)";
            }
            // Riding Horse
            if(miscCreateComboBox.SelectedIndex == 79)
            {
                miscCreatureLabel.Text = "336)";
            }
        // -- S --
            // Saber-Toother Tiger
            if(miscCreateComboBox.SelectedIndex == 80)
            {
                miscCreatureLabel.Text = "336)";
            }
            // Scorpion
            if(miscCreateComboBox.SelectedIndex == 81)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Sea Horse
            if(miscCreateComboBox.SelectedIndex == 82)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Spider
            if(miscCreateComboBox.SelectedIndex == 83)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Swarm of Bats
            if(miscCreateComboBox.SelectedIndex == 84)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Swarm of Insects
            if(miscCreateComboBox.SelectedIndex == 85)
            {
                miscCreatureLabel.Text = "338)";
            }
            // Swarm of Poisonous Snakes
            if(miscCreateComboBox.SelectedIndex == 86)
            {
                miscCreatureLabel.Text = "338)";
            }
            // Swarm of Quippers
            if(miscCreateComboBox.SelectedIndex == 87)
            {
                miscCreatureLabel.Text = "338)";
            }
            // Swarm of Rats
            if(miscCreateComboBox.SelectedIndex == 88)
            {
                miscCreatureLabel.Text = "339)";
            }
            // Swarm of Ravens
            if(miscCreateComboBox.SelectedIndex == 89)
            {
                miscCreatureLabel.Text = "339)";
            }
        //-- T --
            // Tiger
            if(miscCreateComboBox.SelectedIndex == 90)
            {
                miscCreatureLabel.Text = "339)";
            }
            //-- V --
            // Vulture
            if (miscCreateComboBox.SelectedIndex == 91)
            {
                miscCreatureLabel.Text = "339)";
            }
        //-- W --
            // Warhorse
            if(miscCreateComboBox.SelectedIndex == 92)
                {
                    miscCreatureLabel.Text = "340)";
                }
            // Weasel
            if(miscCreateComboBox.SelectedIndex == 93)
                {
                    miscCreatureLabel.Text = "340)";
                }
            // Winter Wolf
            if(miscCreateComboBox.SelectedIndex == 94)
                {
                    miscCreatureLabel.Text = "340)";
                }
            // Wolf
            if(miscCreateComboBox.SelectedIndex == 95)
                {
                    miscCreatureLabel.Text = "341)";
                }
            // Worg
            if(miscCreateComboBox.SelectedIndex == 96)
                {
                    miscCreatureLabel.Text = "341)";
                }

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void npcComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {// Npc Characters
          // -- A --
            // Acolyte
            if(npcComboBox.SelectedIndex == 0)
            {
                npcLabel.Text = "342)";
            }
            // Archmage
            if(npcComboBox.SelectedIndex == 1)
            {
                npcLabel.Text = "342)";
            }
            // Assassin
            if(npcComboBox.SelectedIndex == 2)
            {
                npcLabel.Text = "343)";
            }
        //-- B --
            // Bandit
            if(npcComboBox.SelectedIndex == 3)
            {
                npcLabel.Text = "343)";
            }
            // Bandit Captain
            if(npcComboBox.SelectedIndex == 4)
            {
                npcLabel.Text = "344)";
            }
            // Berserker
            if(npcComboBox.SelectedIndex == 5)
            {
                npcLabel.Text = "344)";
            }
       //-- C --
            // Commoner
            if(npcComboBox.SelectedIndex == 6)
            {
                npcLabel.Text = "345)";
            }
            // Cultist
            if(npcComboBox.SelectedIndex == 7)
            {
                npcLabel.Text = "345)";
            }
            // Cult Fanatic
            if(npcComboBox.SelectedIndex == 8)
            {
                npcLabel.Text = "345)";
            }
        //-- D --
            // Druid
            if(npcComboBox.SelectedIndex == 9)
            {
                npcLabel.Text = "346)";
            }
       //-- G --
            // Gladiator
            if(npcComboBox.SelectedIndex == 10)
            {
                npcLabel.Text = "346)";
            }
            // Guard
            if(npcComboBox.SelectedIndex == 11)
            {
                npcLabel.Text = "347)";
            }
       //-- K --
            // Knight
            if(npcComboBox.SelectedIndex == 12)
            {
                npcLabel.Text = "347)";
            }
       //-- M --
            // Mage
            if(npcComboBox.SelectedIndex == 13)
            {
                npcLabel.Text = "347)";
            }
       //-- N --
            // Noble
            if(npcComboBox.SelectedIndex == 14)
            {
                npcLabel.Text = "348)";
            }
       //-- P --
            // Priest
            if(npcComboBox.SelectedIndex == 15)
            {
                npcLabel.Text = "348)";
            }
       //-- S --
            // Scout
            if(npcComboBox.SelectedIndex == 16)
            {
                npcLabel.Text = "349)";
            }
            // Spy
            if(npcComboBox.SelectedIndex == 17)
            {
                npcLabel.Text = "349)";
            }
        //-- T --
            // Thug
            if(npcComboBox.SelectedIndex == 18)
            {
                npcLabel.Text = "350)";
            }
            // Tribal Warrior
            if(npcComboBox.SelectedIndex == 19)
            {
                npcLabel.Text = "350)";
            }
        //-- V --
            // Veteran
            if(npcComboBox.SelectedIndex == 20)
            {
                npcLabel.Text = "350)";
            }

        }

        private void angelSubcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Deva
            if (angelSubcomboBox.SelectedIndex == 0)
            {
                angelRightLabel.Text = "16)";

            }
            if (angelSubcomboBox.SelectedIndex == 1)
            {
                angelRightLabel.Text = "17)";
            }
            if (angelSubcomboBox.SelectedIndex == 2)
            {
                angelRightLabel.Text = "18)";
            }
        }

        private void animatedObjectcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(animatedObjectcomboBox.SelectedIndex == 0)
            {
                animatedObjectRightLabel.Text = "19)";
            }
            if(animatedObjectcomboBox.SelectedIndex == 1)
            {
                animatedObjectRightLabel.Text = "20)";
            }
            if(animatedObjectcomboBox.SelectedIndex == 2)
            {
                animatedObjectRightLabel.Text = "20)";
            }

        }

        private void beHoldercomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(beHoldercomboBox.SelectedIndex == 0)
            {
                beholderRightLabel.Text = "28)";
            }
            if(beHoldercomboBox.SelectedIndex == 1)
            {
                beholderRightLabel.Text = "29)";
            }
            if(beHoldercomboBox.SelectedIndex == 2)
            {
                beholderRightLabel.Text = "30)";
            }
        }

        private void blightComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(blightComboBox.SelectedIndex == 0)
            {
                blightRightLabel.Text = "32)";
            }
            if (blightComboBox.SelectedIndex == 1)
            {
                blightRightLabel.Text = "32)";
            }
            if (blightComboBox.SelectedIndex == 2)
            {
                blightRightLabel.Text = "32)";
            }
        }

        private void bugBearComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(bugBearComboBox.SelectedIndex == 0)
            {
                bugbearRightLabel.Text = "33)";
            }
            if(bugBearComboBox.SelectedIndex == 0)
            {
                bugbearRightLabel.Text = "33)";
            }
        }

        private void demonComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(demonComboBox.SelectedIndex == 0)
            {
                demonRightLabel.Text = "55)";
            }
            if (demonComboBox.SelectedIndex == 1)
            {
                demonRightLabel.Text = "56)";
            }
            if (demonComboBox.SelectedIndex == 2)
            {
                demonRightLabel.Text = "57)";
            }
            if (demonComboBox.SelectedIndex == 3)
            {
                demonRightLabel.Text = "57)";
            }
            if (demonComboBox.SelectedIndex == 4)
            {
                demonRightLabel.Text = "58)";
            }
            if (demonComboBox.SelectedIndex == 5)
            {
                demonRightLabel.Text = "59)";
            }
            if (demonComboBox.SelectedIndex == 6)
            {
                demonRightLabel.Text = "60)";
            }
            if (demonComboBox.SelectedIndex == 7)
            {
                demonRightLabel.Text = "60)";
            }
            if (demonComboBox.SelectedIndex == 8)
            {
                demonRightLabel.Text = "61)";
            }
            if (demonComboBox.SelectedIndex == 9)
            {
                demonRightLabel.Text = "62)";
            }
            if (demonComboBox.SelectedIndex == 10)
            {
                demonRightLabel.Text = "63)";
            }
            if (demonComboBox.SelectedIndex == 11)
            {
                demonRightLabel.Text = "64)";
            }
            if (demonComboBox.SelectedIndex == 12)
            {
                demonRightLabel.Text = "64)";
            }
            if (demonComboBox.SelectedIndex == 13)
            {
                demonRightLabel.Text = "65)";
            }
        }

        private void devilComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(devilComboBox.SelectedIndex == 0)
            {
                devilRightLabel.Text = "70)";
            }
            if (devilComboBox.SelectedIndex == 1)
            {
                devilRightLabel.Text = "70)";
            }
            if (devilComboBox.SelectedIndex == 2)
            {
                devilRightLabel.Text = "71)";
            }
            if (devilComboBox.SelectedIndex == 3)
            {
                devilRightLabel.Text = "72)";
            }
            if (devilComboBox.SelectedIndex == 4)
            {
                devilRightLabel.Text = "73)";
            }
            if (devilComboBox.SelectedIndex == 5)
            {
                devilRightLabel.Text = "74)";
            }
            if (devilComboBox.SelectedIndex == 6)
            {
                devilRightLabel.Text = "75)";
            }
            if (devilComboBox.SelectedIndex == 7)
            {
                devilRightLabel.Text = "76)";
            }
            if (devilComboBox.SelectedIndex == 8)
            {
                devilRightLabel.Text = "76)";
            }
            if (devilComboBox.SelectedIndex == 9)
            {
                devilRightLabel.Text = "77)";
            }
            if (devilComboBox.SelectedIndex == 10)
            {
                devilRightLabel.Text = "78)";
            }
        }

        private void dinoComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(dinoComboBox.SelectedIndex == 0)
            {
                dinoRightLabel.Text = "79)";
            }
            if (dinoComboBox.SelectedIndex == 1)
            {
                dinoRightLabel.Text = "79)";
            }
            if (dinoComboBox.SelectedIndex == 2)
            {
                dinoRightLabel.Text = "80)";
            }
            if (dinoComboBox.SelectedIndex == 3)
            {
                dinoRightLabel.Text = "80)";
            }
            if (dinoComboBox.SelectedIndex == 4)
            {
                dinoRightLabel.Text = "80)";
            }
            if (dinoComboBox.SelectedIndex == 5)
            {
                dinoRightLabel.Text = "80)";
            }
        }

        private void dragon1ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(dragon1ComboBox.SelectedIndex == 0)
            {
                dragRightLabel.Text = "87)";
            }
            if (dragon1ComboBox.SelectedIndex == 1)
            {
                dragRightLabel.Text = "88)";
            }
            if (dragon1ComboBox.SelectedIndex == 2)
            {
                dragRightLabel.Text = "88)";
            }
            if (dragon1ComboBox.SelectedIndex == 3)
            {
                dragRightLabel.Text = "88)";
            }
            if (dragon1ComboBox.SelectedIndex == 4)
            {
                dragRightLabel.Text = "90)";
            }
            if (dragon1ComboBox.SelectedIndex == 5)
            {
                dragRightLabel.Text = "91)";
            }
            if (dragon1ComboBox.SelectedIndex == 6)
            {
                dragRightLabel.Text = "91)";
            }
            if (dragon1ComboBox.SelectedIndex == 7)
            {
                dragRightLabel.Text = "91)";
            }
            if (dragon1ComboBox.SelectedIndex == 8)
            {
                dragRightLabel.Text = "93)";
            }
            if (dragon1ComboBox.SelectedIndex == 9)
            {
                dragRightLabel.Text = "94)";
            }
            if (dragon1ComboBox.SelectedIndex == 10)
            {
                dragRightLabel.Text = "94)";
            }
            if (dragon1ComboBox.SelectedIndex == 11)
            {
                dragRightLabel.Text = "95)";
            }
            if (dragon1ComboBox.SelectedIndex == 12)
            {
                dragRightLabel.Text = "97)";
            }
            if (dragon1ComboBox.SelectedIndex == 13)
            {
                dragRightLabel.Text = "98)";
            }
            if (dragon1ComboBox.SelectedIndex == 14)
            {
                dragRightLabel.Text = "98)";
            }
            if (dragon1ComboBox.SelectedIndex == 15)
            {
                dragRightLabel.Text = "98)";
            }
            if (dragon1ComboBox.SelectedIndex == 16)
            {
                dragRightLabel.Text = "100)";
            }
            if (dragon1ComboBox.SelectedIndex == 17)
            {
                dragRightLabel.Text = "101)";
            }
            if (dragon1ComboBox.SelectedIndex == 18)
            {
                dragRightLabel.Text = "101)";
            }
            if (dragon1ComboBox.SelectedIndex == 19)
            {
                dragRightLabel.Text = "102)";
            }
            if (dragon1ComboBox.SelectedIndex == 20)
            {
                dragRightLabel.Text = "104)";
            }
            if (dragon1ComboBox.SelectedIndex == 21)
            {
                dragRightLabel.Text = "105)";
            }
            if (dragon1ComboBox.SelectedIndex == 22)
            {
                dragRightLabel.Text = "105)";
            }
            if (dragon1ComboBox.SelectedIndex == 23)
            {
                dragRightLabel.Text = "106)";
            }
            if (dragon1ComboBox.SelectedIndex == 24)
            {
                dragRightLabel.Text = "107)";
            }
            if (dragon1ComboBox.SelectedIndex == 25)
            {
                dragRightLabel.Text = "108)";
            }
            if (dragon1ComboBox.SelectedIndex == 26)
            {
                dragRightLabel.Text = "108)";
            }
            if (dragon1ComboBox.SelectedIndex == 27)
            {
                dragRightLabel.Text = "109)";
            }
            if (dragon1ComboBox.SelectedIndex == 28)
            {
                dragRightLabel.Text = "110)";
            }
            if (dragon1ComboBox.SelectedIndex == 29)
            {
                dragRightLabel.Text = "111)";
            }
            if (dragon1ComboBox.SelectedIndex == 30)
            {
                dragRightLabel.Text = "111)";
            }
            if (dragon1ComboBox.SelectedIndex == 31)
            {
                dragRightLabel.Text = "112)";
            }
            if (dragon1ComboBox.SelectedIndex == 32)
            {
                dragRightLabel.Text = "113)";
            }
            if (dragon1ComboBox.SelectedIndex == 33)
            {
                dragRightLabel.Text = "114)";
            }
            if (dragon1ComboBox.SelectedIndex == 34)
            {
                dragRightLabel.Text = "115)";
            }
            if (dragon1ComboBox.SelectedIndex == 35)
            {
                dragRightLabel.Text = "115)";
            }
            if (dragon1ComboBox.SelectedIndex == 36)
            {
                dragRightLabel.Text = "116)";
            }
            if (dragon1ComboBox.SelectedIndex == 37)
            {
                dragRightLabel.Text = "117)";
            }
            if (dragon1ComboBox.SelectedIndex == 38)
            {
                dragRightLabel.Text = "118)";
            }
            if (dragon1ComboBox.SelectedIndex == 39)
            {
                dragRightLabel.Text = "118)";
            }
        }

        private void elementsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(elementsComboBox.SelectedIndex == 0)
            {
                elemRightLabel.Text = "124)";
            }
            if(elementsComboBox.SelectedIndex == 1)
            {
                elemRightLabel.Text = "124)";
            }
            if(elementsComboBox.SelectedIndex == 2)
            {
                elemRightLabel.Text = "125)";
            }
            if(elementsComboBox.SelectedIndex == 3)
            {
                elemRightLabel.Text = "125)";
            }
        }

        private void drowComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(drowComboBox.SelectedIndex == 0)
            {
                drowRightLabel.Text = "128)";
            }
            if(drowComboBox.SelectedIndex == 1)
            {
                drowRightLabel.Text = "128)";
            }
            if(drowComboBox.SelectedIndex == 2)
            {
                drowRightLabel.Text = "129)";
            }
            if(drowComboBox.SelectedIndex == 3)
            {
                drowRightLabel.Text = "129)";
            }
        }

        private void fungiComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(fungiComboBox.SelectedIndex == 0)
            {
                fungiRightLabel.Text = "138)";
            }
            if(fungiComboBox.SelectedIndex == 1)
            {
                fungiRightLabel.Text = "138)";
            }
            if(fungiComboBox.SelectedIndex == 2)
            {
                fungiRightLabel.Text = "138)";
            }
        }

        private void genieComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(genieComboBox.SelectedIndex == 0)
            {
                genieRightLabel.Text = "143)";
            }
            if(genieComboBox.SelectedIndex == 1)
            {
                genieRightLabel.Text = "144)";
            }
            if(genieComboBox.SelectedIndex == 2)
            {
                genieRightLabel.Text = "145)";
            }
            if(genieComboBox.SelectedIndex == 3)
            {
                genieRightLabel.Text = "146)";
            }
        }

        private void ghoulComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ghoulComboBox.SelectedIndex == 0)
            {
                ghoulRightLabel.Text = "148)";
            }
            if(ghoulComboBox.SelectedIndex == 1)
            {
                ghoulRightLabel.Text = "148)";
            }
        }

        private void giantsComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(giantsComboBox.SelectedIndex == 0)
            {
                giantsRightLabel.Text = "154)";
            }
            if(giantsComboBox.SelectedIndex == 1)
            {
                giantsRightLabel.Text = "154)";
            }
            if(giantsComboBox.SelectedIndex == 2)
            {
                giantsRightLabel.Text = "155)";
            }
            if(giantsComboBox.SelectedIndex == 3)
            {
                giantsRightLabel.Text = "155)";
            }
            if(giantsComboBox.SelectedIndex == 4)
            {
                giantsRightLabel.Text = "156)";
            }
            if(giantsComboBox.SelectedIndex == 5)
            {
                giantsRightLabel.Text = "156)";
            }
        }

        private void githComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(githComboBox.SelectedIndex == 0)
            {
                githRightLabel.Text = "160)";
            }
            if(githComboBox.SelectedIndex == 1)
            {
                githRightLabel.Text = "160)";
            }
            if(githComboBox.SelectedIndex == 2)
            {
                githRightLabel.Text = "161)";
            }
            if(githComboBox.SelectedIndex == 3)
            {
                githRightLabel.Text = "161)";
            }
        }

        private void gnollComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(gnollComboBox.SelectedIndex == 0 || gnollComboBox.SelectedIndex == 1 ||gnollComboBox.SelectedIndex == 2)
            {
                gnollRightLabel.Text = "163)";
            }
        }

        private void orcComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(orcComboBox.SelectedIndex == 0 || orcComboBox.SelectedIndex == 1)
            {
                orcRightLabel.Text = "246)";
            }
            if(orcComboBox.SelectedIndex == 2 || orcComboBox.SelectedIndex == 3)
            {
                orcRightLabel.Text = "247)";
            }
        }

        private void yetiComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(yetiComboBox.SelectedIndex == 0)
            {
                yetiRightLabel.Text = "305)";
            }
            if(yetiComboBox.SelectedIndex == 1)
            {
                yetiRightLabel.Text = "306)";
            }
        }

        private void goblinComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(goblinComboBox.SelectedIndex == 0 || goblinComboBox.SelectedIndex == 1)
            {
                goblinRightLabel.Text = "166)";
            }
        }

        private void golemComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(golemComboBox.SelectedIndex == 0)
            {
                golemRightLabel.Text = "168)";
            }
            if(golemComboBox.SelectedIndex == 1)
            {
                golemRightLabel.Text = "169)";
            }
            if(golemComboBox.SelectedIndex == 2 || golemComboBox.SelectedIndex == 3)
            {
                golemRightLabel.Text = "170)";
            }

        }

        private void grickComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(grickComboBox.SelectedIndex == 0 || grickComboBox.SelectedIndex == 1)
            {
                grickRightLabel.Text = "173)";
            }
        }

        private void hagComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(hagComboBox.SelectedIndex == 0)
            {
                hagRightLabel.Text = "177)";
            }
            if(hagComboBox.SelectedIndex == 1)
            {
                hagRightLabel.Text = "178)";
            }
            if(hagComboBox.SelectedIndex == 2)
            {
                hagRightLabel.Text = "179)";
            }

        }

        private void hobgoblinComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(hobgoblinComboBox.SelectedIndex == 0)
            {
                hobgoblinRightLabel.Text = "186)";
            }
            if(hobgoblinComboBox.SelectedIndex == 1)
            {
                hobgoblinRightLabel.Text = "186)";
            }
            if(hobgoblinComboBox.SelectedIndex == 2)
            {
                hobgoblinRightLabel.Text = "187)";
            }
        }

        private void koboldComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(koboldComboBox.SelectedIndex == 0)
            {
                koboldRightLabel.Text = "195)";
            }
            if(koboldComboBox.SelectedIndex == 1)
            {
                koboldRightLabel.Text = "195)";
            }
        }

        private void kuoComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(kuoComboBox.SelectedIndex == 0)
            {
                kuoRightLabel.Text = "199)";
            }
            if(kuoComboBox.SelectedIndex == 1|| kuoComboBox.SelectedIndex == 2)
            {
                kuoRightLabel.Text = "200)";
            }
        }

        private void lizardFolkComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lizardFolkComboBox.SelectedIndex == 0)
            {
                lizardfolkRightLabel.Text = "204)";
            }
            if(lizardFolkComboBox.SelectedIndex == 1 || lizardFolkComboBox.SelectedIndex == 2)
            {
                lizardfolkRightLabel.Text = "205)";
            }
        }

        private void lycanthropeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(lycanthropeComboBox.SelectedIndex == 0)
            {
                lycanRightLabel.Text = "208)";
            }
            if(lycanthropeComboBox.SelectedIndex == 1 || lycanthropeComboBox.SelectedIndex ==2)
            {
                lycanRightLabel.Text = "209)";
            }
            if(lycanthropeComboBox.SelectedIndex == 3)
            {
                lycanRightLabel.Text = "210)";
            }
            if(lycanthropeComboBox.SelectedIndex == 4)
            {
                lycanRightLabel.Text = "211)";
            }
        }

        private void mephitesComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(mephitesComboBox.SelectedIndex == 0 || mephitesComboBox.SelectedIndex == 1)
            {
                mephitRightLabel.Text = "215)";
            }
            if(mephitesComboBox.SelectedIndex == 2 || mephitesComboBox.SelectedIndex == 3)
            {
                mephitRightLabel.Text = "216)";
            }
            if(mephitesComboBox.SelectedIndex == 4 || mephitesComboBox.SelectedIndex == 4)
            {
                mephitRightLabel.Text = "217)";
            }
        }

        private void mondroneComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(mondroneComboBox.SelectedIndex == 0)
            {
                modroneRightLabel.Text = "224)";
            }
            if(mondroneComboBox.SelectedIndex == 1 || mondroneComboBox.SelectedIndex == 2)
            {
                modroneRightLabel.Text = "225)";
            }
            if(mondroneComboBox.SelectedIndex == 3 || mondroneComboBox.SelectedIndex == 4)
            {
                modroneRightLabel.Text = "226)";
            }
        }

        private void mummyComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(mummyComboBox.SelectedIndex == 0)
            {
                mummyRightLabel.Text = "228)";
            }
            if(mummyComboBox.SelectedIndex == 1)
            {
                mummyRightLabel.Text = "229)";
            }
        }

        private void myconoidComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(myconoidComboBox.SelectedIndex == 0 || myconoidComboBox.SelectedIndex == 1)
            {
                myconidRightLabel.Text = "230)";
            }
            if(myconoidComboBox.SelectedIndex == 2 || myconoidComboBox.SelectedIndex == 3)
            {
                myconidRightLabel.Text = "232)";
            }
        }

        private void nagaComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(nagaComboBox.SelectedIndex == 0)
            {
                nagaRightLabel.Text = "233)";
            }
            if(nagaComboBox.SelectedIndex == 1 || nagaComboBox.SelectedIndex == 2)
            {
                nagaRightLabel.Text = "234)";
            }

        }

        private void ogreComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(ogreComboBox.SelectedIndex == 0)
            {
                ogreRightLabel.Text = "237)";
            }
            if(ogreComboBox.SelectedIndex == 1)
            {
                ogreRightLabel.Text = "238)";
            }
        }

        private void oozeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(oozeComboBox.SelectedIndex == 0)
            {
                oozeRightLabel.Text = "241)";
            }
            if(oozeComboBox.SelectedIndex == 1)
            {
                oozeRightLabel.Text = "242)";
            }
            if(oozeComboBox.SelectedIndex == 2 || oozeComboBox.SelectedIndex == 3)
            {
                oozeRightLabel.Text = "243)";
            }
        }

        private void remorhazComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(remorhazComboBox.SelectedIndex == 0 || remorhazComboBox.SelectedIndex == 1)
            {
                remorhazRightLabel.Text = "258)";
            }
        }

        private void sahuaginComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(sahuaginComboBox.SelectedIndex == 0)
            {
                sahuginRightLabel.Text = "263)";
            }
            if(sahuaginComboBox.SelectedIndex == 1 || sahuaginComboBox.SelectedIndex == 2)
            {
                sahuginRightLabel.Text = "264)";
            }
        }

        private void salamanderComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(salamanderComboBox.SelectedIndex == 0)
            {
                salamanderRightLabel.Text = "265)";
            }
            if(salamanderComboBox.SelectedIndex == 1)
            {
                salamanderRightLabel.Text = "266)";
            }
        }

        private void skeletonComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(skeletonComboBox.SelectedIndex == 0)
            {
                skeletonRightLabel.Text = "272)";
            }
            if(skeletonComboBox.SelectedIndex == 1 || skeletonComboBox.SelectedIndex == 2)
            {
                skeletonRightLabel.Text = "273)";
            }
        }

        private void slaadiComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(slaadiComboBox.SelectedIndex == 0 || slaadiComboBox.SelectedIndex == 1 || slaadiComboBox.SelectedIndex == 2)
            {
                slaadiRightLabel.Text = "276)";
            }
            if(slaadiComboBox.SelectedIndex == 3 || slaadiComboBox.SelectedIndex == 4)
            {
                slaadiRightLabel.Text = "277)";
            }
            if(slaadiComboBox.SelectedIndex == 5)
            {
                slaadiRightLabel.Text = "278)";
            }
        }

        private void sphinxesComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(sphinxesComboBox.SelectedIndex == 0)
            {
                sphinxRightLabel.Text = "281)";
            }
            if(sphinxesComboBox.SelectedIndex == 1)
            {
                sphinxRightLabel.Text = "282)";
            }
        }

        private void vampireComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(vampireComboBox.SelectedIndex == 0)
            {
                vampireRightLabel.Text = "297)";
            }
            if(vampireComboBox.SelectedIndex == 1)
            {
                vampireRightLabel.Text = "298)";
            }
        }

        private void yuanTiComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(yuanTiComboBox.SelectedIndex == 0)
            {
                yuanRightLabel.Text = "308)";
            }
            if(yuanTiComboBox.SelectedIndex == 1 || yuanTiComboBox.SelectedIndex == 2)
            {
                yuanRightLabel.Text = "309)";
            }
            if(yuanTiComboBox.SelectedIndex == 3)
            {
                yuanRightLabel.Text = "310)";
            }
        }

        private void yugolothComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(yugolothComboBox.SelectedIndex == 0 || yugolothComboBox.SelectedIndex == 1)
            {
                yugoRightLabel.Text = "313)";
            }
            if(yugolothComboBox.SelectedIndex == 2 || yugolothComboBox.SelectedIndex == 3)
            {
                yugoRightLabel.Text = "314)";
            }
        }

        private void zombieComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(zombieComboBox.SelectedIndex == 0 || zombieComboBox.SelectedIndex == 1 || zombieComboBox.SelectedIndex == 2)
            {
                zombieRightLabel.Text = "316)";
            }
        }

        private void mhpLabel_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
