﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lvlLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.acLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.profLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.hpLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.attackBLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.damageLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.saveThrowLabel = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.expLabel = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pageNumLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.miscCreateComboBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.npcComboBox = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.miscCreatureLabel = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.npcLabel = new System.Windows.Forms.Label();
            this.angelSubcomboBox = new System.Windows.Forms.ComboBox();
            this.animatedObjectcomboBox = new System.Windows.Forms.ComboBox();
            this.beHoldercomboBox = new System.Windows.Forms.ComboBox();
            this.blightComboBox = new System.Windows.Forms.ComboBox();
            this.bugBearComboBox = new System.Windows.Forms.ComboBox();
            this.demonComboBox = new System.Windows.Forms.ComboBox();
            this.devilComboBox = new System.Windows.Forms.ComboBox();
            this.dinoComboBox = new System.Windows.Forms.ComboBox();
            this.dragon1ComboBox = new System.Windows.Forms.ComboBox();
            this.elementsComboBox = new System.Windows.Forms.ComboBox();
            this.drowComboBox = new System.Windows.Forms.ComboBox();
            this.fungiComboBox = new System.Windows.Forms.ComboBox();
            this.giantsComboBox = new System.Windows.Forms.ComboBox();
            this.githComboBox = new System.Windows.Forms.ComboBox();
            this.gnollComboBox = new System.Windows.Forms.ComboBox();
            this.golemComboBox = new System.Windows.Forms.ComboBox();
            this.hagComboBox = new System.Windows.Forms.ComboBox();
            this.hobgoblinComboBox = new System.Windows.Forms.ComboBox();
            this.koboldComboBox = new System.Windows.Forms.ComboBox();
            this.kuoComboBox = new System.Windows.Forms.ComboBox();
            this.lizardFolkComboBox = new System.Windows.Forms.ComboBox();
            this.lycanthropeComboBox = new System.Windows.Forms.ComboBox();
            this.mephitesComboBox = new System.Windows.Forms.ComboBox();
            this.mondroneComboBox = new System.Windows.Forms.ComboBox();
            this.myconoidComboBox = new System.Windows.Forms.ComboBox();
            this.nagaComboBox = new System.Windows.Forms.ComboBox();
            this.ogreComboBox = new System.Windows.Forms.ComboBox();
            this.oozeComboBox = new System.Windows.Forms.ComboBox();
            this.orcComboBox = new System.Windows.Forms.ComboBox();
            this.remorhazComboBox = new System.Windows.Forms.ComboBox();
            this.sahuaginComboBox = new System.Windows.Forms.ComboBox();
            this.salamanderComboBox = new System.Windows.Forms.ComboBox();
            this.skeletonComboBox = new System.Windows.Forms.ComboBox();
            this.slaadiComboBox = new System.Windows.Forms.ComboBox();
            this.sphinxesComboBox = new System.Windows.Forms.ComboBox();
            this.vampireComboBox = new System.Windows.Forms.ComboBox();
            this.yetiComboBox = new System.Windows.Forms.ComboBox();
            this.yuanTiComboBox = new System.Windows.Forms.ComboBox();
            this.yugolothComboBox = new System.Windows.Forms.ComboBox();
            this.zombieComboBox = new System.Windows.Forms.ComboBox();
            this.angelArrowPictureBox = new System.Windows.Forms.PictureBox();
            this.angelLeftLabel = new System.Windows.Forms.Label();
            this.angelRightLabel = new System.Windows.Forms.Label();
            this.animatedObjArrowPictureBox = new System.Windows.Forms.PictureBox();
            this.animatedObjLeftLabel = new System.Windows.Forms.Label();
            this.animatedObjectRightLabel = new System.Windows.Forms.Label();
            this.beholderArrowPictureBox = new System.Windows.Forms.PictureBox();
            this.beholderLeftLabel = new System.Windows.Forms.Label();
            this.beholderRightLabel = new System.Windows.Forms.Label();
            this.blightArrowBox = new System.Windows.Forms.PictureBox();
            this.blightLeftLabel = new System.Windows.Forms.Label();
            this.blightRightLabel = new System.Windows.Forms.Label();
            this.bugbearArrowBox = new System.Windows.Forms.PictureBox();
            this.bugbearLeftLabel = new System.Windows.Forms.Label();
            this.bugbearRightLabel = new System.Windows.Forms.Label();
            this.demonArrowBox = new System.Windows.Forms.PictureBox();
            this.demonLeftLabel = new System.Windows.Forms.Label();
            this.demonRightLabel = new System.Windows.Forms.Label();
            this.devilArrowBox = new System.Windows.Forms.PictureBox();
            this.devilLeftLabel = new System.Windows.Forms.Label();
            this.devilRightLabel = new System.Windows.Forms.Label();
            this.dinoArrowBox = new System.Windows.Forms.PictureBox();
            this.dinoLeftLabel = new System.Windows.Forms.Label();
            this.dinoRightLabel = new System.Windows.Forms.Label();
            this.dragArrowBox = new System.Windows.Forms.PictureBox();
            this.dragLeftLabel = new System.Windows.Forms.Label();
            this.dragRightLabel = new System.Windows.Forms.Label();
            this.elemArrowBox = new System.Windows.Forms.PictureBox();
            this.elemLeftLabel = new System.Windows.Forms.Label();
            this.elemRightLabel = new System.Windows.Forms.Label();
            this.drowArrowBox = new System.Windows.Forms.PictureBox();
            this.drowLeftLabel = new System.Windows.Forms.Label();
            this.drowRightLabel = new System.Windows.Forms.Label();
            this.fungiArrowBox = new System.Windows.Forms.PictureBox();
            this.fungiLeftLabel = new System.Windows.Forms.Label();
            this.fungiRightLabel = new System.Windows.Forms.Label();
            this.genieComboBox = new System.Windows.Forms.ComboBox();
            this.genieArrowBox = new System.Windows.Forms.PictureBox();
            this.genieLeftLabel = new System.Windows.Forms.Label();
            this.genieRightLabel = new System.Windows.Forms.Label();
            this.ghoulComboBox = new System.Windows.Forms.ComboBox();
            this.ghoulArrowBox = new System.Windows.Forms.PictureBox();
            this.ghoulLeftLabel = new System.Windows.Forms.Label();
            this.ghoulRightLabel = new System.Windows.Forms.Label();
            this.giantsArrowBox = new System.Windows.Forms.PictureBox();
            this.giantsLeftLabel = new System.Windows.Forms.Label();
            this.giantsRightLabel = new System.Windows.Forms.Label();
            this.githArrowBox = new System.Windows.Forms.PictureBox();
            this.githLeftLabel = new System.Windows.Forms.Label();
            this.githRightLabel = new System.Windows.Forms.Label();
            this.gnollArrowBox = new System.Windows.Forms.PictureBox();
            this.gnollLeftLabel = new System.Windows.Forms.Label();
            this.gnollRightLabel = new System.Windows.Forms.Label();
            this.goblinComboBox = new System.Windows.Forms.ComboBox();
            this.goblinArrowBox = new System.Windows.Forms.PictureBox();
            this.goblinLeftLabel = new System.Windows.Forms.Label();
            this.goblinRightLabel = new System.Windows.Forms.Label();
            this.golemArrowBox = new System.Windows.Forms.PictureBox();
            this.golemLeftLabel = new System.Windows.Forms.Label();
            this.golemRightLabel = new System.Windows.Forms.Label();
            this.grickComboBox = new System.Windows.Forms.ComboBox();
            this.grickArrowBox = new System.Windows.Forms.PictureBox();
            this.grickLeftLabel = new System.Windows.Forms.Label();
            this.grickRightLabel = new System.Windows.Forms.Label();
            this.hagArrowBox = new System.Windows.Forms.PictureBox();
            this.hagLeftLabel = new System.Windows.Forms.Label();
            this.hagRightLabel = new System.Windows.Forms.Label();
            this.hobgoblinArrowBox = new System.Windows.Forms.PictureBox();
            this.hobgoblinLeftLabel = new System.Windows.Forms.Label();
            this.hobgoblinRightLabel = new System.Windows.Forms.Label();
            this.koboldArrowBox = new System.Windows.Forms.PictureBox();
            this.koboldLeftLabel = new System.Windows.Forms.Label();
            this.koboldRightLabel = new System.Windows.Forms.Label();
            this.kuoArrowBox = new System.Windows.Forms.PictureBox();
            this.kuoLeftLabel = new System.Windows.Forms.Label();
            this.kuoRightLabel = new System.Windows.Forms.Label();
            this.lizardfolkArrowBox = new System.Windows.Forms.PictureBox();
            this.lizardfolkLeftLabel = new System.Windows.Forms.Label();
            this.lizardfolkRightLabel = new System.Windows.Forms.Label();
            this.lycanArrowBox = new System.Windows.Forms.PictureBox();
            this.lycanLeftLabel = new System.Windows.Forms.Label();
            this.lycanRightLabel = new System.Windows.Forms.Label();
            this.mephitArrowBox = new System.Windows.Forms.PictureBox();
            this.mephitLeftLabel = new System.Windows.Forms.Label();
            this.mephitRightLabel = new System.Windows.Forms.Label();
            this.modroneArrowBox = new System.Windows.Forms.PictureBox();
            this.modroneLeftLabel = new System.Windows.Forms.Label();
            this.modroneRightLabel = new System.Windows.Forms.Label();
            this.mummyComboBox = new System.Windows.Forms.ComboBox();
            this.mummyArrowBox = new System.Windows.Forms.PictureBox();
            this.mummyLeftLabel = new System.Windows.Forms.Label();
            this.mummyRightLabel = new System.Windows.Forms.Label();
            this.myconidArrowBox = new System.Windows.Forms.PictureBox();
            this.myconidLeftLabel = new System.Windows.Forms.Label();
            this.myconidRightLabel = new System.Windows.Forms.Label();
            this.nagaLeftLabel = new System.Windows.Forms.Label();
            this.nagaRightLabel = new System.Windows.Forms.Label();
            this.nagaArrowBox = new System.Windows.Forms.PictureBox();
            this.ogreArrowBox = new System.Windows.Forms.PictureBox();
            this.ogreLeftLabel = new System.Windows.Forms.Label();
            this.ogreRightLabel = new System.Windows.Forms.Label();
            this.zombieArrowBox = new System.Windows.Forms.PictureBox();
            this.zombieLeftLabel = new System.Windows.Forms.Label();
            this.zombieRightLabel = new System.Windows.Forms.Label();
            this.yugoArrowBox = new System.Windows.Forms.PictureBox();
            this.yugoLeftLabel = new System.Windows.Forms.Label();
            this.yugoRightLabel = new System.Windows.Forms.Label();
            this.yuanArrowBox = new System.Windows.Forms.PictureBox();
            this.yuanLeftLabel = new System.Windows.Forms.Label();
            this.yuanRightLabel = new System.Windows.Forms.Label();
            this.yetiArrowBox = new System.Windows.Forms.PictureBox();
            this.yetiLeftLabel = new System.Windows.Forms.Label();
            this.yetiRightLabel = new System.Windows.Forms.Label();
            this.vampireArrowBox = new System.Windows.Forms.PictureBox();
            this.vampireLeftLabel = new System.Windows.Forms.Label();
            this.vampireRightLabel = new System.Windows.Forms.Label();
            this.sphinxArrowBox = new System.Windows.Forms.PictureBox();
            this.sphinxLeftLabel = new System.Windows.Forms.Label();
            this.sphinxRightLabel = new System.Windows.Forms.Label();
            this.sladdiArrowBox = new System.Windows.Forms.PictureBox();
            this.sahuginArrowBox = new System.Windows.Forms.PictureBox();
            this.oozeArrowBox = new System.Windows.Forms.PictureBox();
            this.skeletonArrowBox = new System.Windows.Forms.PictureBox();
            this.salamanderArrowBox = new System.Windows.Forms.PictureBox();
            this.remorhazeArrowBox = new System.Windows.Forms.PictureBox();
            this.orcArrowBox = new System.Windows.Forms.PictureBox();
            this.oozeLeftLabel = new System.Windows.Forms.Label();
            this.orcLeftLabel = new System.Windows.Forms.Label();
            this.slaadiLeftLabel = new System.Windows.Forms.Label();
            this.salamanderLeftLabel = new System.Windows.Forms.Label();
            this.sahuginLeftLabel = new System.Windows.Forms.Label();
            this.yugolothLeftLabel = new System.Windows.Forms.Label();
            this.skeletonLeftLabel = new System.Windows.Forms.Label();
            this.remorhazLeftLabel = new System.Windows.Forms.Label();
            this.oozeRightLabel = new System.Windows.Forms.Label();
            this.yugolothRightLabel = new System.Windows.Forms.Label();
            this.skeletonRightLabel = new System.Windows.Forms.Label();
            this.orcRightLabel = new System.Windows.Forms.Label();
            this.slaadiRightLabel = new System.Windows.Forms.Label();
            this.salamanderRightLabel = new System.Windows.Forms.Label();
            this.remorhazRightLabel = new System.Windows.Forms.Label();
            this.sahuginRightLabel = new System.Windows.Forms.Label();
            this.yuantiRightLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelArrowPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.animatedObjArrowPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.beholderArrowPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blightArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugbearArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.demonArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.devilArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dinoArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dragArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.elemArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.drowArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fungiArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.genieArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ghoulArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.giantsArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.githArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gnollArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.goblinArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.golemArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grickArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hagArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hobgoblinArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.koboldArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kuoArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lizardfolkArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lycanArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mephitArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.modroneArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mummyArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myconidArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nagaArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ogreArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombieArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yugoArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yuanArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.yetiArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vampireArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sphinxArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sladdiArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahuginArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oozeArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeletonArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.salamanderArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.remorhazeArrowBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orcArrowBox)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Black;
            this.comboBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(125, 7);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.MaxDropDownItems = 5;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(209, 24);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(12, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Monsters :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(25, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Level :";
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.Black;
            this.comboBox3.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(175, 134);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox3.MaxDropDownItems = 5;
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(71, 24);
            this.comboBox3.TabIndex = 4;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(3, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 31);
            this.label3.TabIndex = 5;
            this.label3.Text = "Challenge Rating :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // lvlLabel
            // 
            this.lvlLabel.AutoSize = true;
            this.lvlLabel.BackColor = System.Drawing.Color.Transparent;
            this.lvlLabel.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlLabel.ForeColor = System.Drawing.Color.White;
            this.lvlLabel.Location = new System.Drawing.Point(91, 163);
            this.lvlLabel.Name = "lvlLabel";
            this.lvlLabel.Size = new System.Drawing.Size(28, 22);
            this.lvlLabel.TabIndex = 6;
            this.lvlLabel.Text = "   ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(25, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 31);
            this.label4.TabIndex = 7;
            this.label4.Text = "Armor Class: ";
            // 
            // acLabel
            // 
            this.acLabel.AutoSize = true;
            this.acLabel.BackColor = System.Drawing.Color.Transparent;
            this.acLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.acLabel.Location = new System.Drawing.Point(154, 196);
            this.acLabel.Name = "acLabel";
            this.acLabel.Size = new System.Drawing.Size(24, 20);
            this.acLabel.TabIndex = 8;
            this.acLabel.Text = "   ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(27, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(184, 31);
            this.label5.TabIndex = 9;
            this.label5.Text = "Proficiency Bonus: ";
            // 
            // profLabel
            // 
            this.profLabel.AutoSize = true;
            this.profLabel.BackColor = System.Drawing.Color.Transparent;
            this.profLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.profLabel.Location = new System.Drawing.Point(208, 234);
            this.profLabel.Name = "profLabel";
            this.profLabel.Size = new System.Drawing.Size(24, 20);
            this.profLabel.TabIndex = 10;
            this.profLabel.Text = "   ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(27, 259);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 31);
            this.label6.TabIndex = 11;
            this.label6.Text = "Hit Points: ";
            // 
            // hpLabel
            // 
            this.hpLabel.AutoSize = true;
            this.hpLabel.BackColor = System.Drawing.Color.Transparent;
            this.hpLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hpLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.hpLabel.Location = new System.Drawing.Point(135, 264);
            this.hpLabel.Name = "hpLabel";
            this.hpLabel.Size = new System.Drawing.Size(24, 20);
            this.hpLabel.TabIndex = 12;
            this.hpLabel.Text = "   ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Window;
            this.label7.Location = new System.Drawing.Point(27, 290);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 31);
            this.label7.TabIndex = 13;
            this.label7.Text = "Attack Bonus: ";
            // 
            // attackBLabel
            // 
            this.attackBLabel.AutoSize = true;
            this.attackBLabel.BackColor = System.Drawing.Color.Transparent;
            this.attackBLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attackBLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.attackBLabel.Location = new System.Drawing.Point(171, 295);
            this.attackBLabel.Name = "attackBLabel";
            this.attackBLabel.Size = new System.Drawing.Size(24, 20);
            this.attackBLabel.TabIndex = 14;
            this.attackBLabel.Text = "   ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(27, 321);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(193, 31);
            this.label8.TabIndex = 15;
            this.label8.Text = "Damage per Round: ";
            // 
            // damageLabel
            // 
            this.damageLabel.AutoSize = true;
            this.damageLabel.BackColor = System.Drawing.Color.Transparent;
            this.damageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.damageLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.damageLabel.Location = new System.Drawing.Point(221, 326);
            this.damageLabel.Name = "damageLabel";
            this.damageLabel.Size = new System.Drawing.Size(24, 20);
            this.damageLabel.TabIndex = 16;
            this.damageLabel.Text = "   ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Window;
            this.label9.Location = new System.Drawing.Point(27, 352);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(148, 31);
            this.label9.TabIndex = 17;
            this.label9.Text = "Saving Throw: ";
            // 
            // saveThrowLabel
            // 
            this.saveThrowLabel.AutoSize = true;
            this.saveThrowLabel.BackColor = System.Drawing.Color.Transparent;
            this.saveThrowLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveThrowLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.saveThrowLabel.Location = new System.Drawing.Point(171, 357);
            this.saveThrowLabel.Name = "saveThrowLabel";
            this.saveThrowLabel.Size = new System.Drawing.Size(24, 20);
            this.saveThrowLabel.TabIndex = 18;
            this.saveThrowLabel.Text = "   ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Window;
            this.label10.Location = new System.Drawing.Point(29, 383);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 31);
            this.label10.TabIndex = 19;
            this.label10.Text = "Exp: ";
            // 
            // expLabel
            // 
            this.expLabel.AutoSize = true;
            this.expLabel.BackColor = System.Drawing.Color.Transparent;
            this.expLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.expLabel.Location = new System.Drawing.Point(91, 388);
            this.expLabel.Name = "expLabel";
            this.expLabel.Size = new System.Drawing.Size(24, 20);
            this.expLabel.TabIndex = 20;
            this.expLabel.Text = "   ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Window;
            this.label11.Location = new System.Drawing.Point(357, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 27);
            this.label11.TabIndex = 21;
            this.label11.Text = "( Pg#";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // pageNumLabel
            // 
            this.pageNumLabel.AutoSize = true;
            this.pageNumLabel.BackColor = System.Drawing.Color.Transparent;
            this.pageNumLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pageNumLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.pageNumLabel.Location = new System.Drawing.Point(405, 5);
            this.pageNumLabel.Name = "pageNumLabel";
            this.pageNumLabel.Size = new System.Drawing.Size(37, 27);
            this.pageNumLabel.TabIndex = 22;
            this.pageNumLabel.Text = "     )";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.Window;
            this.label12.Location = new System.Drawing.Point(12, 64);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(241, 31);
            this.label12.TabIndex = 23;
            this.label12.Text = "Miscellaneous Creatures: ";
            // 
            // miscCreateComboBox
            // 
            this.miscCreateComboBox.BackColor = System.Drawing.Color.Black;
            this.miscCreateComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.miscCreateComboBox.FormattingEnabled = true;
            this.miscCreateComboBox.Location = new System.Drawing.Point(248, 69);
            this.miscCreateComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.miscCreateComboBox.MaxDropDownItems = 5;
            this.miscCreateComboBox.Name = "miscCreateComboBox";
            this.miscCreateComboBox.Size = new System.Drawing.Size(201, 24);
            this.miscCreateComboBox.TabIndex = 24;
            this.miscCreateComboBox.SelectedIndexChanged += new System.EventHandler(this.miscCreateComboBox_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.Window;
            this.label13.Location = new System.Drawing.Point(12, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(220, 31);
            this.label13.TabIndex = 25;
            this.label13.Text = "NonPlayer Characters: ";
            // 
            // npcComboBox
            // 
            this.npcComboBox.BackColor = System.Drawing.Color.Black;
            this.npcComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.npcComboBox.FormattingEnabled = true;
            this.npcComboBox.Location = new System.Drawing.Point(225, 100);
            this.npcComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.npcComboBox.MaxDropDownItems = 5;
            this.npcComboBox.Name = "npcComboBox";
            this.npcComboBox.Size = new System.Drawing.Size(121, 24);
            this.npcComboBox.TabIndex = 26;
            this.npcComboBox.SelectedIndexChanged += new System.EventHandler(this.npcComboBox_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(341, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(21, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(456, 68);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(21, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 28;
            this.pictureBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.Window;
            this.label14.Location = new System.Drawing.Point(475, 65);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 27);
            this.label14.TabIndex = 29;
            this.label14.Text = "( Pg#";
            // 
            // miscCreatureLabel
            // 
            this.miscCreatureLabel.AutoSize = true;
            this.miscCreatureLabel.BackColor = System.Drawing.Color.Transparent;
            this.miscCreatureLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miscCreatureLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.miscCreatureLabel.Location = new System.Drawing.Point(517, 66);
            this.miscCreatureLabel.Name = "miscCreatureLabel";
            this.miscCreatureLabel.Size = new System.Drawing.Size(29, 27);
            this.miscCreatureLabel.TabIndex = 30;
            this.miscCreatureLabel.Text = "   )";
            this.miscCreatureLabel.Click += new System.EventHandler(this.label15_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(352, 101);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(21, 20);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 31;
            this.pictureBox3.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.Window;
            this.label15.Location = new System.Drawing.Point(371, 97);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 27);
            this.label15.TabIndex = 32;
            this.label15.Text = "( Pg#";
            // 
            // npcLabel
            // 
            this.npcLabel.AutoSize = true;
            this.npcLabel.BackColor = System.Drawing.Color.Transparent;
            this.npcLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.npcLabel.Location = new System.Drawing.Point(413, 97);
            this.npcLabel.Name = "npcLabel";
            this.npcLabel.Size = new System.Drawing.Size(29, 27);
            this.npcLabel.TabIndex = 33;
            this.npcLabel.Text = "   )";
            // 
            // angelSubcomboBox
            // 
            this.angelSubcomboBox.BackColor = System.Drawing.Color.Black;
            this.angelSubcomboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.angelSubcomboBox.FormattingEnabled = true;
            this.angelSubcomboBox.Location = new System.Drawing.Point(125, 37);
            this.angelSubcomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.angelSubcomboBox.Name = "angelSubcomboBox";
            this.angelSubcomboBox.Size = new System.Drawing.Size(121, 24);
            this.angelSubcomboBox.TabIndex = 36;
            this.angelSubcomboBox.Visible = false;
            this.angelSubcomboBox.SelectedIndexChanged += new System.EventHandler(this.angelSubcomboBox_SelectedIndexChanged);
            // 
            // animatedObjectcomboBox
            // 
            this.animatedObjectcomboBox.BackColor = System.Drawing.Color.Black;
            this.animatedObjectcomboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.animatedObjectcomboBox.FormattingEnabled = true;
            this.animatedObjectcomboBox.Location = new System.Drawing.Point(125, 37);
            this.animatedObjectcomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.animatedObjectcomboBox.Name = "animatedObjectcomboBox";
            this.animatedObjectcomboBox.Size = new System.Drawing.Size(147, 24);
            this.animatedObjectcomboBox.TabIndex = 37;
            this.animatedObjectcomboBox.Visible = false;
            this.animatedObjectcomboBox.SelectedIndexChanged += new System.EventHandler(this.animatedObjectcomboBox_SelectedIndexChanged);
            // 
            // beHoldercomboBox
            // 
            this.beHoldercomboBox.BackColor = System.Drawing.Color.Black;
            this.beHoldercomboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.beHoldercomboBox.FormattingEnabled = true;
            this.beHoldercomboBox.Location = new System.Drawing.Point(125, 38);
            this.beHoldercomboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.beHoldercomboBox.Name = "beHoldercomboBox";
            this.beHoldercomboBox.Size = new System.Drawing.Size(147, 24);
            this.beHoldercomboBox.TabIndex = 38;
            this.beHoldercomboBox.Visible = false;
            this.beHoldercomboBox.SelectedIndexChanged += new System.EventHandler(this.beHoldercomboBox_SelectedIndexChanged);
            // 
            // blightComboBox
            // 
            this.blightComboBox.BackColor = System.Drawing.Color.Black;
            this.blightComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.blightComboBox.FormattingEnabled = true;
            this.blightComboBox.Location = new System.Drawing.Point(125, 37);
            this.blightComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.blightComboBox.Name = "blightComboBox";
            this.blightComboBox.Size = new System.Drawing.Size(147, 24);
            this.blightComboBox.TabIndex = 39;
            this.blightComboBox.Visible = false;
            this.blightComboBox.SelectedIndexChanged += new System.EventHandler(this.blightComboBox_SelectedIndexChanged);
            // 
            // bugBearComboBox
            // 
            this.bugBearComboBox.BackColor = System.Drawing.Color.Black;
            this.bugBearComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.bugBearComboBox.FormattingEnabled = true;
            this.bugBearComboBox.Location = new System.Drawing.Point(125, 38);
            this.bugBearComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bugBearComboBox.Name = "bugBearComboBox";
            this.bugBearComboBox.Size = new System.Drawing.Size(147, 24);
            this.bugBearComboBox.TabIndex = 40;
            this.bugBearComboBox.Visible = false;
            this.bugBearComboBox.SelectedIndexChanged += new System.EventHandler(this.bugBearComboBox_SelectedIndexChanged);
            // 
            // demonComboBox
            // 
            this.demonComboBox.BackColor = System.Drawing.Color.Black;
            this.demonComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.demonComboBox.FormattingEnabled = true;
            this.demonComboBox.Location = new System.Drawing.Point(125, 38);
            this.demonComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.demonComboBox.Name = "demonComboBox";
            this.demonComboBox.Size = new System.Drawing.Size(147, 24);
            this.demonComboBox.TabIndex = 41;
            this.demonComboBox.Visible = false;
            this.demonComboBox.SelectedIndexChanged += new System.EventHandler(this.demonComboBox_SelectedIndexChanged);
            // 
            // devilComboBox
            // 
            this.devilComboBox.BackColor = System.Drawing.Color.Black;
            this.devilComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.devilComboBox.FormattingEnabled = true;
            this.devilComboBox.Location = new System.Drawing.Point(125, 37);
            this.devilComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.devilComboBox.Name = "devilComboBox";
            this.devilComboBox.Size = new System.Drawing.Size(147, 24);
            this.devilComboBox.TabIndex = 42;
            this.devilComboBox.Visible = false;
            this.devilComboBox.SelectedIndexChanged += new System.EventHandler(this.devilComboBox_SelectedIndexChanged);
            // 
            // dinoComboBox
            // 
            this.dinoComboBox.BackColor = System.Drawing.Color.Black;
            this.dinoComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.dinoComboBox.FormattingEnabled = true;
            this.dinoComboBox.Location = new System.Drawing.Point(125, 38);
            this.dinoComboBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dinoComboBox.Name = "dinoComboBox";
            this.dinoComboBox.Size = new System.Drawing.Size(147, 24);
            this.dinoComboBox.TabIndex = 43;
            this.dinoComboBox.Visible = false;
            this.dinoComboBox.SelectedIndexChanged += new System.EventHandler(this.dinoComboBox_SelectedIndexChanged);
            // 
            // dragon1ComboBox
            // 
            this.dragon1ComboBox.BackColor = System.Drawing.Color.Black;
            this.dragon1ComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.dragon1ComboBox.FormattingEnabled = true;
            this.dragon1ComboBox.Location = new System.Drawing.Point(125, 37);
            this.dragon1ComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.dragon1ComboBox.Name = "dragon1ComboBox";
            this.dragon1ComboBox.Size = new System.Drawing.Size(164, 24);
            this.dragon1ComboBox.TabIndex = 44;
            this.dragon1ComboBox.Visible = false;
            this.dragon1ComboBox.SelectedIndexChanged += new System.EventHandler(this.dragon1ComboBox_SelectedIndexChanged);
            // 
            // elementsComboBox
            // 
            this.elementsComboBox.BackColor = System.Drawing.Color.Black;
            this.elementsComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.elementsComboBox.FormattingEnabled = true;
            this.elementsComboBox.Location = new System.Drawing.Point(125, 37);
            this.elementsComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.elementsComboBox.Name = "elementsComboBox";
            this.elementsComboBox.Size = new System.Drawing.Size(160, 24);
            this.elementsComboBox.TabIndex = 45;
            this.elementsComboBox.Visible = false;
            this.elementsComboBox.SelectedIndexChanged += new System.EventHandler(this.elementsComboBox_SelectedIndexChanged);
            // 
            // drowComboBox
            // 
            this.drowComboBox.BackColor = System.Drawing.Color.Black;
            this.drowComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.drowComboBox.FormattingEnabled = true;
            this.drowComboBox.Location = new System.Drawing.Point(125, 38);
            this.drowComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.drowComboBox.Name = "drowComboBox";
            this.drowComboBox.Size = new System.Drawing.Size(160, 24);
            this.drowComboBox.TabIndex = 46;
            this.drowComboBox.Visible = false;
            this.drowComboBox.SelectedIndexChanged += new System.EventHandler(this.drowComboBox_SelectedIndexChanged);
            // 
            // fungiComboBox
            // 
            this.fungiComboBox.BackColor = System.Drawing.Color.Black;
            this.fungiComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.fungiComboBox.FormattingEnabled = true;
            this.fungiComboBox.Location = new System.Drawing.Point(125, 37);
            this.fungiComboBox.Name = "fungiComboBox";
            this.fungiComboBox.Size = new System.Drawing.Size(160, 24);
            this.fungiComboBox.TabIndex = 47;
            this.fungiComboBox.Visible = false;
            this.fungiComboBox.SelectedIndexChanged += new System.EventHandler(this.fungiComboBox_SelectedIndexChanged);
            // 
            // giantsComboBox
            // 
            this.giantsComboBox.BackColor = System.Drawing.Color.Black;
            this.giantsComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.giantsComboBox.FormattingEnabled = true;
            this.giantsComboBox.Location = new System.Drawing.Point(125, 36);
            this.giantsComboBox.Name = "giantsComboBox";
            this.giantsComboBox.Size = new System.Drawing.Size(160, 24);
            this.giantsComboBox.TabIndex = 48;
            this.giantsComboBox.Visible = false;
            this.giantsComboBox.SelectedIndexChanged += new System.EventHandler(this.giantsComboBox_SelectedIndexChanged);
            // 
            // githComboBox
            // 
            this.githComboBox.BackColor = System.Drawing.Color.Black;
            this.githComboBox.ForeColor = System.Drawing.Color.White;
            this.githComboBox.FormattingEnabled = true;
            this.githComboBox.Location = new System.Drawing.Point(125, 39);
            this.githComboBox.Name = "githComboBox";
            this.githComboBox.Size = new System.Drawing.Size(160, 24);
            this.githComboBox.TabIndex = 49;
            this.githComboBox.Visible = false;
            this.githComboBox.SelectedIndexChanged += new System.EventHandler(this.githComboBox_SelectedIndexChanged);
            // 
            // gnollComboBox
            // 
            this.gnollComboBox.BackColor = System.Drawing.Color.Black;
            this.gnollComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.gnollComboBox.FormattingEnabled = true;
            this.gnollComboBox.Location = new System.Drawing.Point(126, 37);
            this.gnollComboBox.Name = "gnollComboBox";
            this.gnollComboBox.Size = new System.Drawing.Size(160, 24);
            this.gnollComboBox.TabIndex = 50;
            this.gnollComboBox.Visible = false;
            this.gnollComboBox.SelectedIndexChanged += new System.EventHandler(this.gnollComboBox_SelectedIndexChanged);
            // 
            // golemComboBox
            // 
            this.golemComboBox.BackColor = System.Drawing.Color.Black;
            this.golemComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.golemComboBox.FormattingEnabled = true;
            this.golemComboBox.Location = new System.Drawing.Point(125, 37);
            this.golemComboBox.Name = "golemComboBox";
            this.golemComboBox.Size = new System.Drawing.Size(160, 24);
            this.golemComboBox.TabIndex = 51;
            this.golemComboBox.Visible = false;
            this.golemComboBox.SelectedIndexChanged += new System.EventHandler(this.golemComboBox_SelectedIndexChanged);
            // 
            // hagComboBox
            // 
            this.hagComboBox.BackColor = System.Drawing.Color.Black;
            this.hagComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.hagComboBox.FormattingEnabled = true;
            this.hagComboBox.Location = new System.Drawing.Point(126, 36);
            this.hagComboBox.Name = "hagComboBox";
            this.hagComboBox.Size = new System.Drawing.Size(160, 24);
            this.hagComboBox.TabIndex = 52;
            this.hagComboBox.Visible = false;
            this.hagComboBox.SelectedIndexChanged += new System.EventHandler(this.hagComboBox_SelectedIndexChanged);
            // 
            // hobgoblinComboBox
            // 
            this.hobgoblinComboBox.BackColor = System.Drawing.Color.Black;
            this.hobgoblinComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.hobgoblinComboBox.FormattingEnabled = true;
            this.hobgoblinComboBox.Location = new System.Drawing.Point(125, 37);
            this.hobgoblinComboBox.Name = "hobgoblinComboBox";
            this.hobgoblinComboBox.Size = new System.Drawing.Size(160, 24);
            this.hobgoblinComboBox.TabIndex = 53;
            this.hobgoblinComboBox.Visible = false;
            this.hobgoblinComboBox.SelectedIndexChanged += new System.EventHandler(this.hobgoblinComboBox_SelectedIndexChanged);
            // 
            // koboldComboBox
            // 
            this.koboldComboBox.BackColor = System.Drawing.Color.Black;
            this.koboldComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.koboldComboBox.FormattingEnabled = true;
            this.koboldComboBox.Location = new System.Drawing.Point(125, 39);
            this.koboldComboBox.Name = "koboldComboBox";
            this.koboldComboBox.Size = new System.Drawing.Size(160, 24);
            this.koboldComboBox.TabIndex = 54;
            this.koboldComboBox.Visible = false;
            this.koboldComboBox.SelectedIndexChanged += new System.EventHandler(this.koboldComboBox_SelectedIndexChanged);
            // 
            // kuoComboBox
            // 
            this.kuoComboBox.BackColor = System.Drawing.Color.Black;
            this.kuoComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.kuoComboBox.FormattingEnabled = true;
            this.kuoComboBox.Location = new System.Drawing.Point(126, 37);
            this.kuoComboBox.Name = "kuoComboBox";
            this.kuoComboBox.Size = new System.Drawing.Size(160, 24);
            this.kuoComboBox.TabIndex = 55;
            this.kuoComboBox.Visible = false;
            this.kuoComboBox.SelectedIndexChanged += new System.EventHandler(this.kuoComboBox_SelectedIndexChanged);
            // 
            // lizardFolkComboBox
            // 
            this.lizardFolkComboBox.BackColor = System.Drawing.Color.Black;
            this.lizardFolkComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.lizardFolkComboBox.FormattingEnabled = true;
            this.lizardFolkComboBox.Location = new System.Drawing.Point(125, 39);
            this.lizardFolkComboBox.Name = "lizardFolkComboBox";
            this.lizardFolkComboBox.Size = new System.Drawing.Size(160, 24);
            this.lizardFolkComboBox.TabIndex = 56;
            this.lizardFolkComboBox.Visible = false;
            this.lizardFolkComboBox.SelectedIndexChanged += new System.EventHandler(this.lizardFolkComboBox_SelectedIndexChanged);
            // 
            // lycanthropeComboBox
            // 
            this.lycanthropeComboBox.BackColor = System.Drawing.Color.Black;
            this.lycanthropeComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.lycanthropeComboBox.FormattingEnabled = true;
            this.lycanthropeComboBox.Location = new System.Drawing.Point(126, 38);
            this.lycanthropeComboBox.Name = "lycanthropeComboBox";
            this.lycanthropeComboBox.Size = new System.Drawing.Size(160, 24);
            this.lycanthropeComboBox.TabIndex = 57;
            this.lycanthropeComboBox.Visible = false;
            this.lycanthropeComboBox.SelectedIndexChanged += new System.EventHandler(this.lycanthropeComboBox_SelectedIndexChanged);
            // 
            // mephitesComboBox
            // 
            this.mephitesComboBox.BackColor = System.Drawing.Color.Black;
            this.mephitesComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.mephitesComboBox.FormattingEnabled = true;
            this.mephitesComboBox.Location = new System.Drawing.Point(126, 36);
            this.mephitesComboBox.Name = "mephitesComboBox";
            this.mephitesComboBox.Size = new System.Drawing.Size(160, 24);
            this.mephitesComboBox.TabIndex = 58;
            this.mephitesComboBox.Visible = false;
            this.mephitesComboBox.SelectedIndexChanged += new System.EventHandler(this.mephitesComboBox_SelectedIndexChanged);
            // 
            // mondroneComboBox
            // 
            this.mondroneComboBox.BackColor = System.Drawing.Color.Black;
            this.mondroneComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.mondroneComboBox.FormattingEnabled = true;
            this.mondroneComboBox.Location = new System.Drawing.Point(126, 37);
            this.mondroneComboBox.Name = "mondroneComboBox";
            this.mondroneComboBox.Size = new System.Drawing.Size(160, 24);
            this.mondroneComboBox.TabIndex = 59;
            this.mondroneComboBox.Visible = false;
            this.mondroneComboBox.SelectedIndexChanged += new System.EventHandler(this.mondroneComboBox_SelectedIndexChanged);
            // 
            // myconoidComboBox
            // 
            this.myconoidComboBox.BackColor = System.Drawing.Color.Black;
            this.myconoidComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.myconoidComboBox.FormattingEnabled = true;
            this.myconoidComboBox.Location = new System.Drawing.Point(126, 37);
            this.myconoidComboBox.Name = "myconoidComboBox";
            this.myconoidComboBox.Size = new System.Drawing.Size(160, 24);
            this.myconoidComboBox.TabIndex = 60;
            this.myconoidComboBox.Visible = false;
            this.myconoidComboBox.SelectedIndexChanged += new System.EventHandler(this.myconoidComboBox_SelectedIndexChanged);
            // 
            // nagaComboBox
            // 
            this.nagaComboBox.BackColor = System.Drawing.Color.Black;
            this.nagaComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.nagaComboBox.FormattingEnabled = true;
            this.nagaComboBox.Location = new System.Drawing.Point(128, 37);
            this.nagaComboBox.Name = "nagaComboBox";
            this.nagaComboBox.Size = new System.Drawing.Size(160, 24);
            this.nagaComboBox.TabIndex = 61;
            this.nagaComboBox.Visible = false;
            this.nagaComboBox.SelectedIndexChanged += new System.EventHandler(this.nagaComboBox_SelectedIndexChanged);
            // 
            // ogreComboBox
            // 
            this.ogreComboBox.BackColor = System.Drawing.Color.Black;
            this.ogreComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.ogreComboBox.FormattingEnabled = true;
            this.ogreComboBox.Location = new System.Drawing.Point(126, 39);
            this.ogreComboBox.Name = "ogreComboBox";
            this.ogreComboBox.Size = new System.Drawing.Size(160, 24);
            this.ogreComboBox.TabIndex = 62;
            this.ogreComboBox.Visible = false;
            this.ogreComboBox.SelectedIndexChanged += new System.EventHandler(this.ogreComboBox_SelectedIndexChanged);
            // 
            // oozeComboBox
            // 
            this.oozeComboBox.BackColor = System.Drawing.Color.Black;
            this.oozeComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.oozeComboBox.FormattingEnabled = true;
            this.oozeComboBox.Location = new System.Drawing.Point(126, 37);
            this.oozeComboBox.Name = "oozeComboBox";
            this.oozeComboBox.Size = new System.Drawing.Size(160, 24);
            this.oozeComboBox.TabIndex = 63;
            this.oozeComboBox.Visible = false;
            this.oozeComboBox.SelectedIndexChanged += new System.EventHandler(this.oozeComboBox_SelectedIndexChanged);
            // 
            // orcComboBox
            // 
            this.orcComboBox.BackColor = System.Drawing.Color.Black;
            this.orcComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.orcComboBox.FormattingEnabled = true;
            this.orcComboBox.Location = new System.Drawing.Point(125, 37);
            this.orcComboBox.Name = "orcComboBox";
            this.orcComboBox.Size = new System.Drawing.Size(160, 24);
            this.orcComboBox.TabIndex = 64;
            this.orcComboBox.Visible = false;
            this.orcComboBox.SelectedIndexChanged += new System.EventHandler(this.orcComboBox_SelectedIndexChanged);
            // 
            // remorhazComboBox
            // 
            this.remorhazComboBox.BackColor = System.Drawing.Color.Black;
            this.remorhazComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.remorhazComboBox.FormattingEnabled = true;
            this.remorhazComboBox.Location = new System.Drawing.Point(128, 36);
            this.remorhazComboBox.Name = "remorhazComboBox";
            this.remorhazComboBox.Size = new System.Drawing.Size(160, 24);
            this.remorhazComboBox.TabIndex = 65;
            this.remorhazComboBox.Visible = false;
            this.remorhazComboBox.SelectedIndexChanged += new System.EventHandler(this.remorhazComboBox_SelectedIndexChanged);
            // 
            // sahuaginComboBox
            // 
            this.sahuaginComboBox.BackColor = System.Drawing.Color.Black;
            this.sahuaginComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.sahuaginComboBox.FormattingEnabled = true;
            this.sahuaginComboBox.Location = new System.Drawing.Point(128, 37);
            this.sahuaginComboBox.Name = "sahuaginComboBox";
            this.sahuaginComboBox.Size = new System.Drawing.Size(160, 24);
            this.sahuaginComboBox.TabIndex = 66;
            this.sahuaginComboBox.Visible = false;
            this.sahuaginComboBox.SelectedIndexChanged += new System.EventHandler(this.sahuaginComboBox_SelectedIndexChanged);
            // 
            // salamanderComboBox
            // 
            this.salamanderComboBox.BackColor = System.Drawing.Color.Black;
            this.salamanderComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.salamanderComboBox.FormattingEnabled = true;
            this.salamanderComboBox.Location = new System.Drawing.Point(128, 37);
            this.salamanderComboBox.Name = "salamanderComboBox";
            this.salamanderComboBox.Size = new System.Drawing.Size(160, 24);
            this.salamanderComboBox.TabIndex = 67;
            this.salamanderComboBox.Visible = false;
            this.salamanderComboBox.SelectedIndexChanged += new System.EventHandler(this.salamanderComboBox_SelectedIndexChanged);
            // 
            // skeletonComboBox
            // 
            this.skeletonComboBox.BackColor = System.Drawing.Color.Black;
            this.skeletonComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.skeletonComboBox.FormattingEnabled = true;
            this.skeletonComboBox.Location = new System.Drawing.Point(125, 35);
            this.skeletonComboBox.Name = "skeletonComboBox";
            this.skeletonComboBox.Size = new System.Drawing.Size(160, 24);
            this.skeletonComboBox.TabIndex = 68;
            this.skeletonComboBox.Visible = false;
            this.skeletonComboBox.SelectedIndexChanged += new System.EventHandler(this.skeletonComboBox_SelectedIndexChanged);
            // 
            // slaadiComboBox
            // 
            this.slaadiComboBox.BackColor = System.Drawing.Color.Black;
            this.slaadiComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.slaadiComboBox.FormattingEnabled = true;
            this.slaadiComboBox.Location = new System.Drawing.Point(126, 34);
            this.slaadiComboBox.Name = "slaadiComboBox";
            this.slaadiComboBox.Size = new System.Drawing.Size(160, 24);
            this.slaadiComboBox.TabIndex = 69;
            this.slaadiComboBox.Visible = false;
            this.slaadiComboBox.SelectedIndexChanged += new System.EventHandler(this.slaadiComboBox_SelectedIndexChanged);
            // 
            // sphinxesComboBox
            // 
            this.sphinxesComboBox.BackColor = System.Drawing.Color.Black;
            this.sphinxesComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.sphinxesComboBox.FormattingEnabled = true;
            this.sphinxesComboBox.Location = new System.Drawing.Point(122, 34);
            this.sphinxesComboBox.Name = "sphinxesComboBox";
            this.sphinxesComboBox.Size = new System.Drawing.Size(160, 24);
            this.sphinxesComboBox.TabIndex = 70;
            this.sphinxesComboBox.Visible = false;
            this.sphinxesComboBox.SelectedIndexChanged += new System.EventHandler(this.sphinxesComboBox_SelectedIndexChanged);
            // 
            // vampireComboBox
            // 
            this.vampireComboBox.BackColor = System.Drawing.Color.Black;
            this.vampireComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.vampireComboBox.FormattingEnabled = true;
            this.vampireComboBox.Location = new System.Drawing.Point(122, 37);
            this.vampireComboBox.Name = "vampireComboBox";
            this.vampireComboBox.Size = new System.Drawing.Size(160, 24);
            this.vampireComboBox.TabIndex = 71;
            this.vampireComboBox.Visible = false;
            this.vampireComboBox.SelectedIndexChanged += new System.EventHandler(this.vampireComboBox_SelectedIndexChanged);
            // 
            // yetiComboBox
            // 
            this.yetiComboBox.BackColor = System.Drawing.Color.Black;
            this.yetiComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.yetiComboBox.FormattingEnabled = true;
            this.yetiComboBox.Location = new System.Drawing.Point(130, 34);
            this.yetiComboBox.Name = "yetiComboBox";
            this.yetiComboBox.Size = new System.Drawing.Size(160, 24);
            this.yetiComboBox.TabIndex = 72;
            this.yetiComboBox.Visible = false;
            this.yetiComboBox.SelectedIndexChanged += new System.EventHandler(this.yetiComboBox_SelectedIndexChanged);
            // 
            // yuanTiComboBox
            // 
            this.yuanTiComboBox.BackColor = System.Drawing.Color.Black;
            this.yuanTiComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.yuanTiComboBox.FormattingEnabled = true;
            this.yuanTiComboBox.Location = new System.Drawing.Point(125, 39);
            this.yuanTiComboBox.Name = "yuanTiComboBox";
            this.yuanTiComboBox.Size = new System.Drawing.Size(160, 24);
            this.yuanTiComboBox.TabIndex = 73;
            this.yuanTiComboBox.Visible = false;
            this.yuanTiComboBox.SelectedIndexChanged += new System.EventHandler(this.yuanTiComboBox_SelectedIndexChanged);
            // 
            // yugolothComboBox
            // 
            this.yugolothComboBox.BackColor = System.Drawing.Color.Black;
            this.yugolothComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.yugolothComboBox.FormattingEnabled = true;
            this.yugolothComboBox.Location = new System.Drawing.Point(122, 39);
            this.yugolothComboBox.Name = "yugolothComboBox";
            this.yugolothComboBox.Size = new System.Drawing.Size(160, 24);
            this.yugolothComboBox.TabIndex = 74;
            this.yugolothComboBox.Visible = false;
            this.yugolothComboBox.SelectedIndexChanged += new System.EventHandler(this.yugolothComboBox_SelectedIndexChanged);
            // 
            // zombieComboBox
            // 
            this.zombieComboBox.BackColor = System.Drawing.Color.Black;
            this.zombieComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.zombieComboBox.FormattingEnabled = true;
            this.zombieComboBox.Location = new System.Drawing.Point(126, 38);
            this.zombieComboBox.Name = "zombieComboBox";
            this.zombieComboBox.Size = new System.Drawing.Size(160, 24);
            this.zombieComboBox.TabIndex = 75;
            this.zombieComboBox.Visible = false;
            this.zombieComboBox.SelectedIndexChanged += new System.EventHandler(this.zombieComboBox_SelectedIndexChanged);
            // 
            // angelArrowPictureBox
            // 
            this.angelArrowPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.angelArrowPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("angelArrowPictureBox.Image")));
            this.angelArrowPictureBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("angelArrowPictureBox.InitialImage")));
            this.angelArrowPictureBox.Location = new System.Drawing.Point(288, 41);
            this.angelArrowPictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.angelArrowPictureBox.Name = "angelArrowPictureBox";
            this.angelArrowPictureBox.Size = new System.Drawing.Size(21, 20);
            this.angelArrowPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.angelArrowPictureBox.TabIndex = 76;
            this.angelArrowPictureBox.TabStop = false;
            this.angelArrowPictureBox.Visible = false;
            // 
            // angelLeftLabel
            // 
            this.angelLeftLabel.AutoSize = true;
            this.angelLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.angelLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angelLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.angelLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.angelLeftLabel.Name = "angelLeftLabel";
            this.angelLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.angelLeftLabel.TabIndex = 77;
            this.angelLeftLabel.Text = "( Pg#";
            this.angelLeftLabel.Visible = false;
            // 
            // angelRightLabel
            // 
            this.angelRightLabel.AutoSize = true;
            this.angelRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.angelRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.angelRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.angelRightLabel.Location = new System.Drawing.Point(384, 33);
            this.angelRightLabel.Name = "angelRightLabel";
            this.angelRightLabel.Size = new System.Drawing.Size(37, 27);
            this.angelRightLabel.TabIndex = 78;
            this.angelRightLabel.Text = "     )";
            this.angelRightLabel.Visible = false;
            // 
            // animatedObjArrowPictureBox
            // 
            this.animatedObjArrowPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.animatedObjArrowPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("animatedObjArrowPictureBox.Image")));
            this.animatedObjArrowPictureBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("animatedObjArrowPictureBox.InitialImage")));
            this.animatedObjArrowPictureBox.Location = new System.Drawing.Point(288, 41);
            this.animatedObjArrowPictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.animatedObjArrowPictureBox.Name = "animatedObjArrowPictureBox";
            this.animatedObjArrowPictureBox.Size = new System.Drawing.Size(21, 20);
            this.animatedObjArrowPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.animatedObjArrowPictureBox.TabIndex = 79;
            this.animatedObjArrowPictureBox.TabStop = false;
            this.animatedObjArrowPictureBox.Visible = false;
            // 
            // animatedObjLeftLabel
            // 
            this.animatedObjLeftLabel.AutoSize = true;
            this.animatedObjLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.animatedObjLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.animatedObjLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.animatedObjLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.animatedObjLeftLabel.Name = "animatedObjLeftLabel";
            this.animatedObjLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.animatedObjLeftLabel.TabIndex = 80;
            this.animatedObjLeftLabel.Text = "( Pg#";
            this.animatedObjLeftLabel.Visible = false;
            // 
            // animatedObjectRightLabel
            // 
            this.animatedObjectRightLabel.AutoSize = true;
            this.animatedObjectRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.animatedObjectRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.animatedObjectRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.animatedObjectRightLabel.Location = new System.Drawing.Point(384, 33);
            this.animatedObjectRightLabel.Name = "animatedObjectRightLabel";
            this.animatedObjectRightLabel.Size = new System.Drawing.Size(37, 27);
            this.animatedObjectRightLabel.TabIndex = 81;
            this.animatedObjectRightLabel.Text = "     )";
            this.animatedObjectRightLabel.Visible = false;
            // 
            // beholderArrowPictureBox
            // 
            this.beholderArrowPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.beholderArrowPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("beholderArrowPictureBox.Image")));
            this.beholderArrowPictureBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("beholderArrowPictureBox.InitialImage")));
            this.beholderArrowPictureBox.Location = new System.Drawing.Point(288, 41);
            this.beholderArrowPictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.beholderArrowPictureBox.Name = "beholderArrowPictureBox";
            this.beholderArrowPictureBox.Size = new System.Drawing.Size(21, 20);
            this.beholderArrowPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.beholderArrowPictureBox.TabIndex = 82;
            this.beholderArrowPictureBox.TabStop = false;
            this.beholderArrowPictureBox.Visible = false;
            // 
            // beholderLeftLabel
            // 
            this.beholderLeftLabel.AutoSize = true;
            this.beholderLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.beholderLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beholderLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.beholderLeftLabel.Location = new System.Drawing.Point(315, 34);
            this.beholderLeftLabel.Name = "beholderLeftLabel";
            this.beholderLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.beholderLeftLabel.TabIndex = 83;
            this.beholderLeftLabel.Text = "( Pg#";
            this.beholderLeftLabel.Visible = false;
            // 
            // beholderRightLabel
            // 
            this.beholderRightLabel.AutoSize = true;
            this.beholderRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.beholderRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beholderRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.beholderRightLabel.Location = new System.Drawing.Point(384, 33);
            this.beholderRightLabel.Name = "beholderRightLabel";
            this.beholderRightLabel.Size = new System.Drawing.Size(29, 27);
            this.beholderRightLabel.TabIndex = 84;
            this.beholderRightLabel.Text = "   )";
            this.beholderRightLabel.Visible = false;
            // 
            // blightArrowBox
            // 
            this.blightArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.blightArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("blightArrowBox.Image")));
            this.blightArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("blightArrowBox.InitialImage")));
            this.blightArrowBox.Location = new System.Drawing.Point(288, 42);
            this.blightArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.blightArrowBox.Name = "blightArrowBox";
            this.blightArrowBox.Size = new System.Drawing.Size(21, 20);
            this.blightArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blightArrowBox.TabIndex = 85;
            this.blightArrowBox.TabStop = false;
            this.blightArrowBox.Visible = false;
            // 
            // blightLeftLabel
            // 
            this.blightLeftLabel.AutoSize = true;
            this.blightLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.blightLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blightLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.blightLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.blightLeftLabel.Name = "blightLeftLabel";
            this.blightLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.blightLeftLabel.TabIndex = 86;
            this.blightLeftLabel.Text = "( Pg#";
            this.blightLeftLabel.Visible = false;
            // 
            // blightRightLabel
            // 
            this.blightRightLabel.AutoSize = true;
            this.blightRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.blightRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blightRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.blightRightLabel.Location = new System.Drawing.Point(384, 33);
            this.blightRightLabel.Name = "blightRightLabel";
            this.blightRightLabel.Size = new System.Drawing.Size(29, 27);
            this.blightRightLabel.TabIndex = 87;
            this.blightRightLabel.Text = "   )";
            this.blightRightLabel.Visible = false;
            // 
            // bugbearArrowBox
            // 
            this.bugbearArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.bugbearArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("bugbearArrowBox.Image")));
            this.bugbearArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("bugbearArrowBox.InitialImage")));
            this.bugbearArrowBox.Location = new System.Drawing.Point(288, 41);
            this.bugbearArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.bugbearArrowBox.Name = "bugbearArrowBox";
            this.bugbearArrowBox.Size = new System.Drawing.Size(21, 20);
            this.bugbearArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bugbearArrowBox.TabIndex = 88;
            this.bugbearArrowBox.TabStop = false;
            this.bugbearArrowBox.Visible = false;
            // 
            // bugbearLeftLabel
            // 
            this.bugbearLeftLabel.AutoSize = true;
            this.bugbearLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.bugbearLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bugbearLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.bugbearLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.bugbearLeftLabel.Name = "bugbearLeftLabel";
            this.bugbearLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.bugbearLeftLabel.TabIndex = 89;
            this.bugbearLeftLabel.Text = "( Pg#";
            this.bugbearLeftLabel.Visible = false;
            // 
            // bugbearRightLabel
            // 
            this.bugbearRightLabel.AutoSize = true;
            this.bugbearRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.bugbearRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bugbearRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.bugbearRightLabel.Location = new System.Drawing.Point(384, 33);
            this.bugbearRightLabel.Name = "bugbearRightLabel";
            this.bugbearRightLabel.Size = new System.Drawing.Size(29, 27);
            this.bugbearRightLabel.TabIndex = 90;
            this.bugbearRightLabel.Text = "   )";
            this.bugbearRightLabel.Visible = false;
            // 
            // demonArrowBox
            // 
            this.demonArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.demonArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("demonArrowBox.Image")));
            this.demonArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("demonArrowBox.InitialImage")));
            this.demonArrowBox.Location = new System.Drawing.Point(288, 42);
            this.demonArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.demonArrowBox.Name = "demonArrowBox";
            this.demonArrowBox.Size = new System.Drawing.Size(21, 20);
            this.demonArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.demonArrowBox.TabIndex = 91;
            this.demonArrowBox.TabStop = false;
            this.demonArrowBox.Visible = false;
            // 
            // demonLeftLabel
            // 
            this.demonLeftLabel.AutoSize = true;
            this.demonLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.demonLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.demonLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.demonLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.demonLeftLabel.Name = "demonLeftLabel";
            this.demonLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.demonLeftLabel.TabIndex = 92;
            this.demonLeftLabel.Text = "( Pg#";
            this.demonLeftLabel.Visible = false;
            // 
            // demonRightLabel
            // 
            this.demonRightLabel.AutoSize = true;
            this.demonRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.demonRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.demonRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.demonRightLabel.Location = new System.Drawing.Point(384, 33);
            this.demonRightLabel.Name = "demonRightLabel";
            this.demonRightLabel.Size = new System.Drawing.Size(29, 27);
            this.demonRightLabel.TabIndex = 93;
            this.demonRightLabel.Text = "   )";
            this.demonRightLabel.Visible = false;
            // 
            // devilArrowBox
            // 
            this.devilArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.devilArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("devilArrowBox.Image")));
            this.devilArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("devilArrowBox.InitialImage")));
            this.devilArrowBox.Location = new System.Drawing.Point(288, 41);
            this.devilArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.devilArrowBox.Name = "devilArrowBox";
            this.devilArrowBox.Size = new System.Drawing.Size(21, 20);
            this.devilArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.devilArrowBox.TabIndex = 94;
            this.devilArrowBox.TabStop = false;
            this.devilArrowBox.Visible = false;
            // 
            // devilLeftLabel
            // 
            this.devilLeftLabel.AutoSize = true;
            this.devilLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.devilLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.devilLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.devilLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.devilLeftLabel.Name = "devilLeftLabel";
            this.devilLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.devilLeftLabel.TabIndex = 95;
            this.devilLeftLabel.Text = "( Pg#";
            this.devilLeftLabel.Visible = false;
            // 
            // devilRightLabel
            // 
            this.devilRightLabel.AutoSize = true;
            this.devilRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.devilRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.devilRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.devilRightLabel.Location = new System.Drawing.Point(384, 33);
            this.devilRightLabel.Name = "devilRightLabel";
            this.devilRightLabel.Size = new System.Drawing.Size(29, 27);
            this.devilRightLabel.TabIndex = 96;
            this.devilRightLabel.Text = "   )";
            this.devilRightLabel.Visible = false;
            // 
            // dinoArrowBox
            // 
            this.dinoArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.dinoArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("dinoArrowBox.Image")));
            this.dinoArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("dinoArrowBox.InitialImage")));
            this.dinoArrowBox.Location = new System.Drawing.Point(288, 41);
            this.dinoArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dinoArrowBox.Name = "dinoArrowBox";
            this.dinoArrowBox.Size = new System.Drawing.Size(21, 20);
            this.dinoArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dinoArrowBox.TabIndex = 97;
            this.dinoArrowBox.TabStop = false;
            this.dinoArrowBox.Visible = false;
            // 
            // dinoLeftLabel
            // 
            this.dinoLeftLabel.AutoSize = true;
            this.dinoLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.dinoLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinoLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.dinoLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.dinoLeftLabel.Name = "dinoLeftLabel";
            this.dinoLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.dinoLeftLabel.TabIndex = 98;
            this.dinoLeftLabel.Text = "( Pg#";
            this.dinoLeftLabel.Visible = false;
            // 
            // dinoRightLabel
            // 
            this.dinoRightLabel.AutoSize = true;
            this.dinoRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.dinoRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dinoRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.dinoRightLabel.Location = new System.Drawing.Point(384, 33);
            this.dinoRightLabel.Name = "dinoRightLabel";
            this.dinoRightLabel.Size = new System.Drawing.Size(29, 27);
            this.dinoRightLabel.TabIndex = 99;
            this.dinoRightLabel.Text = "   )";
            this.dinoRightLabel.Visible = false;
            // 
            // dragArrowBox
            // 
            this.dragArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.dragArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("dragArrowBox.Image")));
            this.dragArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("dragArrowBox.InitialImage")));
            this.dragArrowBox.Location = new System.Drawing.Point(296, 41);
            this.dragArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dragArrowBox.Name = "dragArrowBox";
            this.dragArrowBox.Size = new System.Drawing.Size(21, 20);
            this.dragArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dragArrowBox.TabIndex = 100;
            this.dragArrowBox.TabStop = false;
            this.dragArrowBox.Visible = false;
            // 
            // dragLeftLabel
            // 
            this.dragLeftLabel.AutoSize = true;
            this.dragLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.dragLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dragLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.dragLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.dragLeftLabel.Name = "dragLeftLabel";
            this.dragLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.dragLeftLabel.TabIndex = 101;
            this.dragLeftLabel.Text = "( Pg#";
            this.dragLeftLabel.Visible = false;
            // 
            // dragRightLabel
            // 
            this.dragRightLabel.AutoSize = true;
            this.dragRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.dragRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dragRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.dragRightLabel.Location = new System.Drawing.Point(384, 33);
            this.dragRightLabel.Name = "dragRightLabel";
            this.dragRightLabel.Size = new System.Drawing.Size(29, 27);
            this.dragRightLabel.TabIndex = 102;
            this.dragRightLabel.Text = "   )";
            this.dragRightLabel.Visible = false;
            // 
            // elemArrowBox
            // 
            this.elemArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.elemArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("elemArrowBox.Image")));
            this.elemArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("elemArrowBox.InitialImage")));
            this.elemArrowBox.Location = new System.Drawing.Point(288, 41);
            this.elemArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.elemArrowBox.Name = "elemArrowBox";
            this.elemArrowBox.Size = new System.Drawing.Size(21, 20);
            this.elemArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.elemArrowBox.TabIndex = 103;
            this.elemArrowBox.TabStop = false;
            this.elemArrowBox.Visible = false;
            // 
            // elemLeftLabel
            // 
            this.elemLeftLabel.AutoSize = true;
            this.elemLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.elemLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elemLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.elemLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.elemLeftLabel.Name = "elemLeftLabel";
            this.elemLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.elemLeftLabel.TabIndex = 104;
            this.elemLeftLabel.Text = "( Pg#";
            this.elemLeftLabel.Visible = false;
            // 
            // elemRightLabel
            // 
            this.elemRightLabel.AutoSize = true;
            this.elemRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.elemRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.elemRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.elemRightLabel.Location = new System.Drawing.Point(384, 33);
            this.elemRightLabel.Name = "elemRightLabel";
            this.elemRightLabel.Size = new System.Drawing.Size(29, 27);
            this.elemRightLabel.TabIndex = 105;
            this.elemRightLabel.Text = "   )";
            this.elemRightLabel.Visible = false;
            // 
            // drowArrowBox
            // 
            this.drowArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.drowArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("drowArrowBox.Image")));
            this.drowArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("drowArrowBox.InitialImage")));
            this.drowArrowBox.Location = new System.Drawing.Point(288, 41);
            this.drowArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.drowArrowBox.Name = "drowArrowBox";
            this.drowArrowBox.Size = new System.Drawing.Size(21, 20);
            this.drowArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.drowArrowBox.TabIndex = 106;
            this.drowArrowBox.TabStop = false;
            this.drowArrowBox.Visible = false;
            // 
            // drowLeftLabel
            // 
            this.drowLeftLabel.AutoSize = true;
            this.drowLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.drowLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drowLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.drowLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.drowLeftLabel.Name = "drowLeftLabel";
            this.drowLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.drowLeftLabel.TabIndex = 107;
            this.drowLeftLabel.Text = "( Pg#";
            this.drowLeftLabel.Visible = false;
            // 
            // drowRightLabel
            // 
            this.drowRightLabel.AutoSize = true;
            this.drowRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.drowRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drowRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.drowRightLabel.Location = new System.Drawing.Point(384, 33);
            this.drowRightLabel.Name = "drowRightLabel";
            this.drowRightLabel.Size = new System.Drawing.Size(29, 27);
            this.drowRightLabel.TabIndex = 108;
            this.drowRightLabel.Text = "   )";
            this.drowRightLabel.Visible = false;
            // 
            // fungiArrowBox
            // 
            this.fungiArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.fungiArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("fungiArrowBox.Image")));
            this.fungiArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("fungiArrowBox.InitialImage")));
            this.fungiArrowBox.Location = new System.Drawing.Point(291, 40);
            this.fungiArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fungiArrowBox.Name = "fungiArrowBox";
            this.fungiArrowBox.Size = new System.Drawing.Size(21, 20);
            this.fungiArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.fungiArrowBox.TabIndex = 109;
            this.fungiArrowBox.TabStop = false;
            this.fungiArrowBox.Visible = false;
            // 
            // fungiLeftLabel
            // 
            this.fungiLeftLabel.AutoSize = true;
            this.fungiLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.fungiLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fungiLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.fungiLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.fungiLeftLabel.Name = "fungiLeftLabel";
            this.fungiLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.fungiLeftLabel.TabIndex = 110;
            this.fungiLeftLabel.Text = "( Pg#";
            this.fungiLeftLabel.Visible = false;
            // 
            // fungiRightLabel
            // 
            this.fungiRightLabel.AutoSize = true;
            this.fungiRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.fungiRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fungiRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.fungiRightLabel.Location = new System.Drawing.Point(384, 33);
            this.fungiRightLabel.Name = "fungiRightLabel";
            this.fungiRightLabel.Size = new System.Drawing.Size(29, 27);
            this.fungiRightLabel.TabIndex = 111;
            this.fungiRightLabel.Text = "   )";
            this.fungiRightLabel.Visible = false;
            // 
            // genieComboBox
            // 
            this.genieComboBox.BackColor = System.Drawing.Color.Black;
            this.genieComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.genieComboBox.FormattingEnabled = true;
            this.genieComboBox.Location = new System.Drawing.Point(125, 38);
            this.genieComboBox.Name = "genieComboBox";
            this.genieComboBox.Size = new System.Drawing.Size(160, 24);
            this.genieComboBox.TabIndex = 112;
            this.genieComboBox.Visible = false;
            this.genieComboBox.SelectedIndexChanged += new System.EventHandler(this.genieComboBox_SelectedIndexChanged);
            // 
            // genieArrowBox
            // 
            this.genieArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.genieArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("genieArrowBox.Image")));
            this.genieArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("genieArrowBox.InitialImage")));
            this.genieArrowBox.Location = new System.Drawing.Point(292, 38);
            this.genieArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.genieArrowBox.Name = "genieArrowBox";
            this.genieArrowBox.Size = new System.Drawing.Size(21, 20);
            this.genieArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.genieArrowBox.TabIndex = 113;
            this.genieArrowBox.TabStop = false;
            this.genieArrowBox.Visible = false;
            // 
            // genieLeftLabel
            // 
            this.genieLeftLabel.AutoSize = true;
            this.genieLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.genieLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genieLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.genieLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.genieLeftLabel.Name = "genieLeftLabel";
            this.genieLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.genieLeftLabel.TabIndex = 114;
            this.genieLeftLabel.Text = "( Pg#";
            this.genieLeftLabel.Visible = false;
            // 
            // genieRightLabel
            // 
            this.genieRightLabel.AutoSize = true;
            this.genieRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.genieRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.genieRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.genieRightLabel.Location = new System.Drawing.Point(384, 33);
            this.genieRightLabel.Name = "genieRightLabel";
            this.genieRightLabel.Size = new System.Drawing.Size(29, 27);
            this.genieRightLabel.TabIndex = 115;
            this.genieRightLabel.Text = "   )";
            this.genieRightLabel.Visible = false;
            // 
            // ghoulComboBox
            // 
            this.ghoulComboBox.BackColor = System.Drawing.Color.Black;
            this.ghoulComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.ghoulComboBox.FormattingEnabled = true;
            this.ghoulComboBox.Location = new System.Drawing.Point(125, 37);
            this.ghoulComboBox.Name = "ghoulComboBox";
            this.ghoulComboBox.Size = new System.Drawing.Size(164, 24);
            this.ghoulComboBox.TabIndex = 116;
            this.ghoulComboBox.Visible = false;
            this.ghoulComboBox.SelectedIndexChanged += new System.EventHandler(this.ghoulComboBox_SelectedIndexChanged);
            // 
            // ghoulArrowBox
            // 
            this.ghoulArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.ghoulArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("ghoulArrowBox.Image")));
            this.ghoulArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("ghoulArrowBox.InitialImage")));
            this.ghoulArrowBox.Location = new System.Drawing.Point(292, 40);
            this.ghoulArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ghoulArrowBox.Name = "ghoulArrowBox";
            this.ghoulArrowBox.Size = new System.Drawing.Size(21, 20);
            this.ghoulArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ghoulArrowBox.TabIndex = 117;
            this.ghoulArrowBox.TabStop = false;
            this.ghoulArrowBox.Visible = false;
            // 
            // ghoulLeftLabel
            // 
            this.ghoulLeftLabel.AutoSize = true;
            this.ghoulLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.ghoulLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ghoulLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.ghoulLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.ghoulLeftLabel.Name = "ghoulLeftLabel";
            this.ghoulLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.ghoulLeftLabel.TabIndex = 118;
            this.ghoulLeftLabel.Text = "( Pg#";
            this.ghoulLeftLabel.Visible = false;
            // 
            // ghoulRightLabel
            // 
            this.ghoulRightLabel.AutoSize = true;
            this.ghoulRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.ghoulRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ghoulRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.ghoulRightLabel.Location = new System.Drawing.Point(384, 33);
            this.ghoulRightLabel.Name = "ghoulRightLabel";
            this.ghoulRightLabel.Size = new System.Drawing.Size(29, 27);
            this.ghoulRightLabel.TabIndex = 119;
            this.ghoulRightLabel.Text = "   )";
            this.ghoulRightLabel.Visible = false;
            // 
            // giantsArrowBox
            // 
            this.giantsArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.giantsArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("giantsArrowBox.Image")));
            this.giantsArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("giantsArrowBox.InitialImage")));
            this.giantsArrowBox.Location = new System.Drawing.Point(292, 40);
            this.giantsArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.giantsArrowBox.Name = "giantsArrowBox";
            this.giantsArrowBox.Size = new System.Drawing.Size(21, 20);
            this.giantsArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.giantsArrowBox.TabIndex = 120;
            this.giantsArrowBox.TabStop = false;
            this.giantsArrowBox.Visible = false;
            // 
            // giantsLeftLabel
            // 
            this.giantsLeftLabel.AutoSize = true;
            this.giantsLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.giantsLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.giantsLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.giantsLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.giantsLeftLabel.Name = "giantsLeftLabel";
            this.giantsLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.giantsLeftLabel.TabIndex = 121;
            this.giantsLeftLabel.Text = "( Pg#";
            this.giantsLeftLabel.Visible = false;
            // 
            // giantsRightLabel
            // 
            this.giantsRightLabel.AutoSize = true;
            this.giantsRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.giantsRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.giantsRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.giantsRightLabel.Location = new System.Drawing.Point(384, 33);
            this.giantsRightLabel.Name = "giantsRightLabel";
            this.giantsRightLabel.Size = new System.Drawing.Size(29, 27);
            this.giantsRightLabel.TabIndex = 122;
            this.giantsRightLabel.Text = "   )";
            this.giantsRightLabel.Visible = false;
            // 
            // githArrowBox
            // 
            this.githArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.githArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("githArrowBox.Image")));
            this.githArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("githArrowBox.InitialImage")));
            this.githArrowBox.Location = new System.Drawing.Point(296, 41);
            this.githArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.githArrowBox.Name = "githArrowBox";
            this.githArrowBox.Size = new System.Drawing.Size(21, 20);
            this.githArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.githArrowBox.TabIndex = 123;
            this.githArrowBox.TabStop = false;
            this.githArrowBox.Visible = false;
            // 
            // githLeftLabel
            // 
            this.githLeftLabel.AutoSize = true;
            this.githLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.githLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.githLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.githLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.githLeftLabel.Name = "githLeftLabel";
            this.githLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.githLeftLabel.TabIndex = 124;
            this.githLeftLabel.Text = "( Pg#";
            this.githLeftLabel.Visible = false;
            // 
            // githRightLabel
            // 
            this.githRightLabel.AutoSize = true;
            this.githRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.githRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.githRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.githRightLabel.Location = new System.Drawing.Point(384, 33);
            this.githRightLabel.Name = "githRightLabel";
            this.githRightLabel.Size = new System.Drawing.Size(29, 27);
            this.githRightLabel.TabIndex = 125;
            this.githRightLabel.Text = "   )";
            this.githRightLabel.Visible = false;
            // 
            // gnollArrowBox
            // 
            this.gnollArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.gnollArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("gnollArrowBox.Image")));
            this.gnollArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("gnollArrowBox.InitialImage")));
            this.gnollArrowBox.Location = new System.Drawing.Point(295, 40);
            this.gnollArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gnollArrowBox.Name = "gnollArrowBox";
            this.gnollArrowBox.Size = new System.Drawing.Size(21, 20);
            this.gnollArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gnollArrowBox.TabIndex = 126;
            this.gnollArrowBox.TabStop = false;
            this.gnollArrowBox.Visible = false;
            // 
            // gnollLeftLabel
            // 
            this.gnollLeftLabel.AutoSize = true;
            this.gnollLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.gnollLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gnollLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.gnollLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.gnollLeftLabel.Name = "gnollLeftLabel";
            this.gnollLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.gnollLeftLabel.TabIndex = 127;
            this.gnollLeftLabel.Text = "( Pg#";
            this.gnollLeftLabel.Visible = false;
            // 
            // gnollRightLabel
            // 
            this.gnollRightLabel.AutoSize = true;
            this.gnollRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.gnollRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gnollRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.gnollRightLabel.Location = new System.Drawing.Point(384, 33);
            this.gnollRightLabel.Name = "gnollRightLabel";
            this.gnollRightLabel.Size = new System.Drawing.Size(29, 27);
            this.gnollRightLabel.TabIndex = 128;
            this.gnollRightLabel.Text = "   )";
            this.gnollRightLabel.Visible = false;
            // 
            // goblinComboBox
            // 
            this.goblinComboBox.BackColor = System.Drawing.Color.Black;
            this.goblinComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.goblinComboBox.FormattingEnabled = true;
            this.goblinComboBox.Location = new System.Drawing.Point(126, 37);
            this.goblinComboBox.Name = "goblinComboBox";
            this.goblinComboBox.Size = new System.Drawing.Size(149, 24);
            this.goblinComboBox.TabIndex = 129;
            this.goblinComboBox.Visible = false;
            this.goblinComboBox.SelectedIndexChanged += new System.EventHandler(this.goblinComboBox_SelectedIndexChanged);
            // 
            // goblinArrowBox
            // 
            this.goblinArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.goblinArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("goblinArrowBox.Image")));
            this.goblinArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("goblinArrowBox.InitialImage")));
            this.goblinArrowBox.Location = new System.Drawing.Point(292, 41);
            this.goblinArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.goblinArrowBox.Name = "goblinArrowBox";
            this.goblinArrowBox.Size = new System.Drawing.Size(21, 20);
            this.goblinArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.goblinArrowBox.TabIndex = 130;
            this.goblinArrowBox.TabStop = false;
            this.goblinArrowBox.Visible = false;
            // 
            // goblinLeftLabel
            // 
            this.goblinLeftLabel.AutoSize = true;
            this.goblinLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.goblinLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goblinLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.goblinLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.goblinLeftLabel.Name = "goblinLeftLabel";
            this.goblinLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.goblinLeftLabel.TabIndex = 131;
            this.goblinLeftLabel.Text = "( Pg#";
            this.goblinLeftLabel.Visible = false;
            // 
            // goblinRightLabel
            // 
            this.goblinRightLabel.AutoSize = true;
            this.goblinRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.goblinRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.goblinRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.goblinRightLabel.Location = new System.Drawing.Point(384, 33);
            this.goblinRightLabel.Name = "goblinRightLabel";
            this.goblinRightLabel.Size = new System.Drawing.Size(29, 27);
            this.goblinRightLabel.TabIndex = 132;
            this.goblinRightLabel.Text = "   )";
            this.goblinRightLabel.Visible = false;
            // 
            // golemArrowBox
            // 
            this.golemArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.golemArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("golemArrowBox.Image")));
            this.golemArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("golemArrowBox.InitialImage")));
            this.golemArrowBox.Location = new System.Drawing.Point(295, 41);
            this.golemArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.golemArrowBox.Name = "golemArrowBox";
            this.golemArrowBox.Size = new System.Drawing.Size(21, 20);
            this.golemArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.golemArrowBox.TabIndex = 133;
            this.golemArrowBox.TabStop = false;
            this.golemArrowBox.Visible = false;
            // 
            // golemLeftLabel
            // 
            this.golemLeftLabel.AutoSize = true;
            this.golemLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.golemLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.golemLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.golemLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.golemLeftLabel.Name = "golemLeftLabel";
            this.golemLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.golemLeftLabel.TabIndex = 134;
            this.golemLeftLabel.Text = "( Pg#";
            this.golemLeftLabel.Visible = false;
            // 
            // golemRightLabel
            // 
            this.golemRightLabel.AutoSize = true;
            this.golemRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.golemRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.golemRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.golemRightLabel.Location = new System.Drawing.Point(384, 33);
            this.golemRightLabel.Name = "golemRightLabel";
            this.golemRightLabel.Size = new System.Drawing.Size(29, 27);
            this.golemRightLabel.TabIndex = 135;
            this.golemRightLabel.Text = "   )";
            this.golemRightLabel.Visible = false;
            // 
            // grickComboBox
            // 
            this.grickComboBox.BackColor = System.Drawing.Color.Black;
            this.grickComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.grickComboBox.FormattingEnabled = true;
            this.grickComboBox.Location = new System.Drawing.Point(125, 37);
            this.grickComboBox.Name = "grickComboBox";
            this.grickComboBox.Size = new System.Drawing.Size(160, 24);
            this.grickComboBox.TabIndex = 136;
            this.grickComboBox.Visible = false;
            this.grickComboBox.SelectedIndexChanged += new System.EventHandler(this.grickComboBox_SelectedIndexChanged);
            // 
            // grickArrowBox
            // 
            this.grickArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.grickArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("grickArrowBox.Image")));
            this.grickArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("grickArrowBox.InitialImage")));
            this.grickArrowBox.Location = new System.Drawing.Point(296, 40);
            this.grickArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.grickArrowBox.Name = "grickArrowBox";
            this.grickArrowBox.Size = new System.Drawing.Size(21, 20);
            this.grickArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.grickArrowBox.TabIndex = 137;
            this.grickArrowBox.TabStop = false;
            this.grickArrowBox.Visible = false;
            // 
            // grickLeftLabel
            // 
            this.grickLeftLabel.AutoSize = true;
            this.grickLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.grickLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grickLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.grickLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.grickLeftLabel.Name = "grickLeftLabel";
            this.grickLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.grickLeftLabel.TabIndex = 138;
            this.grickLeftLabel.Text = "( Pg#";
            this.grickLeftLabel.Visible = false;
            // 
            // grickRightLabel
            // 
            this.grickRightLabel.AutoSize = true;
            this.grickRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.grickRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grickRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.grickRightLabel.Location = new System.Drawing.Point(384, 33);
            this.grickRightLabel.Name = "grickRightLabel";
            this.grickRightLabel.Size = new System.Drawing.Size(29, 27);
            this.grickRightLabel.TabIndex = 139;
            this.grickRightLabel.Text = "   )";
            this.grickRightLabel.Visible = false;
            // 
            // hagArrowBox
            // 
            this.hagArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.hagArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("hagArrowBox.Image")));
            this.hagArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("hagArrowBox.InitialImage")));
            this.hagArrowBox.Location = new System.Drawing.Point(295, 39);
            this.hagArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hagArrowBox.Name = "hagArrowBox";
            this.hagArrowBox.Size = new System.Drawing.Size(21, 20);
            this.hagArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.hagArrowBox.TabIndex = 140;
            this.hagArrowBox.TabStop = false;
            this.hagArrowBox.Visible = false;
            // 
            // hagLeftLabel
            // 
            this.hagLeftLabel.AutoSize = true;
            this.hagLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.hagLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hagLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.hagLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.hagLeftLabel.Name = "hagLeftLabel";
            this.hagLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.hagLeftLabel.TabIndex = 141;
            this.hagLeftLabel.Text = "( Pg#";
            this.hagLeftLabel.Visible = false;
            // 
            // hagRightLabel
            // 
            this.hagRightLabel.AutoSize = true;
            this.hagRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.hagRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hagRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.hagRightLabel.Location = new System.Drawing.Point(384, 33);
            this.hagRightLabel.Name = "hagRightLabel";
            this.hagRightLabel.Size = new System.Drawing.Size(29, 27);
            this.hagRightLabel.TabIndex = 142;
            this.hagRightLabel.Text = "   )";
            this.hagRightLabel.Visible = false;
            // 
            // hobgoblinArrowBox
            // 
            this.hobgoblinArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.hobgoblinArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("hobgoblinArrowBox.Image")));
            this.hobgoblinArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("hobgoblinArrowBox.InitialImage")));
            this.hobgoblinArrowBox.Location = new System.Drawing.Point(295, 40);
            this.hobgoblinArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.hobgoblinArrowBox.Name = "hobgoblinArrowBox";
            this.hobgoblinArrowBox.Size = new System.Drawing.Size(21, 20);
            this.hobgoblinArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.hobgoblinArrowBox.TabIndex = 143;
            this.hobgoblinArrowBox.TabStop = false;
            this.hobgoblinArrowBox.Visible = false;
            // 
            // hobgoblinLeftLabel
            // 
            this.hobgoblinLeftLabel.AutoSize = true;
            this.hobgoblinLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.hobgoblinLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hobgoblinLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.hobgoblinLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.hobgoblinLeftLabel.Name = "hobgoblinLeftLabel";
            this.hobgoblinLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.hobgoblinLeftLabel.TabIndex = 144;
            this.hobgoblinLeftLabel.Text = "( Pg#";
            this.hobgoblinLeftLabel.Visible = false;
            // 
            // hobgoblinRightLabel
            // 
            this.hobgoblinRightLabel.AutoSize = true;
            this.hobgoblinRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.hobgoblinRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hobgoblinRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.hobgoblinRightLabel.Location = new System.Drawing.Point(384, 33);
            this.hobgoblinRightLabel.Name = "hobgoblinRightLabel";
            this.hobgoblinRightLabel.Size = new System.Drawing.Size(29, 27);
            this.hobgoblinRightLabel.TabIndex = 145;
            this.hobgoblinRightLabel.Text = "   )";
            this.hobgoblinRightLabel.Visible = false;
            // 
            // koboldArrowBox
            // 
            this.koboldArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.koboldArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("koboldArrowBox.Image")));
            this.koboldArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("koboldArrowBox.InitialImage")));
            this.koboldArrowBox.Location = new System.Drawing.Point(292, 40);
            this.koboldArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.koboldArrowBox.Name = "koboldArrowBox";
            this.koboldArrowBox.Size = new System.Drawing.Size(21, 20);
            this.koboldArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.koboldArrowBox.TabIndex = 146;
            this.koboldArrowBox.TabStop = false;
            this.koboldArrowBox.Visible = false;
            // 
            // koboldLeftLabel
            // 
            this.koboldLeftLabel.AutoSize = true;
            this.koboldLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.koboldLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.koboldLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.koboldLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.koboldLeftLabel.Name = "koboldLeftLabel";
            this.koboldLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.koboldLeftLabel.TabIndex = 147;
            this.koboldLeftLabel.Text = "( Pg#";
            this.koboldLeftLabel.Visible = false;
            // 
            // koboldRightLabel
            // 
            this.koboldRightLabel.AutoSize = true;
            this.koboldRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.koboldRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.koboldRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.koboldRightLabel.Location = new System.Drawing.Point(384, 33);
            this.koboldRightLabel.Name = "koboldRightLabel";
            this.koboldRightLabel.Size = new System.Drawing.Size(29, 27);
            this.koboldRightLabel.TabIndex = 148;
            this.koboldRightLabel.Text = "   )";
            this.koboldRightLabel.Visible = false;
            // 
            // kuoArrowBox
            // 
            this.kuoArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.kuoArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("kuoArrowBox.Image")));
            this.kuoArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("kuoArrowBox.InitialImage")));
            this.kuoArrowBox.Location = new System.Drawing.Point(292, 40);
            this.kuoArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.kuoArrowBox.Name = "kuoArrowBox";
            this.kuoArrowBox.Size = new System.Drawing.Size(21, 20);
            this.kuoArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kuoArrowBox.TabIndex = 149;
            this.kuoArrowBox.TabStop = false;
            this.kuoArrowBox.Visible = false;
            // 
            // kuoLeftLabel
            // 
            this.kuoLeftLabel.AutoSize = true;
            this.kuoLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.kuoLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kuoLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.kuoLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.kuoLeftLabel.Name = "kuoLeftLabel";
            this.kuoLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.kuoLeftLabel.TabIndex = 150;
            this.kuoLeftLabel.Text = "( Pg#";
            this.kuoLeftLabel.Visible = false;
            // 
            // kuoRightLabel
            // 
            this.kuoRightLabel.AutoSize = true;
            this.kuoRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.kuoRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kuoRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.kuoRightLabel.Location = new System.Drawing.Point(384, 33);
            this.kuoRightLabel.Name = "kuoRightLabel";
            this.kuoRightLabel.Size = new System.Drawing.Size(29, 27);
            this.kuoRightLabel.TabIndex = 151;
            this.kuoRightLabel.Text = "   )";
            this.kuoRightLabel.Visible = false;
            // 
            // lizardfolkArrowBox
            // 
            this.lizardfolkArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.lizardfolkArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("lizardfolkArrowBox.Image")));
            this.lizardfolkArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("lizardfolkArrowBox.InitialImage")));
            this.lizardfolkArrowBox.Location = new System.Drawing.Point(292, 39);
            this.lizardfolkArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lizardfolkArrowBox.Name = "lizardfolkArrowBox";
            this.lizardfolkArrowBox.Size = new System.Drawing.Size(21, 20);
            this.lizardfolkArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lizardfolkArrowBox.TabIndex = 152;
            this.lizardfolkArrowBox.TabStop = false;
            this.lizardfolkArrowBox.Visible = false;
            // 
            // lizardfolkLeftLabel
            // 
            this.lizardfolkLeftLabel.AutoSize = true;
            this.lizardfolkLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.lizardfolkLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lizardfolkLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.lizardfolkLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.lizardfolkLeftLabel.Name = "lizardfolkLeftLabel";
            this.lizardfolkLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.lizardfolkLeftLabel.TabIndex = 153;
            this.lizardfolkLeftLabel.Text = "( Pg#";
            this.lizardfolkLeftLabel.Visible = false;
            // 
            // lizardfolkRightLabel
            // 
            this.lizardfolkRightLabel.AutoSize = true;
            this.lizardfolkRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.lizardfolkRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lizardfolkRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.lizardfolkRightLabel.Location = new System.Drawing.Point(384, 33);
            this.lizardfolkRightLabel.Name = "lizardfolkRightLabel";
            this.lizardfolkRightLabel.Size = new System.Drawing.Size(29, 27);
            this.lizardfolkRightLabel.TabIndex = 154;
            this.lizardfolkRightLabel.Text = "   )";
            this.lizardfolkRightLabel.Visible = false;
            // 
            // lycanArrowBox
            // 
            this.lycanArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.lycanArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("lycanArrowBox.Image")));
            this.lycanArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("lycanArrowBox.InitialImage")));
            this.lycanArrowBox.Location = new System.Drawing.Point(291, 38);
            this.lycanArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lycanArrowBox.Name = "lycanArrowBox";
            this.lycanArrowBox.Size = new System.Drawing.Size(21, 20);
            this.lycanArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lycanArrowBox.TabIndex = 155;
            this.lycanArrowBox.TabStop = false;
            this.lycanArrowBox.Visible = false;
            // 
            // lycanLeftLabel
            // 
            this.lycanLeftLabel.AutoSize = true;
            this.lycanLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.lycanLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lycanLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.lycanLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.lycanLeftLabel.Name = "lycanLeftLabel";
            this.lycanLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.lycanLeftLabel.TabIndex = 156;
            this.lycanLeftLabel.Text = "( Pg#";
            this.lycanLeftLabel.Visible = false;
            // 
            // lycanRightLabel
            // 
            this.lycanRightLabel.AutoSize = true;
            this.lycanRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.lycanRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lycanRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.lycanRightLabel.Location = new System.Drawing.Point(384, 33);
            this.lycanRightLabel.Name = "lycanRightLabel";
            this.lycanRightLabel.Size = new System.Drawing.Size(29, 27);
            this.lycanRightLabel.TabIndex = 157;
            this.lycanRightLabel.Text = "   )";
            this.lycanRightLabel.Visible = false;
            // 
            // mephitArrowBox
            // 
            this.mephitArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.mephitArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("mephitArrowBox.Image")));
            this.mephitArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("mephitArrowBox.InitialImage")));
            this.mephitArrowBox.Location = new System.Drawing.Point(291, 40);
            this.mephitArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mephitArrowBox.Name = "mephitArrowBox";
            this.mephitArrowBox.Size = new System.Drawing.Size(21, 20);
            this.mephitArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mephitArrowBox.TabIndex = 158;
            this.mephitArrowBox.TabStop = false;
            this.mephitArrowBox.Visible = false;
            // 
            // mephitLeftLabel
            // 
            this.mephitLeftLabel.AutoSize = true;
            this.mephitLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.mephitLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mephitLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.mephitLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.mephitLeftLabel.Name = "mephitLeftLabel";
            this.mephitLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.mephitLeftLabel.TabIndex = 159;
            this.mephitLeftLabel.Text = "( Pg#";
            this.mephitLeftLabel.Visible = false;
            // 
            // mephitRightLabel
            // 
            this.mephitRightLabel.AutoSize = true;
            this.mephitRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.mephitRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mephitRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.mephitRightLabel.Location = new System.Drawing.Point(384, 33);
            this.mephitRightLabel.Name = "mephitRightLabel";
            this.mephitRightLabel.Size = new System.Drawing.Size(29, 27);
            this.mephitRightLabel.TabIndex = 160;
            this.mephitRightLabel.Text = "   )";
            this.mephitRightLabel.Visible = false;
            // 
            // modroneArrowBox
            // 
            this.modroneArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.modroneArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("modroneArrowBox.Image")));
            this.modroneArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("modroneArrowBox.InitialImage")));
            this.modroneArrowBox.Location = new System.Drawing.Point(292, 38);
            this.modroneArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.modroneArrowBox.Name = "modroneArrowBox";
            this.modroneArrowBox.Size = new System.Drawing.Size(21, 20);
            this.modroneArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.modroneArrowBox.TabIndex = 161;
            this.modroneArrowBox.TabStop = false;
            this.modroneArrowBox.Visible = false;
            // 
            // modroneLeftLabel
            // 
            this.modroneLeftLabel.AutoSize = true;
            this.modroneLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.modroneLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modroneLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.modroneLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.modroneLeftLabel.Name = "modroneLeftLabel";
            this.modroneLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.modroneLeftLabel.TabIndex = 162;
            this.modroneLeftLabel.Text = "( Pg#";
            this.modroneLeftLabel.Visible = false;
            // 
            // modroneRightLabel
            // 
            this.modroneRightLabel.AutoSize = true;
            this.modroneRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.modroneRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modroneRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.modroneRightLabel.Location = new System.Drawing.Point(384, 33);
            this.modroneRightLabel.Name = "modroneRightLabel";
            this.modroneRightLabel.Size = new System.Drawing.Size(29, 27);
            this.modroneRightLabel.TabIndex = 163;
            this.modroneRightLabel.Text = "   )";
            this.modroneRightLabel.Visible = false;
            // 
            // mummyComboBox
            // 
            this.mummyComboBox.BackColor = System.Drawing.Color.Black;
            this.mummyComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.mummyComboBox.FormattingEnabled = true;
            this.mummyComboBox.Location = new System.Drawing.Point(128, 38);
            this.mummyComboBox.Name = "mummyComboBox";
            this.mummyComboBox.Size = new System.Drawing.Size(162, 24);
            this.mummyComboBox.TabIndex = 164;
            this.mummyComboBox.Visible = false;
            this.mummyComboBox.SelectedIndexChanged += new System.EventHandler(this.mummyComboBox_SelectedIndexChanged);
            // 
            // mummyArrowBox
            // 
            this.mummyArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.mummyArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("mummyArrowBox.Image")));
            this.mummyArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("mummyArrowBox.InitialImage")));
            this.mummyArrowBox.Location = new System.Drawing.Point(292, 39);
            this.mummyArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mummyArrowBox.Name = "mummyArrowBox";
            this.mummyArrowBox.Size = new System.Drawing.Size(21, 20);
            this.mummyArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mummyArrowBox.TabIndex = 165;
            this.mummyArrowBox.TabStop = false;
            this.mummyArrowBox.Visible = false;
            // 
            // mummyLeftLabel
            // 
            this.mummyLeftLabel.AutoSize = true;
            this.mummyLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.mummyLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mummyLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.mummyLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.mummyLeftLabel.Name = "mummyLeftLabel";
            this.mummyLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.mummyLeftLabel.TabIndex = 166;
            this.mummyLeftLabel.Text = "( Pg#";
            this.mummyLeftLabel.Visible = false;
            // 
            // mummyRightLabel
            // 
            this.mummyRightLabel.AutoSize = true;
            this.mummyRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.mummyRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mummyRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.mummyRightLabel.Location = new System.Drawing.Point(384, 33);
            this.mummyRightLabel.Name = "mummyRightLabel";
            this.mummyRightLabel.Size = new System.Drawing.Size(29, 27);
            this.mummyRightLabel.TabIndex = 167;
            this.mummyRightLabel.Text = "   )";
            this.mummyRightLabel.Visible = false;
            // 
            // myconidArrowBox
            // 
            this.myconidArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.myconidArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("myconidArrowBox.Image")));
            this.myconidArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("myconidArrowBox.InitialImage")));
            this.myconidArrowBox.Location = new System.Drawing.Point(292, 38);
            this.myconidArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.myconidArrowBox.Name = "myconidArrowBox";
            this.myconidArrowBox.Size = new System.Drawing.Size(21, 20);
            this.myconidArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myconidArrowBox.TabIndex = 168;
            this.myconidArrowBox.TabStop = false;
            this.myconidArrowBox.Visible = false;
            // 
            // myconidLeftLabel
            // 
            this.myconidLeftLabel.AutoSize = true;
            this.myconidLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.myconidLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myconidLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.myconidLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.myconidLeftLabel.Name = "myconidLeftLabel";
            this.myconidLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.myconidLeftLabel.TabIndex = 169;
            this.myconidLeftLabel.Text = "( Pg#";
            this.myconidLeftLabel.Visible = false;
            // 
            // myconidRightLabel
            // 
            this.myconidRightLabel.AutoSize = true;
            this.myconidRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.myconidRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.myconidRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.myconidRightLabel.Location = new System.Drawing.Point(384, 33);
            this.myconidRightLabel.Name = "myconidRightLabel";
            this.myconidRightLabel.Size = new System.Drawing.Size(29, 27);
            this.myconidRightLabel.TabIndex = 170;
            this.myconidRightLabel.Text = "   )";
            this.myconidRightLabel.Visible = false;
            // 
            // nagaLeftLabel
            // 
            this.nagaLeftLabel.AutoSize = true;
            this.nagaLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.nagaLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nagaLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.nagaLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.nagaLeftLabel.Name = "nagaLeftLabel";
            this.nagaLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.nagaLeftLabel.TabIndex = 172;
            this.nagaLeftLabel.Text = "( Pg#";
            this.nagaLeftLabel.Visible = false;
            // 
            // nagaRightLabel
            // 
            this.nagaRightLabel.AutoSize = true;
            this.nagaRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.nagaRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nagaRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.nagaRightLabel.Location = new System.Drawing.Point(384, 33);
            this.nagaRightLabel.Name = "nagaRightLabel";
            this.nagaRightLabel.Size = new System.Drawing.Size(29, 27);
            this.nagaRightLabel.TabIndex = 173;
            this.nagaRightLabel.Text = "   )";
            this.nagaRightLabel.Visible = false;
            // 
            // nagaArrowBox
            // 
            this.nagaArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.nagaArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("nagaArrowBox.Image")));
            this.nagaArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("nagaArrowBox.InitialImage")));
            this.nagaArrowBox.Location = new System.Drawing.Point(292, 39);
            this.nagaArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nagaArrowBox.Name = "nagaArrowBox";
            this.nagaArrowBox.Size = new System.Drawing.Size(21, 20);
            this.nagaArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.nagaArrowBox.TabIndex = 171;
            this.nagaArrowBox.TabStop = false;
            this.nagaArrowBox.Visible = false;
            // 
            // ogreArrowBox
            // 
            this.ogreArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.ogreArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("ogreArrowBox.Image")));
            this.ogreArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("ogreArrowBox.InitialImage")));
            this.ogreArrowBox.Location = new System.Drawing.Point(292, 40);
            this.ogreArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ogreArrowBox.Name = "ogreArrowBox";
            this.ogreArrowBox.Size = new System.Drawing.Size(21, 20);
            this.ogreArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ogreArrowBox.TabIndex = 174;
            this.ogreArrowBox.TabStop = false;
            this.ogreArrowBox.Visible = false;
            // 
            // ogreLeftLabel
            // 
            this.ogreLeftLabel.AutoSize = true;
            this.ogreLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.ogreLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ogreLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.ogreLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.ogreLeftLabel.Name = "ogreLeftLabel";
            this.ogreLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.ogreLeftLabel.TabIndex = 175;
            this.ogreLeftLabel.Text = "( Pg#";
            this.ogreLeftLabel.Visible = false;
            // 
            // ogreRightLabel
            // 
            this.ogreRightLabel.AutoSize = true;
            this.ogreRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.ogreRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ogreRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.ogreRightLabel.Location = new System.Drawing.Point(384, 33);
            this.ogreRightLabel.Name = "ogreRightLabel";
            this.ogreRightLabel.Size = new System.Drawing.Size(29, 27);
            this.ogreRightLabel.TabIndex = 176;
            this.ogreRightLabel.Text = "   )";
            this.ogreRightLabel.Visible = false;
            // 
            // zombieArrowBox
            // 
            this.zombieArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.zombieArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("zombieArrowBox.Image")));
            this.zombieArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("zombieArrowBox.InitialImage")));
            this.zombieArrowBox.Location = new System.Drawing.Point(292, 39);
            this.zombieArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.zombieArrowBox.Name = "zombieArrowBox";
            this.zombieArrowBox.Size = new System.Drawing.Size(21, 20);
            this.zombieArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.zombieArrowBox.TabIndex = 177;
            this.zombieArrowBox.TabStop = false;
            this.zombieArrowBox.Visible = false;
            // 
            // zombieLeftLabel
            // 
            this.zombieLeftLabel.AutoSize = true;
            this.zombieLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.zombieLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zombieLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.zombieLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.zombieLeftLabel.Name = "zombieLeftLabel";
            this.zombieLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.zombieLeftLabel.TabIndex = 178;
            this.zombieLeftLabel.Text = "( Pg#";
            this.zombieLeftLabel.Visible = false;
            // 
            // zombieRightLabel
            // 
            this.zombieRightLabel.AutoSize = true;
            this.zombieRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.zombieRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zombieRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.zombieRightLabel.Location = new System.Drawing.Point(384, 33);
            this.zombieRightLabel.Name = "zombieRightLabel";
            this.zombieRightLabel.Size = new System.Drawing.Size(29, 27);
            this.zombieRightLabel.TabIndex = 179;
            this.zombieRightLabel.Text = "   )";
            this.zombieRightLabel.Visible = false;
            // 
            // yugoArrowBox
            // 
            this.yugoArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.yugoArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("yugoArrowBox.Image")));
            this.yugoArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("yugoArrowBox.InitialImage")));
            this.yugoArrowBox.Location = new System.Drawing.Point(292, 38);
            this.yugoArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.yugoArrowBox.Name = "yugoArrowBox";
            this.yugoArrowBox.Size = new System.Drawing.Size(21, 20);
            this.yugoArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.yugoArrowBox.TabIndex = 180;
            this.yugoArrowBox.TabStop = false;
            this.yugoArrowBox.Visible = false;
            // 
            // yugoLeftLabel
            // 
            this.yugoLeftLabel.AutoSize = true;
            this.yugoLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.yugoLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yugoLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yugoLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.yugoLeftLabel.Name = "yugoLeftLabel";
            this.yugoLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.yugoLeftLabel.TabIndex = 181;
            this.yugoLeftLabel.Text = "( Pg#";
            this.yugoLeftLabel.Visible = false;
            // 
            // yugoRightLabel
            // 
            this.yugoRightLabel.AutoSize = true;
            this.yugoRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.yugoRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yugoRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yugoRightLabel.Location = new System.Drawing.Point(384, 33);
            this.yugoRightLabel.Name = "yugoRightLabel";
            this.yugoRightLabel.Size = new System.Drawing.Size(29, 27);
            this.yugoRightLabel.TabIndex = 182;
            this.yugoRightLabel.Text = "   )";
            this.yugoRightLabel.Visible = false;
            // 
            // yuanArrowBox
            // 
            this.yuanArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.yuanArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("yuanArrowBox.Image")));
            this.yuanArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("yuanArrowBox.InitialImage")));
            this.yuanArrowBox.Location = new System.Drawing.Point(292, 38);
            this.yuanArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.yuanArrowBox.Name = "yuanArrowBox";
            this.yuanArrowBox.Size = new System.Drawing.Size(21, 20);
            this.yuanArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.yuanArrowBox.TabIndex = 183;
            this.yuanArrowBox.TabStop = false;
            this.yuanArrowBox.Visible = false;
            // 
            // yuanLeftLabel
            // 
            this.yuanLeftLabel.AutoSize = true;
            this.yuanLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.yuanLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yuanLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yuanLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.yuanLeftLabel.Name = "yuanLeftLabel";
            this.yuanLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.yuanLeftLabel.TabIndex = 184;
            this.yuanLeftLabel.Text = "( Pg#";
            this.yuanLeftLabel.Visible = false;
            // 
            // yuanRightLabel
            // 
            this.yuanRightLabel.AutoSize = true;
            this.yuanRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.yuanRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yuanRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yuanRightLabel.Location = new System.Drawing.Point(384, 33);
            this.yuanRightLabel.Name = "yuanRightLabel";
            this.yuanRightLabel.Size = new System.Drawing.Size(29, 27);
            this.yuanRightLabel.TabIndex = 185;
            this.yuanRightLabel.Text = "   )";
            this.yuanRightLabel.Visible = false;
            // 
            // yetiArrowBox
            // 
            this.yetiArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.yetiArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("yetiArrowBox.Image")));
            this.yetiArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("yetiArrowBox.InitialImage")));
            this.yetiArrowBox.Location = new System.Drawing.Point(295, 40);
            this.yetiArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.yetiArrowBox.Name = "yetiArrowBox";
            this.yetiArrowBox.Size = new System.Drawing.Size(21, 20);
            this.yetiArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.yetiArrowBox.TabIndex = 186;
            this.yetiArrowBox.TabStop = false;
            this.yetiArrowBox.Visible = false;
            // 
            // yetiLeftLabel
            // 
            this.yetiLeftLabel.AutoSize = true;
            this.yetiLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.yetiLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yetiLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yetiLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.yetiLeftLabel.Name = "yetiLeftLabel";
            this.yetiLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.yetiLeftLabel.TabIndex = 187;
            this.yetiLeftLabel.Text = "( Pg#";
            this.yetiLeftLabel.Visible = false;
            // 
            // yetiRightLabel
            // 
            this.yetiRightLabel.AutoSize = true;
            this.yetiRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.yetiRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yetiRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yetiRightLabel.Location = new System.Drawing.Point(384, 33);
            this.yetiRightLabel.Name = "yetiRightLabel";
            this.yetiRightLabel.Size = new System.Drawing.Size(29, 27);
            this.yetiRightLabel.TabIndex = 188;
            this.yetiRightLabel.Text = "   )";
            this.yetiRightLabel.Visible = false;
            // 
            // vampireArrowBox
            // 
            this.vampireArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.vampireArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("vampireArrowBox.Image")));
            this.vampireArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("vampireArrowBox.InitialImage")));
            this.vampireArrowBox.Location = new System.Drawing.Point(296, 42);
            this.vampireArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.vampireArrowBox.Name = "vampireArrowBox";
            this.vampireArrowBox.Size = new System.Drawing.Size(21, 20);
            this.vampireArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.vampireArrowBox.TabIndex = 189;
            this.vampireArrowBox.TabStop = false;
            this.vampireArrowBox.Visible = false;
            // 
            // vampireLeftLabel
            // 
            this.vampireLeftLabel.AutoSize = true;
            this.vampireLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.vampireLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vampireLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.vampireLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.vampireLeftLabel.Name = "vampireLeftLabel";
            this.vampireLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.vampireLeftLabel.TabIndex = 190;
            this.vampireLeftLabel.Text = "( Pg#";
            this.vampireLeftLabel.Visible = false;
            // 
            // vampireRightLabel
            // 
            this.vampireRightLabel.AutoSize = true;
            this.vampireRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.vampireRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vampireRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.vampireRightLabel.Location = new System.Drawing.Point(384, 33);
            this.vampireRightLabel.Name = "vampireRightLabel";
            this.vampireRightLabel.Size = new System.Drawing.Size(29, 27);
            this.vampireRightLabel.TabIndex = 191;
            this.vampireRightLabel.Text = "   )";
            this.vampireRightLabel.Visible = false;
            // 
            // sphinxArrowBox
            // 
            this.sphinxArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.sphinxArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("sphinxArrowBox.Image")));
            this.sphinxArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("sphinxArrowBox.InitialImage")));
            this.sphinxArrowBox.Location = new System.Drawing.Point(294, 41);
            this.sphinxArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sphinxArrowBox.Name = "sphinxArrowBox";
            this.sphinxArrowBox.Size = new System.Drawing.Size(21, 20);
            this.sphinxArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sphinxArrowBox.TabIndex = 192;
            this.sphinxArrowBox.TabStop = false;
            this.sphinxArrowBox.Visible = false;
            // 
            // sphinxLeftLabel
            // 
            this.sphinxLeftLabel.AutoSize = true;
            this.sphinxLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.sphinxLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sphinxLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.sphinxLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.sphinxLeftLabel.Name = "sphinxLeftLabel";
            this.sphinxLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.sphinxLeftLabel.TabIndex = 193;
            this.sphinxLeftLabel.Text = "( Pg#";
            this.sphinxLeftLabel.Visible = false;
            // 
            // sphinxRightLabel
            // 
            this.sphinxRightLabel.AutoSize = true;
            this.sphinxRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.sphinxRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sphinxRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.sphinxRightLabel.Location = new System.Drawing.Point(384, 33);
            this.sphinxRightLabel.Name = "sphinxRightLabel";
            this.sphinxRightLabel.Size = new System.Drawing.Size(29, 27);
            this.sphinxRightLabel.TabIndex = 194;
            this.sphinxRightLabel.Text = "   )";
            this.sphinxRightLabel.Visible = false;
            // 
            // sladdiArrowBox
            // 
            this.sladdiArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.sladdiArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("sladdiArrowBox.Image")));
            this.sladdiArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("sladdiArrowBox.InitialImage")));
            this.sladdiArrowBox.Location = new System.Drawing.Point(292, 41);
            this.sladdiArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sladdiArrowBox.Name = "sladdiArrowBox";
            this.sladdiArrowBox.Size = new System.Drawing.Size(21, 20);
            this.sladdiArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sladdiArrowBox.TabIndex = 195;
            this.sladdiArrowBox.TabStop = false;
            this.sladdiArrowBox.Visible = false;
            // 
            // sahuginArrowBox
            // 
            this.sahuginArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.sahuginArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("sahuginArrowBox.Image")));
            this.sahuginArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("sahuginArrowBox.InitialImage")));
            this.sahuginArrowBox.Location = new System.Drawing.Point(292, 41);
            this.sahuginArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sahuginArrowBox.Name = "sahuginArrowBox";
            this.sahuginArrowBox.Size = new System.Drawing.Size(21, 20);
            this.sahuginArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.sahuginArrowBox.TabIndex = 196;
            this.sahuginArrowBox.TabStop = false;
            this.sahuginArrowBox.Visible = false;
            // 
            // oozeArrowBox
            // 
            this.oozeArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.oozeArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("oozeArrowBox.Image")));
            this.oozeArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("oozeArrowBox.InitialImage")));
            this.oozeArrowBox.Location = new System.Drawing.Point(294, 41);
            this.oozeArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.oozeArrowBox.Name = "oozeArrowBox";
            this.oozeArrowBox.Size = new System.Drawing.Size(21, 20);
            this.oozeArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.oozeArrowBox.TabIndex = 197;
            this.oozeArrowBox.TabStop = false;
            this.oozeArrowBox.Visible = false;
            // 
            // skeletonArrowBox
            // 
            this.skeletonArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.skeletonArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("skeletonArrowBox.Image")));
            this.skeletonArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("skeletonArrowBox.InitialImage")));
            this.skeletonArrowBox.Location = new System.Drawing.Point(295, 42);
            this.skeletonArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.skeletonArrowBox.Name = "skeletonArrowBox";
            this.skeletonArrowBox.Size = new System.Drawing.Size(21, 20);
            this.skeletonArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.skeletonArrowBox.TabIndex = 198;
            this.skeletonArrowBox.TabStop = false;
            this.skeletonArrowBox.Visible = false;
            // 
            // salamanderArrowBox
            // 
            this.salamanderArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.salamanderArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("salamanderArrowBox.Image")));
            this.salamanderArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("salamanderArrowBox.InitialImage")));
            this.salamanderArrowBox.Location = new System.Drawing.Point(296, 40);
            this.salamanderArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.salamanderArrowBox.Name = "salamanderArrowBox";
            this.salamanderArrowBox.Size = new System.Drawing.Size(21, 20);
            this.salamanderArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.salamanderArrowBox.TabIndex = 199;
            this.salamanderArrowBox.TabStop = false;
            this.salamanderArrowBox.Visible = false;
            // 
            // remorhazeArrowBox
            // 
            this.remorhazeArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.remorhazeArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("remorhazeArrowBox.Image")));
            this.remorhazeArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("remorhazeArrowBox.InitialImage")));
            this.remorhazeArrowBox.Location = new System.Drawing.Point(295, 39);
            this.remorhazeArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.remorhazeArrowBox.Name = "remorhazeArrowBox";
            this.remorhazeArrowBox.Size = new System.Drawing.Size(21, 20);
            this.remorhazeArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.remorhazeArrowBox.TabIndex = 200;
            this.remorhazeArrowBox.TabStop = false;
            this.remorhazeArrowBox.Visible = false;
            // 
            // orcArrowBox
            // 
            this.orcArrowBox.BackColor = System.Drawing.Color.Transparent;
            this.orcArrowBox.Image = ((System.Drawing.Image)(resources.GetObject("orcArrowBox.Image")));
            this.orcArrowBox.InitialImage = ((System.Drawing.Image)(resources.GetObject("orcArrowBox.InitialImage")));
            this.orcArrowBox.Location = new System.Drawing.Point(294, 40);
            this.orcArrowBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.orcArrowBox.Name = "orcArrowBox";
            this.orcArrowBox.Size = new System.Drawing.Size(21, 20);
            this.orcArrowBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.orcArrowBox.TabIndex = 201;
            this.orcArrowBox.TabStop = false;
            this.orcArrowBox.Visible = false;
            // 
            // oozeLeftLabel
            // 
            this.oozeLeftLabel.AutoSize = true;
            this.oozeLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.oozeLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oozeLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.oozeLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.oozeLeftLabel.Name = "oozeLeftLabel";
            this.oozeLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.oozeLeftLabel.TabIndex = 202;
            this.oozeLeftLabel.Text = "( Pg#";
            this.oozeLeftLabel.Visible = false;
            // 
            // orcLeftLabel
            // 
            this.orcLeftLabel.AutoSize = true;
            this.orcLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.orcLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orcLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.orcLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.orcLeftLabel.Name = "orcLeftLabel";
            this.orcLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.orcLeftLabel.TabIndex = 203;
            this.orcLeftLabel.Text = "( Pg#";
            this.orcLeftLabel.Visible = false;
            // 
            // slaadiLeftLabel
            // 
            this.slaadiLeftLabel.AutoSize = true;
            this.slaadiLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.slaadiLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slaadiLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.slaadiLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.slaadiLeftLabel.Name = "slaadiLeftLabel";
            this.slaadiLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.slaadiLeftLabel.TabIndex = 204;
            this.slaadiLeftLabel.Text = "( Pg#";
            this.slaadiLeftLabel.Visible = false;
            // 
            // salamanderLeftLabel
            // 
            this.salamanderLeftLabel.AutoSize = true;
            this.salamanderLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.salamanderLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salamanderLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.salamanderLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.salamanderLeftLabel.Name = "salamanderLeftLabel";
            this.salamanderLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.salamanderLeftLabel.TabIndex = 205;
            this.salamanderLeftLabel.Text = "( Pg#";
            this.salamanderLeftLabel.Visible = false;
            // 
            // sahuginLeftLabel
            // 
            this.sahuginLeftLabel.AutoSize = true;
            this.sahuginLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.sahuginLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sahuginLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.sahuginLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.sahuginLeftLabel.Name = "sahuginLeftLabel";
            this.sahuginLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.sahuginLeftLabel.TabIndex = 206;
            this.sahuginLeftLabel.Text = "( Pg#";
            this.sahuginLeftLabel.Visible = false;
            // 
            // yugolothLeftLabel
            // 
            this.yugolothLeftLabel.AutoSize = true;
            this.yugolothLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.yugolothLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yugolothLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yugolothLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.yugolothLeftLabel.Name = "yugolothLeftLabel";
            this.yugolothLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.yugolothLeftLabel.TabIndex = 207;
            this.yugolothLeftLabel.Text = "( Pg#";
            this.yugolothLeftLabel.Visible = false;
            // 
            // skeletonLeftLabel
            // 
            this.skeletonLeftLabel.AutoSize = true;
            this.skeletonLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.skeletonLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skeletonLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.skeletonLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.skeletonLeftLabel.Name = "skeletonLeftLabel";
            this.skeletonLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.skeletonLeftLabel.TabIndex = 208;
            this.skeletonLeftLabel.Text = "( Pg#";
            this.skeletonLeftLabel.Visible = false;
            // 
            // remorhazLeftLabel
            // 
            this.remorhazLeftLabel.AutoSize = true;
            this.remorhazLeftLabel.BackColor = System.Drawing.Color.Transparent;
            this.remorhazLeftLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remorhazLeftLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.remorhazLeftLabel.Location = new System.Drawing.Point(318, 34);
            this.remorhazLeftLabel.Name = "remorhazLeftLabel";
            this.remorhazLeftLabel.Size = new System.Drawing.Size(50, 27);
            this.remorhazLeftLabel.TabIndex = 209;
            this.remorhazLeftLabel.Text = "( Pg#";
            this.remorhazLeftLabel.Visible = false;
            // 
            // oozeRightLabel
            // 
            this.oozeRightLabel.AutoSize = true;
            this.oozeRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.oozeRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oozeRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.oozeRightLabel.Location = new System.Drawing.Point(384, 33);
            this.oozeRightLabel.Name = "oozeRightLabel";
            this.oozeRightLabel.Size = new System.Drawing.Size(29, 27);
            this.oozeRightLabel.TabIndex = 210;
            this.oozeRightLabel.Text = "   )";
            this.oozeRightLabel.Visible = false;
            // 
            // yugolothRightLabel
            // 
            this.yugolothRightLabel.AutoSize = true;
            this.yugolothRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.yugolothRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yugolothRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yugolothRightLabel.Location = new System.Drawing.Point(384, 33);
            this.yugolothRightLabel.Name = "yugolothRightLabel";
            this.yugolothRightLabel.Size = new System.Drawing.Size(29, 27);
            this.yugolothRightLabel.TabIndex = 211;
            this.yugolothRightLabel.Text = "   )";
            this.yugolothRightLabel.Visible = false;
            // 
            // skeletonRightLabel
            // 
            this.skeletonRightLabel.AutoSize = true;
            this.skeletonRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.skeletonRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.skeletonRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.skeletonRightLabel.Location = new System.Drawing.Point(384, 33);
            this.skeletonRightLabel.Name = "skeletonRightLabel";
            this.skeletonRightLabel.Size = new System.Drawing.Size(29, 27);
            this.skeletonRightLabel.TabIndex = 213;
            this.skeletonRightLabel.Text = "   )";
            this.skeletonRightLabel.Visible = false;
            // 
            // orcRightLabel
            // 
            this.orcRightLabel.AutoSize = true;
            this.orcRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.orcRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orcRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.orcRightLabel.Location = new System.Drawing.Point(384, 33);
            this.orcRightLabel.Name = "orcRightLabel";
            this.orcRightLabel.Size = new System.Drawing.Size(29, 27);
            this.orcRightLabel.TabIndex = 214;
            this.orcRightLabel.Text = "   )";
            this.orcRightLabel.Visible = false;
            // 
            // slaadiRightLabel
            // 
            this.slaadiRightLabel.AutoSize = true;
            this.slaadiRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.slaadiRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slaadiRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.slaadiRightLabel.Location = new System.Drawing.Point(384, 33);
            this.slaadiRightLabel.Name = "slaadiRightLabel";
            this.slaadiRightLabel.Size = new System.Drawing.Size(29, 27);
            this.slaadiRightLabel.TabIndex = 215;
            this.slaadiRightLabel.Text = "   )";
            this.slaadiRightLabel.Visible = false;
            // 
            // salamanderRightLabel
            // 
            this.salamanderRightLabel.AutoSize = true;
            this.salamanderRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.salamanderRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salamanderRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.salamanderRightLabel.Location = new System.Drawing.Point(384, 33);
            this.salamanderRightLabel.Name = "salamanderRightLabel";
            this.salamanderRightLabel.Size = new System.Drawing.Size(29, 27);
            this.salamanderRightLabel.TabIndex = 216;
            this.salamanderRightLabel.Text = "   )";
            this.salamanderRightLabel.Visible = false;
            // 
            // remorhazRightLabel
            // 
            this.remorhazRightLabel.AutoSize = true;
            this.remorhazRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.remorhazRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remorhazRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.remorhazRightLabel.Location = new System.Drawing.Point(384, 33);
            this.remorhazRightLabel.Name = "remorhazRightLabel";
            this.remorhazRightLabel.Size = new System.Drawing.Size(29, 27);
            this.remorhazRightLabel.TabIndex = 217;
            this.remorhazRightLabel.Text = "   )";
            this.remorhazRightLabel.Visible = false;
            // 
            // sahuginRightLabel
            // 
            this.sahuginRightLabel.AutoSize = true;
            this.sahuginRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.sahuginRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sahuginRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.sahuginRightLabel.Location = new System.Drawing.Point(384, 33);
            this.sahuginRightLabel.Name = "sahuginRightLabel";
            this.sahuginRightLabel.Size = new System.Drawing.Size(29, 27);
            this.sahuginRightLabel.TabIndex = 218;
            this.sahuginRightLabel.Text = "   )";
            this.sahuginRightLabel.Visible = false;
            // 
            // yuantiRightLabel
            // 
            this.yuantiRightLabel.AutoSize = true;
            this.yuantiRightLabel.BackColor = System.Drawing.Color.Transparent;
            this.yuantiRightLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yuantiRightLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.yuantiRightLabel.Location = new System.Drawing.Point(384, 33);
            this.yuantiRightLabel.Name = "yuantiRightLabel";
            this.yuantiRightLabel.Size = new System.Drawing.Size(29, 27);
            this.yuantiRightLabel.TabIndex = 219;
            this.yuantiRightLabel.Text = "   )";
            this.yuantiRightLabel.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(616, 502);
            this.Controls.Add(this.yuantiRightLabel);
            this.Controls.Add(this.sahuginRightLabel);
            this.Controls.Add(this.remorhazRightLabel);
            this.Controls.Add(this.salamanderRightLabel);
            this.Controls.Add(this.slaadiRightLabel);
            this.Controls.Add(this.orcRightLabel);
            this.Controls.Add(this.skeletonRightLabel);
            this.Controls.Add(this.yugolothRightLabel);
            this.Controls.Add(this.oozeRightLabel);
            this.Controls.Add(this.remorhazLeftLabel);
            this.Controls.Add(this.skeletonLeftLabel);
            this.Controls.Add(this.yugolothLeftLabel);
            this.Controls.Add(this.sahuginLeftLabel);
            this.Controls.Add(this.salamanderLeftLabel);
            this.Controls.Add(this.slaadiLeftLabel);
            this.Controls.Add(this.orcLeftLabel);
            this.Controls.Add(this.oozeLeftLabel);
            this.Controls.Add(this.orcArrowBox);
            this.Controls.Add(this.remorhazeArrowBox);
            this.Controls.Add(this.salamanderArrowBox);
            this.Controls.Add(this.skeletonArrowBox);
            this.Controls.Add(this.oozeArrowBox);
            this.Controls.Add(this.sahuginArrowBox);
            this.Controls.Add(this.sladdiArrowBox);
            this.Controls.Add(this.sphinxRightLabel);
            this.Controls.Add(this.sphinxLeftLabel);
            this.Controls.Add(this.sphinxArrowBox);
            this.Controls.Add(this.vampireRightLabel);
            this.Controls.Add(this.vampireLeftLabel);
            this.Controls.Add(this.vampireArrowBox);
            this.Controls.Add(this.yetiRightLabel);
            this.Controls.Add(this.yetiLeftLabel);
            this.Controls.Add(this.yetiArrowBox);
            this.Controls.Add(this.yuanRightLabel);
            this.Controls.Add(this.yuanLeftLabel);
            this.Controls.Add(this.yuanArrowBox);
            this.Controls.Add(this.yugoRightLabel);
            this.Controls.Add(this.yugoLeftLabel);
            this.Controls.Add(this.yugoArrowBox);
            this.Controls.Add(this.zombieRightLabel);
            this.Controls.Add(this.zombieLeftLabel);
            this.Controls.Add(this.zombieArrowBox);
            this.Controls.Add(this.ogreRightLabel);
            this.Controls.Add(this.ogreLeftLabel);
            this.Controls.Add(this.ogreArrowBox);
            this.Controls.Add(this.nagaRightLabel);
            this.Controls.Add(this.nagaLeftLabel);
            this.Controls.Add(this.nagaArrowBox);
            this.Controls.Add(this.myconidRightLabel);
            this.Controls.Add(this.myconidLeftLabel);
            this.Controls.Add(this.myconidArrowBox);
            this.Controls.Add(this.mummyRightLabel);
            this.Controls.Add(this.mummyLeftLabel);
            this.Controls.Add(this.mummyArrowBox);
            this.Controls.Add(this.mummyComboBox);
            this.Controls.Add(this.modroneRightLabel);
            this.Controls.Add(this.modroneLeftLabel);
            this.Controls.Add(this.modroneArrowBox);
            this.Controls.Add(this.mephitRightLabel);
            this.Controls.Add(this.mephitLeftLabel);
            this.Controls.Add(this.mephitArrowBox);
            this.Controls.Add(this.lycanRightLabel);
            this.Controls.Add(this.lycanLeftLabel);
            this.Controls.Add(this.lycanArrowBox);
            this.Controls.Add(this.lizardfolkRightLabel);
            this.Controls.Add(this.lizardfolkLeftLabel);
            this.Controls.Add(this.lizardfolkArrowBox);
            this.Controls.Add(this.kuoRightLabel);
            this.Controls.Add(this.kuoLeftLabel);
            this.Controls.Add(this.kuoArrowBox);
            this.Controls.Add(this.koboldRightLabel);
            this.Controls.Add(this.koboldLeftLabel);
            this.Controls.Add(this.koboldArrowBox);
            this.Controls.Add(this.hobgoblinRightLabel);
            this.Controls.Add(this.hobgoblinLeftLabel);
            this.Controls.Add(this.hobgoblinArrowBox);
            this.Controls.Add(this.hagRightLabel);
            this.Controls.Add(this.hagLeftLabel);
            this.Controls.Add(this.hagArrowBox);
            this.Controls.Add(this.grickRightLabel);
            this.Controls.Add(this.grickLeftLabel);
            this.Controls.Add(this.grickArrowBox);
            this.Controls.Add(this.grickComboBox);
            this.Controls.Add(this.golemRightLabel);
            this.Controls.Add(this.golemLeftLabel);
            this.Controls.Add(this.golemArrowBox);
            this.Controls.Add(this.goblinRightLabel);
            this.Controls.Add(this.goblinLeftLabel);
            this.Controls.Add(this.goblinArrowBox);
            this.Controls.Add(this.goblinComboBox);
            this.Controls.Add(this.gnollRightLabel);
            this.Controls.Add(this.gnollLeftLabel);
            this.Controls.Add(this.gnollArrowBox);
            this.Controls.Add(this.githRightLabel);
            this.Controls.Add(this.githLeftLabel);
            this.Controls.Add(this.githArrowBox);
            this.Controls.Add(this.giantsRightLabel);
            this.Controls.Add(this.giantsLeftLabel);
            this.Controls.Add(this.giantsArrowBox);
            this.Controls.Add(this.ghoulRightLabel);
            this.Controls.Add(this.ghoulLeftLabel);
            this.Controls.Add(this.ghoulArrowBox);
            this.Controls.Add(this.ghoulComboBox);
            this.Controls.Add(this.genieRightLabel);
            this.Controls.Add(this.genieLeftLabel);
            this.Controls.Add(this.genieArrowBox);
            this.Controls.Add(this.genieComboBox);
            this.Controls.Add(this.fungiRightLabel);
            this.Controls.Add(this.fungiLeftLabel);
            this.Controls.Add(this.fungiArrowBox);
            this.Controls.Add(this.drowRightLabel);
            this.Controls.Add(this.drowLeftLabel);
            this.Controls.Add(this.drowArrowBox);
            this.Controls.Add(this.elemRightLabel);
            this.Controls.Add(this.elemLeftLabel);
            this.Controls.Add(this.elemArrowBox);
            this.Controls.Add(this.dragRightLabel);
            this.Controls.Add(this.dragLeftLabel);
            this.Controls.Add(this.dragArrowBox);
            this.Controls.Add(this.dinoRightLabel);
            this.Controls.Add(this.dinoLeftLabel);
            this.Controls.Add(this.dinoArrowBox);
            this.Controls.Add(this.devilRightLabel);
            this.Controls.Add(this.devilLeftLabel);
            this.Controls.Add(this.devilArrowBox);
            this.Controls.Add(this.demonRightLabel);
            this.Controls.Add(this.demonLeftLabel);
            this.Controls.Add(this.demonArrowBox);
            this.Controls.Add(this.bugbearRightLabel);
            this.Controls.Add(this.bugbearLeftLabel);
            this.Controls.Add(this.bugbearArrowBox);
            this.Controls.Add(this.blightRightLabel);
            this.Controls.Add(this.blightLeftLabel);
            this.Controls.Add(this.blightArrowBox);
            this.Controls.Add(this.beholderRightLabel);
            this.Controls.Add(this.beholderLeftLabel);
            this.Controls.Add(this.beholderArrowPictureBox);
            this.Controls.Add(this.animatedObjectRightLabel);
            this.Controls.Add(this.animatedObjLeftLabel);
            this.Controls.Add(this.animatedObjArrowPictureBox);
            this.Controls.Add(this.angelRightLabel);
            this.Controls.Add(this.angelLeftLabel);
            this.Controls.Add(this.angelArrowPictureBox);
            this.Controls.Add(this.zombieComboBox);
            this.Controls.Add(this.yugolothComboBox);
            this.Controls.Add(this.yuanTiComboBox);
            this.Controls.Add(this.yetiComboBox);
            this.Controls.Add(this.vampireComboBox);
            this.Controls.Add(this.sphinxesComboBox);
            this.Controls.Add(this.slaadiComboBox);
            this.Controls.Add(this.skeletonComboBox);
            this.Controls.Add(this.salamanderComboBox);
            this.Controls.Add(this.sahuaginComboBox);
            this.Controls.Add(this.remorhazComboBox);
            this.Controls.Add(this.orcComboBox);
            this.Controls.Add(this.oozeComboBox);
            this.Controls.Add(this.ogreComboBox);
            this.Controls.Add(this.nagaComboBox);
            this.Controls.Add(this.myconoidComboBox);
            this.Controls.Add(this.mondroneComboBox);
            this.Controls.Add(this.mephitesComboBox);
            this.Controls.Add(this.lycanthropeComboBox);
            this.Controls.Add(this.lizardFolkComboBox);
            this.Controls.Add(this.kuoComboBox);
            this.Controls.Add(this.koboldComboBox);
            this.Controls.Add(this.hobgoblinComboBox);
            this.Controls.Add(this.hagComboBox);
            this.Controls.Add(this.golemComboBox);
            this.Controls.Add(this.gnollComboBox);
            this.Controls.Add(this.githComboBox);
            this.Controls.Add(this.giantsComboBox);
            this.Controls.Add(this.fungiComboBox);
            this.Controls.Add(this.drowComboBox);
            this.Controls.Add(this.elementsComboBox);
            this.Controls.Add(this.dragon1ComboBox);
            this.Controls.Add(this.dinoComboBox);
            this.Controls.Add(this.devilComboBox);
            this.Controls.Add(this.demonComboBox);
            this.Controls.Add(this.bugBearComboBox);
            this.Controls.Add(this.blightComboBox);
            this.Controls.Add(this.beHoldercomboBox);
            this.Controls.Add(this.animatedObjectcomboBox);
            this.Controls.Add(this.angelSubcomboBox);
            this.Controls.Add(this.npcLabel);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.miscCreatureLabel);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.npcComboBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.miscCreateComboBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pageNumLabel);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.expLabel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.saveThrowLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.damageLabel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.attackBLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.hpLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.profLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.acLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lvlLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(384, 33);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DnD5e Monster Manual DM Assistant";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.angelArrowPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.animatedObjArrowPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.beholderArrowPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blightArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bugbearArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.demonArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.devilArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dinoArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dragArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.elemArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.drowArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fungiArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.genieArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ghoulArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.giantsArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.githArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gnollArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.goblinArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.golemArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grickArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hagArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hobgoblinArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.koboldArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kuoArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lizardfolkArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lycanArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mephitArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.modroneArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mummyArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myconidArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nagaArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ogreArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zombieArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yugoArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yuanArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.yetiArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vampireArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sphinxArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sladdiArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sahuginArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oozeArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.skeletonArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.salamanderArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.remorhazeArrowBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orcArrowBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lvlLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label acLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label profLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label hpLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label attackBLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label damageLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label saveThrowLabel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label expLabel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label pageNumLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox miscCreateComboBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox npcComboBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label miscCreatureLabel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label npcLabel;
        private System.Windows.Forms.ComboBox angelSubcomboBox;
        private System.Windows.Forms.ComboBox animatedObjectcomboBox;
        private System.Windows.Forms.ComboBox beHoldercomboBox;
        private System.Windows.Forms.ComboBox blightComboBox;
        private System.Windows.Forms.ComboBox bugBearComboBox;
        private System.Windows.Forms.ComboBox demonComboBox;
        private System.Windows.Forms.ComboBox devilComboBox;
        private System.Windows.Forms.ComboBox dinoComboBox;
        private System.Windows.Forms.ComboBox dragon1ComboBox;
        private System.Windows.Forms.ComboBox elementsComboBox;
        private System.Windows.Forms.ComboBox drowComboBox;
        private System.Windows.Forms.ComboBox fungiComboBox;
        private System.Windows.Forms.ComboBox giantsComboBox;
        private System.Windows.Forms.ComboBox githComboBox;
        private System.Windows.Forms.ComboBox gnollComboBox;
        private System.Windows.Forms.ComboBox golemComboBox;
        private System.Windows.Forms.ComboBox hagComboBox;
        private System.Windows.Forms.ComboBox hobgoblinComboBox;
        private System.Windows.Forms.ComboBox koboldComboBox;
        private System.Windows.Forms.ComboBox kuoComboBox;
        private System.Windows.Forms.ComboBox lizardFolkComboBox;
        private System.Windows.Forms.ComboBox lycanthropeComboBox;
        private System.Windows.Forms.ComboBox mephitesComboBox;
        private System.Windows.Forms.ComboBox mondroneComboBox;
        private System.Windows.Forms.ComboBox myconoidComboBox;
        private System.Windows.Forms.ComboBox nagaComboBox;
        private System.Windows.Forms.ComboBox ogreComboBox;
        private System.Windows.Forms.ComboBox oozeComboBox;
        private System.Windows.Forms.ComboBox orcComboBox;
        private System.Windows.Forms.ComboBox remorhazComboBox;
        private System.Windows.Forms.ComboBox sahuaginComboBox;
        private System.Windows.Forms.ComboBox salamanderComboBox;
        private System.Windows.Forms.ComboBox skeletonComboBox;
        private System.Windows.Forms.ComboBox slaadiComboBox;
        private System.Windows.Forms.ComboBox sphinxesComboBox;
        private System.Windows.Forms.ComboBox vampireComboBox;
        private System.Windows.Forms.ComboBox yetiComboBox;
        private System.Windows.Forms.ComboBox yuanTiComboBox;
        private System.Windows.Forms.ComboBox yugolothComboBox;
        private System.Windows.Forms.ComboBox zombieComboBox;
        private System.Windows.Forms.PictureBox angelArrowPictureBox;
        private System.Windows.Forms.Label angelLeftLabel;
        private System.Windows.Forms.Label angelRightLabel;
        private System.Windows.Forms.PictureBox animatedObjArrowPictureBox;
        private System.Windows.Forms.Label animatedObjLeftLabel;
        private System.Windows.Forms.Label animatedObjectRightLabel;
        private System.Windows.Forms.PictureBox beholderArrowPictureBox;
        private System.Windows.Forms.Label beholderLeftLabel;
        private System.Windows.Forms.Label beholderRightLabel;
        private System.Windows.Forms.PictureBox blightArrowBox;
        private System.Windows.Forms.Label blightLeftLabel;
        private System.Windows.Forms.Label blightRightLabel;
        private System.Windows.Forms.PictureBox bugbearArrowBox;
        private System.Windows.Forms.Label bugbearLeftLabel;
        private System.Windows.Forms.Label bugbearRightLabel;
        private System.Windows.Forms.PictureBox demonArrowBox;
        private System.Windows.Forms.Label demonLeftLabel;
        private System.Windows.Forms.Label demonRightLabel;
        private System.Windows.Forms.PictureBox devilArrowBox;
        private System.Windows.Forms.Label devilLeftLabel;
        private System.Windows.Forms.Label devilRightLabel;
        private System.Windows.Forms.PictureBox dinoArrowBox;
        private System.Windows.Forms.Label dinoLeftLabel;
        private System.Windows.Forms.Label dinoRightLabel;
        private System.Windows.Forms.PictureBox dragArrowBox;
        private System.Windows.Forms.Label dragLeftLabel;
        private System.Windows.Forms.Label dragRightLabel;
        private System.Windows.Forms.PictureBox elemArrowBox;
        private System.Windows.Forms.Label elemLeftLabel;
        private System.Windows.Forms.Label elemRightLabel;
        private System.Windows.Forms.PictureBox drowArrowBox;
        private System.Windows.Forms.Label drowLeftLabel;
        private System.Windows.Forms.Label drowRightLabel;
        private System.Windows.Forms.PictureBox fungiArrowBox;
        private System.Windows.Forms.Label fungiLeftLabel;
        private System.Windows.Forms.Label fungiRightLabel;
        private System.Windows.Forms.ComboBox genieComboBox;
        private System.Windows.Forms.PictureBox genieArrowBox;
        private System.Windows.Forms.Label genieLeftLabel;
        private System.Windows.Forms.Label genieRightLabel;
        private System.Windows.Forms.ComboBox ghoulComboBox;
        private System.Windows.Forms.PictureBox ghoulArrowBox;
        private System.Windows.Forms.Label ghoulLeftLabel;
        private System.Windows.Forms.Label ghoulRightLabel;
        private System.Windows.Forms.PictureBox giantsArrowBox;
        private System.Windows.Forms.Label giantsLeftLabel;
        private System.Windows.Forms.Label giantsRightLabel;
        private System.Windows.Forms.PictureBox githArrowBox;
        private System.Windows.Forms.Label githLeftLabel;
        private System.Windows.Forms.Label githRightLabel;
        private System.Windows.Forms.PictureBox gnollArrowBox;
        private System.Windows.Forms.Label gnollLeftLabel;
        private System.Windows.Forms.Label gnollRightLabel;
        private System.Windows.Forms.ComboBox goblinComboBox;
        private System.Windows.Forms.PictureBox goblinArrowBox;
        private System.Windows.Forms.Label goblinLeftLabel;
        private System.Windows.Forms.Label goblinRightLabel;
        private System.Windows.Forms.PictureBox golemArrowBox;
        private System.Windows.Forms.Label golemLeftLabel;
        private System.Windows.Forms.Label golemRightLabel;
        private System.Windows.Forms.ComboBox grickComboBox;
        private System.Windows.Forms.PictureBox grickArrowBox;
        private System.Windows.Forms.Label grickLeftLabel;
        private System.Windows.Forms.Label grickRightLabel;
        private System.Windows.Forms.PictureBox hagArrowBox;
        private System.Windows.Forms.Label hagLeftLabel;
        private System.Windows.Forms.Label hagRightLabel;
        private System.Windows.Forms.PictureBox hobgoblinArrowBox;
        private System.Windows.Forms.Label hobgoblinLeftLabel;
        private System.Windows.Forms.Label hobgoblinRightLabel;
        private System.Windows.Forms.PictureBox koboldArrowBox;
        private System.Windows.Forms.Label koboldLeftLabel;
        private System.Windows.Forms.Label koboldRightLabel;
        private System.Windows.Forms.PictureBox kuoArrowBox;
        private System.Windows.Forms.Label kuoLeftLabel;
        private System.Windows.Forms.Label kuoRightLabel;
        private System.Windows.Forms.PictureBox lizardfolkArrowBox;
        private System.Windows.Forms.Label lizardfolkLeftLabel;
        private System.Windows.Forms.Label lizardfolkRightLabel;
        private System.Windows.Forms.PictureBox lycanArrowBox;
        private System.Windows.Forms.Label lycanLeftLabel;
        private System.Windows.Forms.Label lycanRightLabel;
        private System.Windows.Forms.PictureBox mephitArrowBox;
        private System.Windows.Forms.Label mephitLeftLabel;
        private System.Windows.Forms.Label mephitRightLabel;
        private System.Windows.Forms.PictureBox modroneArrowBox;
        private System.Windows.Forms.Label modroneLeftLabel;
        private System.Windows.Forms.Label modroneRightLabel;
        private System.Windows.Forms.ComboBox mummyComboBox;
        private System.Windows.Forms.PictureBox mummyArrowBox;
        private System.Windows.Forms.Label mummyLeftLabel;
        private System.Windows.Forms.Label mummyRightLabel;
        private System.Windows.Forms.PictureBox myconidArrowBox;
        private System.Windows.Forms.Label myconidLeftLabel;
        private System.Windows.Forms.Label myconidRightLabel;
        private System.Windows.Forms.Label nagaLeftLabel;
        private System.Windows.Forms.Label nagaRightLabel;
        private System.Windows.Forms.PictureBox ogreArrowBox;
        private System.Windows.Forms.Label ogreLeftLabel;
        private System.Windows.Forms.Label ogreRightLabel;
        private System.Windows.Forms.PictureBox nagaArrowBox;
        private System.Windows.Forms.PictureBox zombieArrowBox;
        private System.Windows.Forms.Label zombieLeftLabel;
        private System.Windows.Forms.Label zombieRightLabel;
        private System.Windows.Forms.PictureBox yugoArrowBox;
        private System.Windows.Forms.Label yugoLeftLabel;
        private System.Windows.Forms.Label yugoRightLabel;
        private System.Windows.Forms.PictureBox yuanArrowBox;
        private System.Windows.Forms.Label yuanLeftLabel;
        private System.Windows.Forms.Label yuanRightLabel;
        private System.Windows.Forms.PictureBox yetiArrowBox;
        private System.Windows.Forms.Label yetiLeftLabel;
        private System.Windows.Forms.Label yetiRightLabel;
        private System.Windows.Forms.PictureBox vampireArrowBox;
        private System.Windows.Forms.Label vampireLeftLabel;
        private System.Windows.Forms.Label vampireRightLabel;
        private System.Windows.Forms.PictureBox sphinxArrowBox;
        private System.Windows.Forms.Label sphinxLeftLabel;
        private System.Windows.Forms.Label sphinxRightLabel;
        private System.Windows.Forms.PictureBox sladdiArrowBox;
        private System.Windows.Forms.PictureBox sahuginArrowBox;
        private System.Windows.Forms.PictureBox oozeArrowBox;
        private System.Windows.Forms.PictureBox skeletonArrowBox;
        private System.Windows.Forms.PictureBox salamanderArrowBox;
        private System.Windows.Forms.PictureBox remorhazeArrowBox;
        private System.Windows.Forms.PictureBox orcArrowBox;
        private System.Windows.Forms.Label oozeLeftLabel;
        private System.Windows.Forms.Label orcLeftLabel;
        private System.Windows.Forms.Label slaadiLeftLabel;
        private System.Windows.Forms.Label salamanderLeftLabel;
        private System.Windows.Forms.Label sahuginLeftLabel;
        private System.Windows.Forms.Label yugolothLeftLabel;
        private System.Windows.Forms.Label skeletonLeftLabel;
        private System.Windows.Forms.Label remorhazLeftLabel;
        private System.Windows.Forms.Label oozeRightLabel;
        private System.Windows.Forms.Label yugolothRightLabel;
        private System.Windows.Forms.Label skeletonRightLabel;
        private System.Windows.Forms.Label orcRightLabel;
        private System.Windows.Forms.Label slaadiRightLabel;
        private System.Windows.Forms.Label salamanderRightLabel;
        private System.Windows.Forms.Label remorhazRightLabel;
        private System.Windows.Forms.Label sahuginRightLabel;
        private System.Windows.Forms.Label yuantiRightLabel;
    }
}

