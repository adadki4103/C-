﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //---Monsters---
            // A (6)
            comboBox1.Items.Add("Aarakocra");
            comboBox1.Items.Add("Aboleth");
            comboBox1.Items.Add("Angels");
            comboBox1.Items.Add("Animated Objects");
            comboBox1.Items.Add("Ankheg");
            comboBox1.Items.Add("Azer");
            // B (8)
            comboBox1.Items.Add("Banshee");
            comboBox1.Items.Add("Basilisk");
            comboBox1.Items.Add("Behir");
            comboBox1.Items.Add("Beholders");
            comboBox1.Items.Add("Blights");
            comboBox1.Items.Add("Bugbears");
            comboBox1.Items.Add("Bulette");
            comboBox1.Items.Add("Bullywug");
            // C (10)
            comboBox1.Items.Add("Cambion");
            comboBox1.Items.Add("Carrion Crawler");
            comboBox1.Items.Add("Centaur");
            comboBox1.Items.Add("Chimera");
            comboBox1.Items.Add("Chuul");
            comboBox1.Items.Add("Cloaker");
            comboBox1.Items.Add("Cockatrice");
            comboBox1.Items.Add("Couatl");
            comboBox1.Items.Add("Crawling Claw");
            comboBox1.Items.Add("Cyclops");
            // D (15)
            comboBox1.Items.Add("Darkmantle");
            comboBox1.Items.Add("Death Knight");
            comboBox1.Items.Add("Demlich");
            comboBox1.Items.Add("Demons");
            comboBox1.Items.Add("Devils");
            comboBox1.Items.Add("Dinosaurs");
            comboBox1.Items.Add("Displacer Beast");
            comboBox1.Items.Add("Doppelganger");
            comboBox1.Items.Add("Dracolich");
            comboBox1.Items.Add("Dragon, Shadow");
            comboBox1.Items.Add("Dragons");
            comboBox1.Items.Add("Dragon Turtle");
            comboBox1.Items.Add("Drider");
            comboBox1.Items.Add("Dryad");
            comboBox1.Items.Add("Duergar");
            // E (5)
            comboBox1.Items.Add("Elementals");
            comboBox1.Items.Add("Elves: Drow");
            comboBox1.Items.Add("Empyrean");
            comboBox1.Items.Add("Ettercap");
            comboBox1.Items.Add("Ettin");
            // F (5)
            comboBox1.Items.Add("Faerie Dragon");
            comboBox1.Items.Add("Flameskull");
            comboBox1.Items.Add("Flumph");
            comboBox1.Items.Add("Fomorian");
            comboBox1.Items.Add("Fungi");
            // G (17)
            comboBox1.Items.Add("Galeb Duhr");
            comboBox1.Items.Add("Gargoyle");
            comboBox1.Items.Add("Genies");
            comboBox1.Items.Add("Ghost");
            comboBox1.Items.Add("Ghouls");
            comboBox1.Items.Add("Giants");
            comboBox1.Items.Add("Gibbering Mouther");
            comboBox1.Items.Add("Gith");
            comboBox1.Items.Add("Gnolls");
            comboBox1.Items.Add("Gnome, Deep");
            comboBox1.Items.Add("Goblins");
            comboBox1.Items.Add("Golems");
            comboBox1.Items.Add("Gorgon");
            comboBox1.Items.Add("Grell");
            comboBox1.Items.Add("Grick");
            comboBox1.Items.Add("Griffon");
            comboBox1.Items.Add("Grimlock");
            // H (10)
            comboBox1.Items.Add("Hags");
            comboBox1.Items.Add("Half-Dragon");
            comboBox1.Items.Add("Harpy");
            comboBox1.Items.Add("Hell Hound");
            comboBox1.Items.Add("Helmed Horror");
            comboBox1.Items.Add("Hippogriff");
            comboBox1.Items.Add("Hobgoblins");
            comboBox1.Items.Add("Hounculus");
            comboBox1.Items.Add("Hook Horror");
            comboBox1.Items.Add("Hydra");
            // I (2)
            comboBox1.Items.Add("Intellect Devourer");
            comboBox1.Items.Add("Invisible Stalker");
            // J (1)
            comboBox1.Items.Add("Jackalwere");
            // K (4)
            comboBox1.Items.Add("Kenku");
            comboBox1.Items.Add("Kobolds");
            comboBox1.Items.Add("Kraken");
            comboBox1.Items.Add("Kuo-toa");
            // L (4)
            comboBox1.Items.Add("Lamia");
            comboBox1.Items.Add("Lich");
            comboBox1.Items.Add("Lizardfolk");
            comboBox1.Items.Add("Lycanthropes");
            // M (12)
            comboBox1.Items.Add("Magmin");
            comboBox1.Items.Add("Manticore");
            comboBox1.Items.Add("Medusa");
            comboBox1.Items.Add("Mephits");
            comboBox1.Items.Add("Merfolk");
            comboBox1.Items.Add("Merrow");
            comboBox1.Items.Add("Mimic");
            comboBox1.Items.Add("Mind Flayer");
            comboBox1.Items.Add("Minotaur");
            comboBox1.Items.Add("Modrons");
            comboBox1.Items.Add("Mummies");
            comboBox1.Items.Add("Myconids");
            // N (3)
            comboBox1.Items.Add("Nagas");
            comboBox1.Items.Add("Nightmare");
            comboBox1.Items.Add("Nothic");
            // O (6)
            comboBox1.Items.Add("Ogres");
            comboBox1.Items.Add("Oni");
            comboBox1.Items.Add("Oozes");
            comboBox1.Items.Add("Orcs");
            comboBox1.Items.Add("Otyugh");
            comboBox1.Items.Add("Owlbear");
            // P (6)
            comboBox1.Items.Add("Pegasus");
            comboBox1.Items.Add("Peryton");
            comboBox1.Items.Add("Piercer");
            comboBox1.Items.Add("Pixie");
            comboBox1.Items.Add("Pseudodragon");
            comboBox1.Items.Add("Purple Worm");
            // Q (1)
            comboBox1.Items.Add("Quaggoth");
            // R (6)
            comboBox1.Items.Add("Rakshsa");
            comboBox1.Items.Add("Remorhazes");
            comboBox1.Items.Add("Revenant");
            comboBox1.Items.Add("Roc");
            comboBox1.Items.Add("Roper");
            comboBox1.Items.Add("Rust Monster");
            // S (14)
            comboBox1.Items.Add("Sahuagin");
            comboBox1.Items.Add("Salamanders");
            comboBox1.Items.Add("Satyr");
            comboBox1.Items.Add("Scarecrow");
            comboBox1.Items.Add("Shadow");
            comboBox1.Items.Add("Shambling Mound");
            comboBox1.Items.Add("Shield Guardian");
            comboBox1.Items.Add("Skeletons");
            comboBox1.Items.Add("Slaadi");
            comboBox1.Items.Add("Specter");
            comboBox1.Items.Add("Sphinxes");
            comboBox1.Items.Add("Sprite");
            comboBox1.Items.Add("Stirge");
            comboBox1.Items.Add("Succubus/Incubus");
            // T (5)
            comboBox1.Items.Add("Tarrasque");
            comboBox1.Items.Add("Thri-kreen");
            comboBox1.Items.Add("Treant");
            comboBox1.Items.Add("Troglodyte");
            comboBox1.Items.Add("Troll");
            // U (2)
            comboBox1.Items.Add("Umber Hulk");
            comboBox1.Items.Add("Unicorn");
            // V (1)
            comboBox1.Items.Add("Vampires");
            // W (5)
            comboBox1.Items.Add("Water Weird");
            comboBox1.Items.Add("Wight");
            comboBox1.Items.Add("Will-o'wisp");
            comboBox1.Items.Add("Wraith");
            comboBox1.Items.Add("Wyvern");
            // X (1)
            comboBox1.Items.Add("Xorn");
            // Y (3)
            comboBox1.Items.Add("Yetis");
            comboBox1.Items.Add("Yuan-ti");
            comboBox1.Items.Add("Yugoloths");
            // Z (1)
            comboBox1.Items.Add("Zombies");
            //--Challenge Rating-------
            comboBox3.Items.Add("0");
            comboBox3.Items.Add("1/8");
            comboBox3.Items.Add("1/4");
            comboBox3.Items.Add("1/2");
            comboBox3.Items.Add("1");
            comboBox3.Items.Add("2");
            comboBox3.Items.Add("3");
            comboBox3.Items.Add("4");
            comboBox3.Items.Add("5");
            comboBox3.Items.Add("6");
            comboBox3.Items.Add("7");
            comboBox3.Items.Add("8");
            comboBox3.Items.Add("9");
            comboBox3.Items.Add("10");
            comboBox3.Items.Add("11");
            comboBox3.Items.Add("12");
            comboBox3.Items.Add("13");
            comboBox3.Items.Add("14");
            comboBox3.Items.Add("15");
            comboBox3.Items.Add("16");
            comboBox3.Items.Add("17");
            comboBox3.Items.Add("18");
            comboBox3.Items.Add("19");
            comboBox3.Items.Add("20");
            comboBox3.Items.Add("21");
            comboBox3.Items.Add("22");
            comboBox3.Items.Add("23");
            comboBox3.Items.Add("24");
            comboBox3.Items.Add("25");
            comboBox3.Items.Add("26");
            comboBox3.Items.Add("27");
            comboBox3.Items.Add("28");
            comboBox3.Items.Add("29");
            comboBox3.Items.Add("30");
  // Misc. Creatures ----------------------------------
            miscCreateComboBox.Items.Add("Ape");
            miscCreateComboBox.Items.Add("Awakened Shrub");
            miscCreateComboBox.Items.Add("Awakened Tree");
            miscCreateComboBox.Items.Add("Axe Beak");
            miscCreateComboBox.Items.Add("Baboon");
            miscCreateComboBox.Items.Add("Badger");
            miscCreateComboBox.Items.Add("Bat");
            miscCreateComboBox.Items.Add("Black Bear");
            miscCreateComboBox.Items.Add("Blink Dog");
            miscCreateComboBox.Items.Add("Blood Hawk");
            miscCreateComboBox.Items.Add("Boar");
            miscCreateComboBox.Items.Add("Brown Bear");
            miscCreateComboBox.Items.Add("Camel");
            miscCreateComboBox.Items.Add("Cat");
            miscCreateComboBox.Items.Add("Constrictor Snake");
            miscCreateComboBox.Items.Add("Crab");
            miscCreateComboBox.Items.Add("Crocodile");
            miscCreateComboBox.Items.Add("Death Dog");
            miscCreateComboBox.Items.Add("Deer");
            miscCreateComboBox.Items.Add("Dire Wolf");
            miscCreateComboBox.Items.Add("Draft Horse");
            miscCreateComboBox.Items.Add("Elephant");
            miscCreateComboBox.Items.Add("Elk");
            miscCreateComboBox.Items.Add("Flying Snake");
            miscCreateComboBox.Items.Add("Frog");
            miscCreateComboBox.Items.Add("Giant Ape");
            miscCreateComboBox.Items.Add("Giant Badger");
            miscCreateComboBox.Items.Add("Giant Bat");
            miscCreateComboBox.Items.Add("Giant Boar");
            miscCreateComboBox.Items.Add("Giant Centipede");
            miscCreateComboBox.Items.Add("Giant Constrictor Snake");
            miscCreateComboBox.Items.Add("Giant Crab");
            miscCreateComboBox.Items.Add("Giant Crocodile");
            miscCreateComboBox.Items.Add("Giant Eagle");
            miscCreateComboBox.Items.Add("Giant Elk");
            miscCreateComboBox.Items.Add("Giant Fire Beetle");
            miscCreateComboBox.Items.Add("Giant Frog");
            miscCreateComboBox.Items.Add("Giant Goat");
            miscCreateComboBox.Items.Add("Giant Hyena");
            miscCreateComboBox.Items.Add("Giant Lizard");
            miscCreateComboBox.Items.Add("Giant Octopus");
            miscCreateComboBox.Items.Add("Giant Owl");
            miscCreateComboBox.Items.Add("Giant Poisonous Snake");
            miscCreateComboBox.Items.Add("Giant Rat");
            miscCreateComboBox.Items.Add("Giant Scorpion");
            miscCreateComboBox.Items.Add("Giant Sea Horse");
            miscCreateComboBox.Items.Add("Giant Shark");
            miscCreateComboBox.Items.Add("Giant Spider");
            miscCreateComboBox.Items.Add("Giant Toad");
            miscCreateComboBox.Items.Add("Giant Vulture");
            miscCreateComboBox.Items.Add("Giant Wasp");
            miscCreateComboBox.Items.Add("Giant Weasel");
            miscCreateComboBox.Items.Add("Giant Wolf Spider");
            miscCreateComboBox.Items.Add("Goat");
            miscCreateComboBox.Items.Add("Hawk");
            miscCreateComboBox.Items.Add("Hunter Shark");
            miscCreateComboBox.Items.Add("Hyena");
            miscCreateComboBox.Items.Add("Jackal");
            miscCreateComboBox.Items.Add("Killer Whale");
            miscCreateComboBox.Items.Add("Lion");
            miscCreateComboBox.Items.Add("Lizard");
            miscCreateComboBox.Items.Add("Mammoth");
            miscCreateComboBox.Items.Add("Mastiff");
            miscCreateComboBox.Items.Add("Mule");
            miscCreateComboBox.Items.Add("Octopus");
            miscCreateComboBox.Items.Add("Owl");
            miscCreateComboBox.Items.Add("Panther");
            miscCreateComboBox.Items.Add("Phase Spider");
            miscCreateComboBox.Items.Add("Poisonous Snake");
            miscCreateComboBox.Items.Add("Polar Bear");
            miscCreateComboBox.Items.Add("Pony");
            miscCreateComboBox.Items.Add("Quipper");
            miscCreateComboBox.Items.Add("Rat");
            miscCreateComboBox.Items.Add("Raven");
            miscCreateComboBox.Items.Add("Reef Shark");
            miscCreateComboBox.Items.Add("Rhinoceros");
            miscCreateComboBox.Items.Add("Riding Horse");
            miscCreateComboBox.Items.Add("Saber-Toothed Tiger");
            miscCreateComboBox.Items.Add("Scorpion");
            miscCreateComboBox.Items.Add("Sea Horse");
            miscCreateComboBox.Items.Add("Spider");
            miscCreateComboBox.Items.Add("Swarm of Bats");
            miscCreateComboBox.Items.Add("Swarm of Insects");
            miscCreateComboBox.Items.Add("Swarm of Posonous Snakes");
            miscCreateComboBox.Items.Add("Swarm of Quippers");
            miscCreateComboBox.Items.Add("Swarm of Rats");
            miscCreateComboBox.Items.Add("Swarm of Ravens");
            miscCreateComboBox.Items.Add("Tiger");
            miscCreateComboBox.Items.Add("Vulture");
            miscCreateComboBox.Items.Add("Warhorse");
            miscCreateComboBox.Items.Add("Weasel");
            miscCreateComboBox.Items.Add("Winter Wolf");
            miscCreateComboBox.Items.Add("Wolf");
            miscCreateComboBox.Items.Add("Worg");
    // Npc Characters ----------------------------------
            npcComboBox.Items.Add("Acolyte");
            npcComboBox.Items.Add("Archmage");
            npcComboBox.Items.Add("Assassin");
            npcComboBox.Items.Add("Bandit");
            npcComboBox.Items.Add("Bandit Captain");
            npcComboBox.Items.Add("Berserker");
            npcComboBox.Items.Add("Commoner");
            npcComboBox.Items.Add("Cultist");
            npcComboBox.Items.Add("Cult Fanatic");
            npcComboBox.Items.Add("Druid");
            npcComboBox.Items.Add("Gladiator");
            npcComboBox.Items.Add("Guard");
            npcComboBox.Items.Add("Knight");
            npcComboBox.Items.Add("Mage");
            npcComboBox.Items.Add("Noble");
            npcComboBox.Items.Add("Priest");
            npcComboBox.Items.Add("Scout");
            npcComboBox.Items.Add("Spy");
            npcComboBox.Items.Add("Thug");
            npcComboBox.Items.Add("Tribal Warrior");
            npcComboBox.Items.Add("Veteran");
        // Angel Sub Menu ----------------------------------
            angelSubcomboBox.Items.Add("Deva");
            angelSubcomboBox.Items.Add("Planetar");
            angelSubcomboBox.Items.Add("Solar");
       // Animated Objects Sub Menu ------------------------
            animatedObjectcomboBox.Items.Add("Animated Armor");
            animatedObjectcomboBox.Items.Add("Flying Sword");
            animatedObjectcomboBox.Items.Add("Rug of Smothering");
      // Beholder Sub Menu ---------------------------------------
            beHoldercomboBox.Items.Add("Beholder");
            beHoldercomboBox.Items.Add("Death Tyrant");
            beHoldercomboBox.Items.Add("Spectator");
     // Blight Sub Menu ---------------------------------------
            blightComboBox.Items.Add("Needle Blight");
            blightComboBox.Items.Add("Twig Blight");
            blightComboBox.Items.Add("Vine Blight");
      // BugBear Sub Menu
            bugBearComboBox.Items.Add("Bugbear");
            bugBearComboBox.Items.Add("Bugbear Chief");
     // Demon Sub Menu
            demonComboBox.Items.Add("Balor");
            demonComboBox.Items.Add("Barlgura");
            demonComboBox.Items.Add("Chasme");
            demonComboBox.Items.Add("Dretch");
            demonComboBox.Items.Add("Glabrezu");
            demonComboBox.Items.Add("Goristro");
            demonComboBox.Items.Add("Hezrou");
            demonComboBox.Items.Add("Manes");
            demonComboBox.Items.Add("Marilith");
            demonComboBox.Items.Add("Nalfeshnee");
            demonComboBox.Items.Add("Quasit");
            demonComboBox.Items.Add("Shadow Demon");
            demonComboBox.Items.Add("Vrock");
            demonComboBox.Items.Add("Yochlol");
    // Devil Sub Menu -------------------------
            devilComboBox.Items.Add("Barbed Devil");
            devilComboBox.Items.Add("Bearded Devil");
            devilComboBox.Items.Add("Bone Devil");
            devilComboBox.Items.Add("Chain Devil");
            devilComboBox.Items.Add("Erinyes");
            devilComboBox.Items.Add("Horned Devil");
            devilComboBox.Items.Add("Ice Devil");
            devilComboBox.Items.Add("Imp");
            devilComboBox.Items.Add("Lemure");
            devilComboBox.Items.Add("Pit Fiend");
            devilComboBox.Items.Add("Spined Devil");
      // Dinosaurs Sub Menu ---------------------------
            dinoComboBox.Items.Add("Allosaurus");
            dinoComboBox.Items.Add("Ankylosaurus");
            dinoComboBox.Items.Add("Plesiosaurus");
            dinoComboBox.Items.Add("Pteranodon");
            dinoComboBox.Items.Add("Triceratops");
            dinoComboBox.Items.Add("Tyrannosaurus Rex");



        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        { //---Monster List---
          //-- A --
          // Aarakocra
            if (comboBox1.SelectedIndex == 0)
            {
                pageNumLabel.Text = "12)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Aboleth
            if(comboBox1.SelectedIndex == 1)
            {
                pageNumLabel.Text = "13)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Angels
            if(comboBox1.SelectedIndex == 2)
            {
                pageNumLabel.Text = "15)";
                typeLabel.Text = "Celestial";
                angelSubcomboBox.Visible = true;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Animated Objects
            if(comboBox1.SelectedIndex == 3)
            {
                pageNumLabel.Text = "19)";
                typeLabel.Text = "Construct";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = true;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Ankheg
            if(comboBox1.SelectedIndex == 4)
            {
                pageNumLabel.Text = "21)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Azer
            if(comboBox1.SelectedIndex == 5)
            {
                pageNumLabel.Text = "22)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- B --
            // Banshee
            if(comboBox1.SelectedIndex == 6)
            {
                pageNumLabel.Text = "23)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Basilisk
            if(comboBox1.SelectedIndex == 7)
            {
                pageNumLabel.Text = "24)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Behir
            if(comboBox1.SelectedIndex == 8)
            {
                pageNumLabel.Text = "25)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Beholders
            if(comboBox1.SelectedIndex == 9)
            {
                pageNumLabel.Text = "26)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = true;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Blights
            if(comboBox1.SelectedIndex == 10)
            {
                pageNumLabel.Text = "31)";
                typeLabel.Text = "Plant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = true;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Bugbears
            if(comboBox1.SelectedIndex == 11)
            {
                pageNumLabel.Text = "33)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = true;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Bulette
            if(comboBox1.SelectedIndex == 12)
            {
                pageNumLabel.Text = "34)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Bullywug
            if(comboBox1.SelectedIndex == 13)
            {
                pageNumLabel.Text = "35)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- C --
            // Cambion
            if(comboBox1.SelectedIndex == 14)
            {
                pageNumLabel.Text = "36)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Carrion Crawler
            if(comboBox1.SelectedIndex == 15)
            {
                pageNumLabel.Text = "37)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Centaur
            if(comboBox1.SelectedIndex == 16)
            {
                pageNumLabel.Text = "38)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Chimera
            if(comboBox1.SelectedIndex == 17)
            {
                pageNumLabel.Text = "39)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Chuul
            if(comboBox1.SelectedIndex == 18)
            {
                pageNumLabel.Text = "40)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Cloaker
            if(comboBox1.SelectedIndex == 19)
            {
                pageNumLabel.Text = "41)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Cockatrice
            if(comboBox1.SelectedIndex == 20)
            {
                pageNumLabel.Text = "42)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Couatl
            if(comboBox1.SelectedIndex == 21)
            {
                pageNumLabel.Text = "43)";
                typeLabel.Text = "Celestial";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Crawling Claw
            if(comboBox1.SelectedIndex == 22)
            {
                pageNumLabel.Text = "44)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Cyclops
            if(comboBox1.SelectedIndex == 23)
            {
                pageNumLabel.Text = "45)";
                typeLabel.Text = "Giant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- D --
            // Darkmantle
            if(comboBox1.SelectedIndex == 24)
            {
                pageNumLabel.Text = "46)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Death Knight
            if(comboBox1.SelectedIndex == 25)
            {
                pageNumLabel.Text = "47)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Demilich
            if(comboBox1.SelectedIndex == 26)
            {
                pageNumLabel.Text = "48)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;

            }
            // Demons
            if(comboBox1.SelectedIndex == 27)
            {
                pageNumLabel.Text = "50)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = true;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Devils
            if(comboBox1.SelectedIndex == 28)
            {
                pageNumLabel.Text = "66)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = true;
                dinoComboBox.Visible = false;
            }
            // Dinosaurs
            if(comboBox1.SelectedIndex == 29)
            {
                pageNumLabel.Text = "79)";
                typeLabel.Text = "Beast";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = true;
            }
            // Displacer Beast
            if(comboBox1.SelectedIndex == 30)
            {
                pageNumLabel.Text = "81)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Doppelganger
            if(comboBox1.SelectedIndex == 31)
            {
                pageNumLabel.Text = "82)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Dracolich
            if(comboBox1.SelectedIndex == 32)
            {
                pageNumLabel.Text = "83)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Dragon, Shadow
            if(comboBox1.SelectedIndex == 33)
            {
                pageNumLabel.Text = "84)";
                typeLabel.Text = "Dragon";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Dragons
            if(comboBox1.SelectedIndex == 34)
            {
                pageNumLabel.Text = "86)";
                typeLabel.Text = "Dragon";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Dragon Turtle
            if(comboBox1.SelectedIndex == 35)
            {
                pageNumLabel.Text = "119)";
                typeLabel.Text = "Dragon";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Drider
            if(comboBox1.SelectedIndex == 36)
            {
                pageNumLabel.Text = "120)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Dryad
            if(comboBox1.SelectedIndex == 37)
            {
                pageNumLabel.Text = "121)";
                typeLabel.Text = "Fey";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Duergar
            if(comboBox1.SelectedIndex == 38)
            {
                pageNumLabel.Text = "122)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- E --
            // Elementals
            if(comboBox1.SelectedIndex == 39)
            {
                pageNumLabel.Text = "123)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Elves: Drow
            if(comboBox1.SelectedIndex == 40)
            {
                pageNumLabel.Text = "126)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Empyrean
            if(comboBox1.SelectedIndex == 41)
            {
                pageNumLabel.Text = "130)";
                typeLabel.Text = "Celestial";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Ettercap
            if(comboBox1.SelectedIndex == 42)
            {
                pageNumLabel.Text = "131)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Ettin
            if(comboBox1.SelectedIndex == 43)
            {
                pageNumLabel.Text = "132)";
                typeLabel.Text = "Giant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- F --
            // Faerie Dragon
            if(comboBox1.SelectedIndex == 44)
            {
                pageNumLabel.Text = "133)";
                typeLabel.Text = "Dragon";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                bugBearComboBox.Visible = false;
                blightComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Flameskull
            if(comboBox1.SelectedIndex == 45)
            {
                pageNumLabel.Text = "134)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Flumph
            if(comboBox1.SelectedIndex == 46)
            {
                pageNumLabel.Text = "135)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Fomorian
            if(comboBox1.SelectedIndex == 47)
            {
                pageNumLabel.Text = "136)";
                typeLabel.Text = "Giant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Fungi
            if(comboBox1.SelectedIndex == 48)
            {
                pageNumLabel.Text = "137)";
                typeLabel.Text = "Plant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- G --
            // Galeb Duhr
            if(comboBox1.SelectedIndex == 49)
            {
                pageNumLabel.Text = "139)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Gargoyle
            if(comboBox1.SelectedIndex == 50)
            {
                pageNumLabel.Text = "140)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Genies
            if(comboBox1.SelectedIndex == 51)
            {
                pageNumLabel.Text = "141)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Ghost
            if(comboBox1.SelectedIndex == 52)
            {
                pageNumLabel.Text = "147)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Ghouls
            if(comboBox1.SelectedIndex == 53)
            {
                pageNumLabel.Text = "148)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Giants
            if(comboBox1.SelectedIndex == 54)
            {
                pageNumLabel.Text = "149)";
                typeLabel.Text = "Giant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Gibbering Mouther
            if(comboBox1.SelectedIndex == 55)
            {
                pageNumLabel.Text = "157)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Gith 
            if(comboBox1.SelectedIndex == 56)
            {
                pageNumLabel.Text = "158)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Gnolls
            if(comboBox1.SelectedIndex == 57)
            {
                pageNumLabel.Text = "162)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Gnome, Deep
            if(comboBox1.SelectedIndex == 58)
            {
                pageNumLabel.Text = "164)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Goblins
            if(comboBox1.SelectedIndex == 59)
            {
                pageNumLabel.Text = "165)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Golems 
            if(comboBox1.SelectedIndex == 60)
            {
                pageNumLabel.Text = "167)";
                typeLabel.Text = "Construct";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Gorgon
            if(comboBox1.SelectedIndex == 61)
            {
                pageNumLabel.Text = "171)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Grell
            if(comboBox1.SelectedIndex == 62)
            {
                pageNumLabel.Text = "172)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Grick
            if(comboBox1.SelectedIndex == 63)
            {
                pageNumLabel.Text = "173)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Griffon
            if(comboBox1.SelectedIndex == 64)
            {
                pageNumLabel.Text = "174)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Grimlock
            if(comboBox1.SelectedIndex == 65)
            {
                pageNumLabel.Text = "175)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
       //-- H --
            // Hags
            if(comboBox1.SelectedIndex == 66)
            {
                pageNumLabel.Text = "176)";
                typeLabel.Text = "Fey";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Half-Dragon
            if(comboBox1.SelectedIndex == 67)
            {
                pageNumLabel.Text = "180)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Harpy
            if(comboBox1.SelectedIndex == 68)
            {
                pageNumLabel.Text = "181)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Hell Hound
            if(comboBox1.SelectedIndex == 69)
            {
                pageNumLabel.Text = "182)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Helmed Horror 
            if(comboBox1.SelectedIndex == 70)
            {
                pageNumLabel.Text = "183)";
                typeLabel.Text = "Construct";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Hippogrif
            if(comboBox1.SelectedIndex == 71)
            {
                pageNumLabel.Text = "184)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Hobgoblins
            if(comboBox1.SelectedIndex == 72)
            {
                pageNumLabel.Text = "185)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Homunculus
            if(comboBox1.SelectedIndex == 73)
            {
                pageNumLabel.Text = "188)";
                typeLabel.Text = "Construct";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Hook Horror
            if(comboBox1.SelectedIndex == 74)
            {
                pageNumLabel.Text = "189)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
            }
            // Hydra
            if(comboBox1.SelectedIndex == 75)
            {
                pageNumLabel.Text = "190)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
       //-- I --
            // Intellect Devourer
            if(comboBox1.SelectedIndex == 76)
            {
                pageNumLabel.Text = "191)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Invisible Stalker
            if(comboBox1.SelectedIndex == 77)
            {
                pageNumLabel.Text = "192)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- J --
            // Jackalwere
            if(comboBox1.SelectedIndex == 78)
            {
                pageNumLabel.Text = "193)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- K --
            // Kenku
            if(comboBox1.SelectedIndex == 79)
            {
                pageNumLabel.Text = "194)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Kobolds
            if(comboBox1.SelectedIndex == 80)
            {
                pageNumLabel.Text = "195)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Kraken
            if(comboBox1.SelectedIndex == 81)
            {
                pageNumLabel.Text = "196)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Kuo-toa
            if(comboBox1.SelectedIndex == 82)
            {
                pageNumLabel.Text = "198)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
      //-- L --
            // Lamia
            if(comboBox1.SelectedIndex == 83)
            {
                pageNumLabel.Text = "201)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Lich
            if(comboBox1.SelectedIndex == 84)
            {
                pageNumLabel.Text = "202)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Lizardfolk
            if(comboBox1.SelectedIndex == 85)
            {
                pageNumLabel.Text = "204)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Lycanthropes
            if(comboBox1.SelectedIndex == 86)
            {
                pageNumLabel.Text = "206)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- M --
            // Magmin
            if(comboBox1.SelectedIndex == 87)
            {
                pageNumLabel.Text = "212)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Manticore
            if(comboBox1.SelectedIndex == 88)
            {
                pageNumLabel.Text = "213)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Medusa
            if(comboBox1.SelectedIndex == 89)
            {
                pageNumLabel.Text = "214)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Mephits
            if(comboBox1.SelectedIndex == 90)
            {
                pageNumLabel.Text = "215)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Merfolk
            if(comboBox1.SelectedIndex == 91)
            {
                pageNumLabel.Text = "218)";
                angelSubcomboBox.Visible = false;
                typeLabel.Text = "Humanoid";
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Merrow
            if (comboBox1.SelectedIndex == 92)
            {
                pageNumLabel.Text = "219)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Mimic
            if(comboBox1.SelectedIndex == 93)
            {
                pageNumLabel.Text = "220)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Mind Flayer
            if(comboBox1.SelectedIndex == 94)
            {
                pageNumLabel.Text = "221)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Minotaur
            if(comboBox1.SelectedIndex == 95)
            {
                pageNumLabel.Text = "223)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Modrons
            if(comboBox1.SelectedIndex == 96)
            {
                pageNumLabel.Text = "224)";
                typeLabel.Text = "Construct";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Mummies
            if(comboBox1.SelectedIndex == 97)
            {
                pageNumLabel.Text = "227)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Myconids
            if(comboBox1.SelectedIndex == 98)
            {
                pageNumLabel.Text = "230)";
                typeLabel.Text = "Plant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- N --
            // Nagas
            if(comboBox1.SelectedIndex == 99)
            {
                pageNumLabel.Text = "233)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Nightmare
            if(comboBox1.SelectedIndex == 100)
            {
                pageNumLabel.Text = "235)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Nothic
            if(comboBox1.SelectedIndex == 101)
            {
                pageNumLabel.Text = "236)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- O --
            // Ogres
            if(comboBox1.SelectedIndex == 102)
            {
                pageNumLabel.Text = "237)";
                typeLabel.Text = "Giant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            } 
            // Oni
            if(comboBox1.SelectedIndex == 103)
            {
                pageNumLabel.Text = "239)";
                typeLabel.Text = "Giant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Oozes
            if(comboBox1.SelectedIndex == 104)
            {
                pageNumLabel.Text = "240)";
                typeLabel.Text = "Ooze";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Orcs
            if(comboBox1.SelectedIndex == 105)
            {
                pageNumLabel.Text = "244)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Otyugh
            if(comboBox1.SelectedIndex == 106)
            {
                pageNumLabel.Text = "248)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Owlbear
            if(comboBox1.SelectedIndex == 107)
            {
                pageNumLabel.Text = "249)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- P --
            // Pegasus
            if(comboBox1.SelectedIndex == 108)
            {
                pageNumLabel.Text = "250)";
                typeLabel.Text = "Celestial";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Peryton
            if(comboBox1.SelectedIndex == 109)
            {
                pageNumLabel.Text = "251)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Piercer
            if(comboBox1.SelectedIndex == 110)
            {
                pageNumLabel.Text = "252)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Pixie
            if(comboBox1.SelectedIndex == 111)
            {
                pageNumLabel.Text = "253)";
                typeLabel.Text = "Fey";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Pseudodragon
            if(comboBox1.SelectedIndex == 112)
            {
                pageNumLabel.Text = "254)";
                typeLabel.Text = "Dragon";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Purple Worm
            if(comboBox1.SelectedIndex == 113)
            {
                pageNumLabel.Text = "255)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- Q --
            // Quaggoth
            if(comboBox1.SelectedIndex == 114)
            {
                pageNumLabel.Text = "256)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- R --
            // Rakshasha
            if(comboBox1.SelectedIndex == 115)
            {
                pageNumLabel.Text = "257)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Remorhazes
            if(comboBox1.SelectedIndex == 116)
            {
                pageNumLabel.Text = "258)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Revenant
            if(comboBox1.SelectedIndex == 117)
            {
                pageNumLabel.Text = "259)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Roc
            if(comboBox1.SelectedIndex == 118)
            {
                pageNumLabel.Text = "260)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Roper
            if(comboBox1.SelectedIndex == 119)
            {
                pageNumLabel.Text = "261)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Rust Monster
            if(comboBox1.SelectedIndex == 120)
            {
                pageNumLabel.Text = "262)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- S --
            // Sahuagin
            if(comboBox1.SelectedIndex == 121)
            {
                pageNumLabel.Text = "263)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Salamanders
            if(comboBox1.SelectedIndex == 122)
            {
                pageNumLabel.Text = "265)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Satyr
            if(comboBox1.SelectedIndex == 123)
            {
                pageNumLabel.Text = "267)";
                typeLabel.Text = "Fey";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Scarecrow
            if(comboBox1.SelectedIndex == 124)
            {
                pageNumLabel.Text = "268)";
                typeLabel.Text = "Construct";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Shadow
            if(comboBox1.SelectedIndex == 125)
            {
                pageNumLabel.Text = "269)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Shambling Mound
            if(comboBox1.SelectedIndex == 126)
            {
                pageNumLabel.Text = "270)";
                typeLabel.Text = "Plant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Shield Guardian
            if(comboBox1.SelectedIndex == 127)
            {
                pageNumLabel.Text = "271)";
                typeLabel.Text = "Construct";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Skeletons
            if(comboBox1.SelectedIndex == 128)
            {
                pageNumLabel.Text = "272)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Slaadi
            if(comboBox1.SelectedIndex == 129)
            {
                pageNumLabel.Text = "274)";
                typeLabel.Text = "Aberration";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Specter
            if(comboBox1.SelectedIndex == 130)
            {
                pageNumLabel.Text = "279)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Sphinxes
            if(comboBox1.SelectedIndex == 131)
            {
                pageNumLabel.Text = "280)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Sprite
            if(comboBox1.SelectedIndex == 132)
            {
                pageNumLabel.Text = "283)";
                typeLabel.Text = "Fey";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Stirge
            if(comboBox1.SelectedIndex == 133)
            {
                pageNumLabel.Text = "284)";
                typeLabel.Text = "Beast";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Succubus/Incubus
            if(comboBox1.SelectedIndex == 134)
            {
                pageNumLabel.Text = "285)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- T --
            // Tarrasque
            if(comboBox1.SelectedIndex == 135)
            {
                pageNumLabel.Text = "286)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Thri-kreen
            if(comboBox1.SelectedIndex == 136)
            {
                pageNumLabel.Text = "288)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Treant
            if(comboBox1.SelectedIndex == 137)
            {
                pageNumLabel.Text = "289)";
                typeLabel.Text = "Plant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Troglodyte
            if(comboBox1.SelectedIndex == 138)
            {
                pageNumLabel.Text = "290)";
                typeLabel.Text = "Humanoid";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Troll
            if(comboBox1.SelectedIndex == 139)
            {
                pageNumLabel.Text = "291)";
                typeLabel.Text = "Giant";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                bugBearComboBox.Visible = false;
                blightComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- U --
            // Umber Hulk
            if(comboBox1.SelectedIndex == 140)
            {
                pageNumLabel.Text = "292)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Unicorn
            if(comboBox1.SelectedIndex == 141)
            {
                pageNumLabel.Text = "293)";
                typeLabel.Text = "Celestial";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- V --
            // Vampires
            if(comboBox1.SelectedIndex == 142)
            {
                pageNumLabel.Text = "295)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- W --
            // Water Weird
            if(comboBox1.SelectedIndex == 143)
            {
                pageNumLabel.Text = "299)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Wight
            if(comboBox1.SelectedIndex == 144)
            {
                pageNumLabel.Text = "300)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;

            }
            // Will-o'-wisp
            if(comboBox1.SelectedIndex == 145)
            {
                pageNumLabel.Text = "301)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Wraith
            if(comboBox1.SelectedIndex == 146)
            {
                pageNumLabel.Text = "302)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Wyvern
            if(comboBox1.SelectedIndex == 147)
            {
                pageNumLabel.Text = "303)";
                typeLabel.Text = "Dragon";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
       //-- X --
            // Xorn
            if(comboBox1.SelectedIndex == 148)
            {
                pageNumLabel.Text = "304)";
                typeLabel.Text = "Elemental";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
       //-- Y --
            // Yetis
            if(comboBox1.SelectedIndex == 149)
            {
                pageNumLabel.Text = "305)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Yuan-ti
            if(comboBox1.SelectedIndex == 150)
            {
                pageNumLabel.Text = "307)";
                typeLabel.Text = "Monstrosity";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
            // Yugoloths
            if(comboBox1.SelectedIndex == 151)
            {
                pageNumLabel.Text = "311)";
                typeLabel.Text = "Fiend";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }
        //-- Z --
            // Zombies
            if(comboBox1.SelectedIndex == 152)
            {
                pageNumLabel.Text = "315)";
                typeLabel.Text = "Undead";
                angelSubcomboBox.Visible = false;
                animatedObjectcomboBox.Visible = false;
                beHoldercomboBox.Visible = false;
                blightComboBox.Visible = false;
                bugBearComboBox.Visible = false;
                demonComboBox.Visible = false;
                devilComboBox.Visible = false;
                dinoComboBox.Visible = false;
            }

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {//--Challenge Rating:
            // 0
            if(comboBox3.SelectedIndex == 0)
            {
                lvlLabel.Text = "0";
                acLabel.Text = "< 13";
                profLabel.Text = "+2";
                hpLabel.Text = "1-6";
                attackBLabel.Text = "< +3";
                damageLabel.Text = "0-1";
                saveThrowLabel.Text = "< 13";
                expLabel.Text = "0 or 10";
            }
            // 1/8
            if (comboBox3.SelectedIndex == 1)
            {
                lvlLabel.Text = "1/8";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "7-35";
                attackBLabel.Text = "+3";
                damageLabel.Text = "2-3";
                saveThrowLabel.Text = "13";
                expLabel.Text = "25";
            }
            // 1/4
            if (comboBox3.SelectedIndex == 2)
            {
                lvlLabel.Text = "1/4";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "36-49";
                attackBLabel.Text = "+3";
                damageLabel.Text = "4-5";
                saveThrowLabel.Text = "13";
                expLabel.Text = "50";
            }
            // 1/2
            if (comboBox3.SelectedIndex == 3)
            {
                lvlLabel.Text = "1/2";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "50-70";
                attackBLabel.Text = "+3";
                damageLabel.Text = "6-8";
                saveThrowLabel.Text = "13";
                expLabel.Text = "100";
            }
            // 1
            if (comboBox3.SelectedIndex == 4)
            {
                lvlLabel.Text = "1";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "71-85";
                attackBLabel.Text = "+3";
                damageLabel.Text = "9-14";
                saveThrowLabel.Text = "13";
                expLabel.Text = "200";
            }
            // 2
            if (comboBox3.SelectedIndex == 5)
            {
                lvlLabel.Text = "2";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "86-100";
                attackBLabel.Text = "+3";
                damageLabel.Text = "15-20";
                saveThrowLabel.Text = "13";
                expLabel.Text = "450";
            }
            // 3
            if (comboBox3.SelectedIndex == 6)
            {
                lvlLabel.Text = "3";
                acLabel.Text = "13";
                profLabel.Text = "+2";
                hpLabel.Text = "101-115";
                attackBLabel.Text = "+4";
                damageLabel.Text = "21-26";
                saveThrowLabel.Text = "13";
                expLabel.Text = "700";
            }
            // 4
            if (comboBox3.SelectedIndex == 7)
            {
                lvlLabel.Text = "4";
                acLabel.Text = "14";
                profLabel.Text = "+2";
                hpLabel.Text = "116-130";
                attackBLabel.Text = "+5";
                damageLabel.Text = "27-32";
                saveThrowLabel.Text = "14";
                expLabel.Text = "1,100";
            }
            // 5
            if (comboBox3.SelectedIndex == 8)
            {
                lvlLabel.Text = "5";
                acLabel.Text = "15";
                profLabel.Text = "+3";
                hpLabel.Text = "131-145";
                attackBLabel.Text = "+6";
                damageLabel.Text = "33-38";
                saveThrowLabel.Text = "15";
                expLabel.Text = "1,800";
            }
            // 6
            if (comboBox3.SelectedIndex == 9)
            {
                lvlLabel.Text = "6";
                acLabel.Text = "15";
                profLabel.Text = "+3";
                hpLabel.Text = "146-160";
                attackBLabel.Text = "+6";
                damageLabel.Text = "39-44";
                saveThrowLabel.Text = "15";
                expLabel.Text = "2,300";
            }
            // 7
            if (comboBox3.SelectedIndex == 10)
            {
                lvlLabel.Text = "7";
                acLabel.Text = "15";
                profLabel.Text = "+3";
                hpLabel.Text = "161-175";
                attackBLabel.Text = "+6";
                damageLabel.Text = "45-50";
                saveThrowLabel.Text = "15";
                expLabel.Text = "2,900";
            }
            // 8
            if (comboBox3.SelectedIndex == 11)
            {
                lvlLabel.Text = "8";
                acLabel.Text = "16";
                profLabel.Text = "+3";
                hpLabel.Text = "176-190";
                attackBLabel.Text = "+7";
                damageLabel.Text = "51-56";
                saveThrowLabel.Text = "16";
                expLabel.Text = "3,900";
            }
            // 9
            if (comboBox3.SelectedIndex == 12)
            {
                lvlLabel.Text = "9";
                acLabel.Text = "16";
                profLabel.Text = "+4";
                hpLabel.Text = "191-205";
                attackBLabel.Text = "+7";
                damageLabel.Text = "57-62";
                saveThrowLabel.Text = "16";
                expLabel.Text = "5,000";
                
            }
            // 10
            if (comboBox3.SelectedIndex == 13)
            {
                lvlLabel.Text = "10";
                acLabel.Text = "17";
                profLabel.Text = "+4";
                hpLabel.Text = "206-220";
                attackBLabel.Text = "+7";
                damageLabel.Text = "63-68";
                saveThrowLabel.Text = "16";
                expLabel.Text = "5,900";
            }
            // 11
            if (comboBox3.SelectedIndex == 14)
            {
                lvlLabel.Text = "11";
                acLabel.Text = "17";
                profLabel.Text = "+4";
                hpLabel.Text = "221-235";
                attackBLabel.Text = "+8";
                damageLabel.Text = "69-74";
                saveThrowLabel.Text = "17";
                expLabel.Text = "7,200";
            }
            // 12
            if (comboBox3.SelectedIndex == 15)
            {
                lvlLabel.Text = "12";
                acLabel.Text = "17";
                profLabel.Text = "+4";
                hpLabel.Text = "236-250";
                attackBLabel.Text = "+8";
                damageLabel.Text = "75-80";
                saveThrowLabel.Text = "17";
                expLabel.Text = "8,400";
            }
            // 13
            if (comboBox3.SelectedIndex == 16)
            {
                lvlLabel.Text = "13";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "251-265";
                attackBLabel.Text = "+8";
                damageLabel.Text = "81-86";
                saveThrowLabel.Text = "18";
                expLabel.Text = "10,000";
            }
            // 14
            if (comboBox3.SelectedIndex == 17)
            {
                lvlLabel.Text = "14";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "266-280";
                attackBLabel.Text = "+8";
                damageLabel.Text = "87-92";
                saveThrowLabel.Text = "18";
                expLabel.Text = "11,500";
            }
            // 15
            if (comboBox3.SelectedIndex == 18)
            {
                lvlLabel.Text = "15";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "281-295";
                attackBLabel.Text = "+8";
                damageLabel.Text = "93-98";
                saveThrowLabel.Text = "18";
                expLabel.Text = "13,000";
            }
            // 16
            if (comboBox3.SelectedIndex == 19)
            {
                lvlLabel.Text = "16";
                acLabel.Text = "18";
                profLabel.Text = "+5";
                hpLabel.Text = "296-310";
                attackBLabel.Text = "+9";
                damageLabel.Text = "99-104";
                saveThrowLabel.Text = "18";
                expLabel.Text = "15,000";
            }
            // 17
            if (comboBox3.SelectedIndex == 20)
            {
                lvlLabel.Text = "17";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "311-325";
                attackBLabel.Text = "+10";
                damageLabel.Text = "105-110";
                saveThrowLabel.Text = "19";
                expLabel.Text = "18,000";
            }
            // 18 
            if (comboBox3.SelectedIndex == 21)
            {
                lvlLabel.Text = "18";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "326-340";
                attackBLabel.Text = "+10";
                damageLabel.Text = "111-116";
                saveThrowLabel.Text = "19";
                expLabel.Text = "20,000";
            }
            // 19
            if (comboBox3.SelectedIndex == 22)
            {
                lvlLabel.Text = "19";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "341-355";
                attackBLabel.Text = "+10";
                damageLabel.Text = "117-122";
                saveThrowLabel.Text = "19";
                expLabel.Text = "22,000";
            }
            // 20
            if (comboBox3.SelectedIndex == 23)
            {
                lvlLabel.Text = "20";
                acLabel.Text = "19";
                profLabel.Text = "+6";
                hpLabel.Text = "356-400";
                attackBLabel.Text = "+10";
                damageLabel.Text = "123-140";
                saveThrowLabel.Text = "19";
                expLabel.Text = "25,000";
            }
            // 21
            if (comboBox3.SelectedIndex == 24)
            {
                lvlLabel.Text = "21";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "401-445";
                attackBLabel.Text = "+11";
                damageLabel.Text = "141-158";
                saveThrowLabel.Text = "20";
                expLabel.Text = "33,000";
            }
            // 22
            if (comboBox3.SelectedIndex == 25)
            {
                lvlLabel.Text = "22";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "446-490";
                attackBLabel.Text = "+11";
                damageLabel.Text = "159-176";
                saveThrowLabel.Text = "20";
                expLabel.Text = "41,000";
            }
            // 23
            if (comboBox3.SelectedIndex == 26)
            {
                lvlLabel.Text = "23";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "491-535";
                attackBLabel.Text = "+11";
                damageLabel.Text = "177-194";
                saveThrowLabel.Text = "20";
                expLabel.Text = "50,000";
            }
            // 24
            if (comboBox3.SelectedIndex == 27)
            {
                lvlLabel.Text = "24";
                acLabel.Text = "19";
                profLabel.Text = "+7";
                hpLabel.Text = "536-580";
                attackBLabel.Text = "+12";
                damageLabel.Text = "195-212";
                saveThrowLabel.Text = "21";
                expLabel.Text = "62,000";
            }
            // 25
            if (comboBox3.SelectedIndex == 28)
            {
                lvlLabel.Text = "25";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "581-625";
                attackBLabel.Text = "+12";
                damageLabel.Text = "213-230";
                saveThrowLabel.Text = "21";
                expLabel.Text = "75,000";
            }
            // 26
            if (comboBox3.SelectedIndex == 29)
            {
                lvlLabel.Text = "26";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "626-670";
                attackBLabel.Text = "+12";
                damageLabel.Text = "231-248";
                saveThrowLabel.Text = "21";
                expLabel.Text = "90,000";
            }
            // 27
            if (comboBox3.SelectedIndex == 30)
            {
                lvlLabel.Text = "27";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "671-715";
                attackBLabel.Text = "+13";
                damageLabel.Text = "249-266";
                saveThrowLabel.Text = "22";
                expLabel.Text = "105,000";
            }
            // 28
            if (comboBox3.SelectedIndex == 31)
            {
                lvlLabel.Text = "28";
                acLabel.Text = "19";
                profLabel.Text = "+8";
                hpLabel.Text = "716-760";
                attackBLabel.Text = "+13";
                damageLabel.Text = "267-284";
                saveThrowLabel.Text = "22";
                expLabel.Text = "120,000";
            }
            // 29
            if (comboBox3.SelectedIndex == 32)
            {
                lvlLabel.Text = "29";
                acLabel.Text = "19";
                profLabel.Text = "+9";
                hpLabel.Text = "761-805";
                attackBLabel.Text = "+13";
                damageLabel.Text = "285-302";
                saveThrowLabel.Text = "22";
                expLabel.Text = "135,000";
            }
            // 30
            if (comboBox3.SelectedIndex == 33)
            {
                lvlLabel.Text = "30";
                acLabel.Text = "19";
                profLabel.Text = "+9";
                hpLabel.Text = "806-850";
                attackBLabel.Text = "+14";
                damageLabel.Text = "303-320";
                saveThrowLabel.Text = "23";
                expLabel.Text = "155,000";
            }


        }

        private void miscCreateComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
        //-- A --
            // Ape
            if(miscCreateComboBox.SelectedIndex == 0)
            {
                miscCreatureLabel.Text = "317)";
            }
            // Awakened Shrub
            if(miscCreateComboBox.SelectedIndex == 1)
            {
                miscCreatureLabel.Text = "317)";
            }
            // Awakened Tree
            if(miscCreateComboBox.SelectedIndex == 2)
            {
                miscCreatureLabel.Text = "317)";
            }
            // Axe Beak
            if(miscCreateComboBox.SelectedIndex == 3)
            {
                miscCreatureLabel.Text = "317)";
            }
        //-- B --
            // Baboon
            if(miscCreateComboBox.SelectedIndex == 4)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Badger
            if(miscCreateComboBox.SelectedIndex == 5)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Bat
            if(miscCreateComboBox.SelectedIndex == 6)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Black Bear
            if(miscCreateComboBox.SelectedIndex == 7)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Blink Dog
            if(miscCreateComboBox.SelectedIndex == 8)
            {
                miscCreatureLabel.Text = "318)";
            }
            // Blood Hawk
            if(miscCreateComboBox.SelectedIndex == 9)
            {
                miscCreatureLabel.Text = "319)";
            }
            // Boar
            if(miscCreateComboBox.SelectedIndex == 10)
            {
                miscCreatureLabel.Text = "319)";
            }
            // Brown Bear
            if(miscCreateComboBox.SelectedIndex == 11)
            {
                miscCreatureLabel.Text = "319)";
            }
        //-- C --
            // Camel
            if(miscCreateComboBox.SelectedIndex == 12)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Cat
            if(miscCreateComboBox.SelectedIndex == 13)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Constrictor Snake
            if(miscCreateComboBox.SelectedIndex == 14)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Crab
            if(miscCreateComboBox.SelectedIndex == 15)
            {
                miscCreatureLabel.Text = "320)";
            }
            // Crocodile
            if(miscCreateComboBox.SelectedIndex == 16)
            {
                miscCreatureLabel.Text = "320)";
            }
        //-- D --
            // Death Dog
            if(miscCreateComboBox.SelectedIndex == 17)
            {
                miscCreatureLabel.Text = "321)";
            }
            // Deer
            if(miscCreateComboBox.SelectedIndex == 18)
            {
                miscCreatureLabel.Text = "321)";
            }
            // Dire Wolf
            if(miscCreateComboBox.SelectedIndex == 19)
            {
                miscCreatureLabel.Text = "321)";
            }
            // Draft Horse
            if(miscCreateComboBox.SelectedIndex == 20)
            {
                miscCreatureLabel.Text = "321)";
            }
        //-- E --
            // Eagle
            if(miscCreateComboBox.SelectedIndex == 21)
            {
                miscCreatureLabel.Text = "322)";
            }
            // Elephant
            if(miscCreateComboBox.SelectedIndex == 22)
            {
                miscCreatureLabel.Text = "322)";
            }
            // Elk
            if(miscCreateComboBox.SelectedIndex == 23)
            {
                miscCreatureLabel.Text = "322)";
            }
        //-- F --
            // Flying Snake
            if(miscCreateComboBox.SelectedIndex == 24)
            {
                miscCreatureLabel.Text = "322)";
            }
            // Frog
            if(miscCreateComboBox.SelectedIndex == 25)
            {
                miscCreatureLabel.Text = "322)";
            }
       //-- G --
            // Giant Ape
            if(miscCreateComboBox.SelectedIndex == 26)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Badger
            if(miscCreateComboBox.SelectedIndex == 27)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Bat
            if(miscCreateComboBox.SelectedIndex == 28)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Boar
            if(miscCreateComboBox.SelectedIndex == 29)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Centipede
            if(miscCreateComboBox.SelectedIndex == 30)
            {
                miscCreatureLabel.Text = "323)";
            }
            // Giant Constrictor Snake
            if(miscCreateComboBox.SelectedIndex == 31)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Crab
            if(miscCreateComboBox.SelectedIndex == 32)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Crocodile
            if(miscCreateComboBox.SelectedIndex == 33)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Eagle
            if(miscCreateComboBox.SelectedIndex == 36)
            {
                miscCreatureLabel.Text = "324)";
            }
            // Giant Elk
            if(miscCreateComboBox.SelectedIndex == 37)
            {
                miscCreatureLabel.Text = "325)";
            }
            // Giant Fire Beetle
            if(miscCreateComboBox.SelectedIndex == 38)
            {
                miscCreatureLabel.Text = "325)";
            }
            // Giant Frog
            if(miscCreateComboBox.SelectedIndex== 39)
            {
                miscCreatureLabel.Text = "325)";
            }
            // Giant Goat
            if(miscCreateComboBox.SelectedIndex == 40)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Hyena
            if(miscCreateComboBox.SelectedIndex == 41)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Lizard
            if(miscCreateComboBox.SelectedIndex == 42)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Octopus
            if(miscCreateComboBox.SelectedIndex == 43)
            {
                miscCreatureLabel.Text = "326)";
            }
            // Giant Owl
            if(miscCreateComboBox.SelectedIndex == 44)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Poisonous Snake
            if(miscCreateComboBox.SelectedIndex == 45)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Rat
            if(miscCreateComboBox.SelectedIndex == 46)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Scorpion
            if(miscCreateComboBox.SelectedIndex == 47)
            {
                miscCreatureLabel.Text = "327)";
            }
            // Giant Sea Horse
            if(miscCreateComboBox.SelectedIndex == 48)
            {
                miscCreatureLabel.Text = "328)";
            }
            // Giant Shark
            if(miscCreateComboBox.SelectedIndex == 49)
            {
                miscCreatureLabel.Text = "328)";
            }
            // Giant Spider
            if(miscCreateComboBox.SelectedIndex == 50)
            {
                miscCreatureLabel.Text = "328)";
            }
            // Giant Toad
            if(miscCreateComboBox.SelectedIndex == 51)
            {
                miscCreatureLabel.Text = "329)";
            }
            // Giant Vulture
            if(miscCreateComboBox.SelectedIndex == 52)
            {
                miscCreatureLabel.Text = "329)";
            }
            // Giant Wasp
            if(miscCreateComboBox.SelectedIndex == 53)
            {
                miscCreatureLabel.Text = "329)";
            }
            // Giant Weasel
            if(miscCreateComboBox.SelectedIndex == 54)
            {
                miscCreatureLabel.Text = "329)";
            }
            //Giant Wolf Spider
            if(miscCreateComboBox.SelectedIndex == 55)
            {
                miscCreatureLabel.Text = "330)";
            }
            // Goat
            if(miscCreateComboBox.SelectedIndex == 56)
            {
                miscCreatureLabel.Text = "330)";
            }
        //-- H --
            // Hawk
            if(miscCreateComboBox.SelectedIndex == 57)
            {
                miscCreatureLabel.Text = "330)";
            }
            // Hunter Shark
            if(miscCreateComboBox.SelectedIndex == 58)
            {
                miscCreatureLabel.Text = "330)";
            }
            // Hyena
            if(miscCreateComboBox.SelectedIndex == 59)
            {
                miscCreatureLabel.Text = "331)";
            }
        //-- J --
            // Jackal
            if(miscCreateComboBox.SelectedIndex == 60)
            {
                miscCreatureLabel.Text = "331)";
            }
        //-- K --
            // Killer Whale
            if(miscCreateComboBox.SelectedIndex == 61)
            {
                miscCreatureLabel.Text = "331)";
            }
        //-- L --
            // Lion
            if(miscCreateComboBox.SelectedIndex == 62)
            {
                miscCreatureLabel.Text = "331)";
            }
            // Lizard
            if(miscCreateComboBox.SelectedIndex == 63)
            {
                miscCreatureLabel.Text = "332)";
            }
        //-- M --
            // Mammoth
            if(miscCreateComboBox.SelectedIndex == 64)
            {
                miscCreatureLabel.Text = "332)";
            }
            // Mastiff
            if(miscCreateComboBox.SelectedIndex == 65)
            {
                miscCreatureLabel.Text = "332)";
            }
            // Mule
            if(miscCreateComboBox.SelectedIndex == 66)
            {
                miscCreatureLabel.Text = "333)";
            }
        //-- O --
            // Octopus
            if(miscCreateComboBox.SelectedIndex == 67)
            {
                miscCreatureLabel.Text = "333)";
            }
            // Owl
            if(miscCreateComboBox.SelectedIndex == 68)
            {
                miscCreatureLabel.Text = "333)";
            }
        //-- P --
            // Panther
            if(miscCreateComboBox.SelectedIndex == 69)
            {
                miscCreatureLabel.Text = "333)";
            }
            // Phase Spider
            if(miscCreateComboBox.SelectedIndex == 70)
            {
                miscCreatureLabel.Text = "334)";
            }
            // Poisonous Snake
            if(miscCreateComboBox.SelectedIndex == 71)
            {
                miscCreatureLabel.Text = "334)";
            }
            // Polar Bear
            if(miscCreateComboBox.SelectedIndex == 72)
            {
                miscCreatureLabel.Text = "334)";
            }
            // Pony
            if(miscCreateComboBox.SelectedIndex == 73)
            {
                miscCreatureLabel.Text = "335)";
            }
        //-- Q --
            // Quipper
            if(miscCreateComboBox.SelectedIndex == 74)
            {
                miscCreatureLabel.Text = "335)";
            }
        //-- R --
            // Rat
            if(miscCreateComboBox.SelectedIndex == 75)
            {
                miscCreatureLabel.Text = "335)";
            }
            // Raven
            if(miscCreateComboBox.SelectedIndex == 76)
            {
                miscCreatureLabel.Text = "335)";
            }
            // Reef Shark
            if(miscCreateComboBox.SelectedIndex == 77)
            {
                miscCreatureLabel.Text = "336)";
            }
            // Rhinoceros
            if(miscCreateComboBox.SelectedIndex == 78)
            {
                miscCreatureLabel.Text = "336)";
            }
            // Riding Horse
            if(miscCreateComboBox.SelectedIndex == 79)
            {
                miscCreatureLabel.Text = "336)";
            }
        // -- S --
            // Saber-Toother Tiger
            if(miscCreateComboBox.SelectedIndex == 80)
            {
                miscCreatureLabel.Text = "336)";
            }
            // Scorpion
            if(miscCreateComboBox.SelectedIndex == 81)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Sea Horse
            if(miscCreateComboBox.SelectedIndex == 82)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Spider
            if(miscCreateComboBox.SelectedIndex == 83)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Swarm of Bats
            if(miscCreateComboBox.SelectedIndex == 84)
            {
                miscCreatureLabel.Text = "337)";
            }
            // Swarm of Insects
            if(miscCreateComboBox.SelectedIndex == 85)
            {
                miscCreatureLabel.Text = "338)";
            }
            // Swarm of Poisonous Snakes
            if(miscCreateComboBox.SelectedIndex == 86)
            {
                miscCreatureLabel.Text = "338)";
            }
            // Swarm of Quippers
            if(miscCreateComboBox.SelectedIndex == 87)
            {
                miscCreatureLabel.Text = "338)";
            }
            // Swarm of Rats
            if(miscCreateComboBox.SelectedIndex == 88)
            {
                miscCreatureLabel.Text = "339)";
            }
            // Swarm of Ravens
            if(miscCreateComboBox.SelectedIndex == 89)
            {
                miscCreatureLabel.Text = "339)";
            }
        //-- T --
            // Tiger
            if(miscCreateComboBox.SelectedIndex == 90)
            {
                miscCreatureLabel.Text = "339)";
            }
            //-- V --
            // Vulture
            if (miscCreateComboBox.SelectedIndex == 91)
            {
                miscCreatureLabel.Text = "339)";
            }
        //-- W --
            // Warhorse
            if(miscCreateComboBox.SelectedIndex == 92)
                {
                    miscCreatureLabel.Text = "340)";
                }
            // Weasel
            if(miscCreateComboBox.SelectedIndex == 93)
                {
                    miscCreatureLabel.Text = "340)";
                }
            // Winter Wolf
            if(miscCreateComboBox.SelectedIndex == 94)
                {
                    miscCreatureLabel.Text = "340)";
                }
            // Wolf
            if(miscCreateComboBox.SelectedIndex == 95)
                {
                    miscCreatureLabel.Text = "341)";
                }
            // Worg
            if(miscCreateComboBox.SelectedIndex == 96)
                {
                    miscCreatureLabel.Text = "341)";
                }

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void npcComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {// Npc Characters
          // -- A --
            // Acolyte
            if(npcComboBox.SelectedIndex == 0)
            {
                npcLabel.Text = "342)";
            }
            // Archmage
            if(npcComboBox.SelectedIndex == 1)
            {
                npcLabel.Text = "342)";
            }
            // Assassin
            if(npcComboBox.SelectedIndex == 2)
            {
                npcLabel.Text = "343)";
            }
        //-- B --
            // Bandit
            if(npcComboBox.SelectedIndex == 3)
            {
                npcLabel.Text = "343)";
            }
            // Bandit Captain
            if(npcComboBox.SelectedIndex == 4)
            {
                npcLabel.Text = "344)";
            }
            // Berserker
            if(npcComboBox.SelectedIndex == 5)
            {
                npcLabel.Text = "344)";
            }
       //-- C --
            // Commoner
            if(npcComboBox.SelectedIndex == 6)
            {
                npcLabel.Text = "345)";
            }
            // Cultist
            if(npcComboBox.SelectedIndex == 7)
            {
                npcLabel.Text = "345)";
            }
            // Cult Fanatic
            if(npcComboBox.SelectedIndex == 8)
            {
                npcLabel.Text = "345)";
            }
        //-- D --
            // Druid
            if(npcComboBox.SelectedIndex == 9)
            {
                npcLabel.Text = "346)";
            }
       //-- G --
            // Gladiator
            if(npcComboBox.SelectedIndex == 10)
            {
                npcLabel.Text = "346)";
            }
            // Guard
            if(npcComboBox.SelectedIndex == 11)
            {
                npcLabel.Text = "347)";
            }
       //-- K --
            // Knight
            if(npcComboBox.SelectedIndex == 12)
            {
                npcLabel.Text = "347)";
            }
       //-- M --
            // Mage
            if(npcComboBox.SelectedIndex == 13)
            {
                npcLabel.Text = "347)";
            }
       //-- N --
            // Noble
            if(npcComboBox.SelectedIndex == 14)
            {
                npcLabel.Text = "348)";
            }
       //-- P --
            // Priest
            if(npcComboBox.SelectedIndex == 15)
            {
                npcLabel.Text = "348)";
            }
       //-- S --
            // Scout
            if(npcComboBox.SelectedIndex == 16)
            {
                npcLabel.Text = "349)";
            }
            // Spy
            if(npcComboBox.SelectedIndex == 17)
            {
                npcLabel.Text = "349)";
            }
        //-- T --
            // Thug
            if(npcComboBox.SelectedIndex == 18)
            {
                npcLabel.Text = "350)";
            }
            // Tribal Warrior
            if(npcComboBox.SelectedIndex == 19)
            {
                npcLabel.Text = "350)";
            }
        //-- V --
            // Veteran
            if(npcComboBox.SelectedIndex == 20)
            {
                npcLabel.Text = "350)";
            }

        }
    }
}
