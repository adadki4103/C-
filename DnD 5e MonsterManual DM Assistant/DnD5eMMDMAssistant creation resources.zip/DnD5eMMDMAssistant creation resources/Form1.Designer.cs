﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lvlLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.acLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.profLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.hpLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.attackBLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.damageLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.saveThrowLabel = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.expLabel = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pageNumLabel = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.miscCreateComboBox = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.npcComboBox = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.miscCreatureLabel = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.npcLabel = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.typeLabel = new System.Windows.Forms.Label();
            this.angelSubcomboBox = new System.Windows.Forms.ComboBox();
            this.animatedObjectcomboBox = new System.Windows.Forms.ComboBox();
            this.beHoldercomboBox = new System.Windows.Forms.ComboBox();
            this.blightComboBox = new System.Windows.Forms.ComboBox();
            this.bugBearComboBox = new System.Windows.Forms.ComboBox();
            this.demonComboBox = new System.Windows.Forms.ComboBox();
            this.devilComboBox = new System.Windows.Forms.ComboBox();
            this.dinoComboBox = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Black;
            this.comboBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(125, 8);
            this.comboBox1.MaxDropDownItems = 5;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(210, 24);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Window;
            this.label1.Location = new System.Drawing.Point(12, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Monsters :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Window;
            this.label2.Location = new System.Drawing.Point(997, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 31);
            this.label2.TabIndex = 3;
            this.label2.Text = "Level :";
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.Black;
            this.comboBox3.ForeColor = System.Drawing.SystemColors.Window;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(1070, 5);
            this.comboBox3.MaxDropDownItems = 5;
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(70, 24);
            this.comboBox3.TabIndex = 4;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Window;
            this.label3.Location = new System.Drawing.Point(891, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(173, 31);
            this.label3.TabIndex = 5;
            this.label3.Text = "Challenge Rating :";
            // 
            // lvlLabel
            // 
            this.lvlLabel.AutoSize = true;
            this.lvlLabel.BackColor = System.Drawing.Color.Black;
            this.lvlLabel.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlLabel.ForeColor = System.Drawing.Color.White;
            this.lvlLabel.Location = new System.Drawing.Point(1070, 40);
            this.lvlLabel.Name = "lvlLabel";
            this.lvlLabel.Size = new System.Drawing.Size(28, 22);
            this.lvlLabel.TabIndex = 6;
            this.lvlLabel.Text = "   ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Window;
            this.label4.Location = new System.Drawing.Point(930, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 31);
            this.label4.TabIndex = 7;
            this.label4.Text = "Armor Class: ";
            // 
            // acLabel
            // 
            this.acLabel.AutoSize = true;
            this.acLabel.BackColor = System.Drawing.Color.Black;
            this.acLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.acLabel.Location = new System.Drawing.Point(1066, 68);
            this.acLabel.Name = "acLabel";
            this.acLabel.Size = new System.Drawing.Size(24, 20);
            this.acLabel.TabIndex = 8;
            this.acLabel.Text = "   ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Window;
            this.label5.Location = new System.Drawing.Point(880, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(184, 31);
            this.label5.TabIndex = 9;
            this.label5.Text = "Proficiency Bonus: ";
            // 
            // profLabel
            // 
            this.profLabel.AutoSize = true;
            this.profLabel.BackColor = System.Drawing.Color.Black;
            this.profLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.profLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.profLabel.Location = new System.Drawing.Point(1066, 95);
            this.profLabel.Name = "profLabel";
            this.profLabel.Size = new System.Drawing.Size(24, 20);
            this.profLabel.TabIndex = 10;
            this.profLabel.Text = "   ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(952, 121);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 31);
            this.label6.TabIndex = 11;
            this.label6.Text = "Hit Points: ";
            // 
            // hpLabel
            // 
            this.hpLabel.AutoSize = true;
            this.hpLabel.BackColor = System.Drawing.Color.Black;
            this.hpLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hpLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.hpLabel.Location = new System.Drawing.Point(1066, 126);
            this.hpLabel.Name = "hpLabel";
            this.hpLabel.Size = new System.Drawing.Size(24, 20);
            this.hpLabel.TabIndex = 12;
            this.hpLabel.Text = "   ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Window;
            this.label7.Location = new System.Drawing.Point(916, 147);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 31);
            this.label7.TabIndex = 13;
            this.label7.Text = "Attack Bonus: ";
            // 
            // attackBLabel
            // 
            this.attackBLabel.AutoSize = true;
            this.attackBLabel.BackColor = System.Drawing.Color.Black;
            this.attackBLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attackBLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.attackBLabel.Location = new System.Drawing.Point(1066, 152);
            this.attackBLabel.Name = "attackBLabel";
            this.attackBLabel.Size = new System.Drawing.Size(24, 20);
            this.attackBLabel.TabIndex = 14;
            this.attackBLabel.Text = "   ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(871, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(193, 31);
            this.label8.TabIndex = 15;
            this.label8.Text = "Damage per Round: ";
            // 
            // damageLabel
            // 
            this.damageLabel.AutoSize = true;
            this.damageLabel.BackColor = System.Drawing.Color.Black;
            this.damageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.damageLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.damageLabel.Location = new System.Drawing.Point(1066, 178);
            this.damageLabel.Name = "damageLabel";
            this.damageLabel.Size = new System.Drawing.Size(24, 20);
            this.damageLabel.TabIndex = 16;
            this.damageLabel.Text = "   ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.Window;
            this.label9.Location = new System.Drawing.Point(916, 198);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(148, 31);
            this.label9.TabIndex = 17;
            this.label9.Text = "Saving Throw: ";
            // 
            // saveThrowLabel
            // 
            this.saveThrowLabel.AutoSize = true;
            this.saveThrowLabel.BackColor = System.Drawing.Color.Black;
            this.saveThrowLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveThrowLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.saveThrowLabel.Location = new System.Drawing.Point(1066, 203);
            this.saveThrowLabel.Name = "saveThrowLabel";
            this.saveThrowLabel.Size = new System.Drawing.Size(24, 20);
            this.saveThrowLabel.TabIndex = 18;
            this.saveThrowLabel.Text = "   ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.Window;
            this.label10.Location = new System.Drawing.Point(1001, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 31);
            this.label10.TabIndex = 19;
            this.label10.Text = "Exp: ";
            // 
            // expLabel
            // 
            this.expLabel.AutoSize = true;
            this.expLabel.BackColor = System.Drawing.Color.Black;
            this.expLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.expLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.expLabel.Location = new System.Drawing.Point(1070, 228);
            this.expLabel.Name = "expLabel";
            this.expLabel.Size = new System.Drawing.Size(24, 20);
            this.expLabel.TabIndex = 20;
            this.expLabel.Text = "   ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Window;
            this.label11.Location = new System.Drawing.Point(357, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 27);
            this.label11.TabIndex = 21;
            this.label11.Text = "( Pg#";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // pageNumLabel
            // 
            this.pageNumLabel.AutoSize = true;
            this.pageNumLabel.BackColor = System.Drawing.Color.Transparent;
            this.pageNumLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pageNumLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.pageNumLabel.Location = new System.Drawing.Point(405, 5);
            this.pageNumLabel.Name = "pageNumLabel";
            this.pageNumLabel.Size = new System.Drawing.Size(37, 27);
            this.pageNumLabel.TabIndex = 22;
            this.pageNumLabel.Text = "     )";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.Window;
            this.label12.Location = new System.Drawing.Point(12, 64);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(241, 31);
            this.label12.TabIndex = 23;
            this.label12.Text = "Miscellaneous Creatures: ";
            // 
            // miscCreateComboBox
            // 
            this.miscCreateComboBox.BackColor = System.Drawing.Color.Black;
            this.miscCreateComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.miscCreateComboBox.FormattingEnabled = true;
            this.miscCreateComboBox.Location = new System.Drawing.Point(248, 69);
            this.miscCreateComboBox.MaxDropDownItems = 5;
            this.miscCreateComboBox.Name = "miscCreateComboBox";
            this.miscCreateComboBox.Size = new System.Drawing.Size(202, 24);
            this.miscCreateComboBox.TabIndex = 24;
            this.miscCreateComboBox.SelectedIndexChanged += new System.EventHandler(this.miscCreateComboBox_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.Window;
            this.label13.Location = new System.Drawing.Point(12, 95);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(220, 31);
            this.label13.TabIndex = 25;
            this.label13.Text = "NonPlayer Characters: ";
            // 
            // npcComboBox
            // 
            this.npcComboBox.BackColor = System.Drawing.Color.Black;
            this.npcComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.npcComboBox.FormattingEnabled = true;
            this.npcComboBox.Location = new System.Drawing.Point(225, 100);
            this.npcComboBox.MaxDropDownItems = 5;
            this.npcComboBox.Name = "npcComboBox";
            this.npcComboBox.Size = new System.Drawing.Size(121, 24);
            this.npcComboBox.TabIndex = 26;
            this.npcComboBox.SelectedIndexChanged += new System.EventHandler(this.npcComboBox_SelectedIndexChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(341, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 27;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(456, 68);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(22, 20);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 28;
            this.pictureBox2.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.Window;
            this.label14.Location = new System.Drawing.Point(475, 65);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 27);
            this.label14.TabIndex = 29;
            this.label14.Text = "( Pg#";
            // 
            // miscCreatureLabel
            // 
            this.miscCreatureLabel.AutoSize = true;
            this.miscCreatureLabel.BackColor = System.Drawing.Color.Transparent;
            this.miscCreatureLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miscCreatureLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.miscCreatureLabel.Location = new System.Drawing.Point(517, 67);
            this.miscCreatureLabel.Name = "miscCreatureLabel";
            this.miscCreatureLabel.Size = new System.Drawing.Size(29, 27);
            this.miscCreatureLabel.TabIndex = 30;
            this.miscCreatureLabel.Text = "   )";
            this.miscCreatureLabel.Click += new System.EventHandler(this.label15_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.InitialImage")));
            this.pictureBox3.Location = new System.Drawing.Point(352, 101);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(22, 20);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 31;
            this.pictureBox3.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.Window;
            this.label15.Location = new System.Drawing.Point(371, 97);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 27);
            this.label15.TabIndex = 32;
            this.label15.Text = "( Pg#";
            // 
            // npcLabel
            // 
            this.npcLabel.AutoSize = true;
            this.npcLabel.BackColor = System.Drawing.Color.Transparent;
            this.npcLabel.Font = new System.Drawing.Font("Papyrus", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.npcLabel.Location = new System.Drawing.Point(413, 97);
            this.npcLabel.Name = "npcLabel";
            this.npcLabel.Size = new System.Drawing.Size(29, 27);
            this.npcLabel.TabIndex = 33;
            this.npcLabel.Text = "   )";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Papyrus", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.Window;
            this.label16.Location = new System.Drawing.Point(12, 192);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(73, 31);
            this.label16.TabIndex = 34;
            this.label16.Text = "Type: ";
            // 
            // typeLabel
            // 
            this.typeLabel.AutoSize = true;
            this.typeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeLabel.ForeColor = System.Drawing.SystemColors.Window;
            this.typeLabel.Location = new System.Drawing.Point(79, 198);
            this.typeLabel.Name = "typeLabel";
            this.typeLabel.Size = new System.Drawing.Size(24, 20);
            this.typeLabel.TabIndex = 35;
            this.typeLabel.Text = "   ";
            // 
            // angelSubcomboBox
            // 
            this.angelSubcomboBox.BackColor = System.Drawing.Color.Black;
            this.angelSubcomboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.angelSubcomboBox.FormattingEnabled = true;
            this.angelSubcomboBox.Location = new System.Drawing.Point(125, 37);
            this.angelSubcomboBox.Name = "angelSubcomboBox";
            this.angelSubcomboBox.Size = new System.Drawing.Size(121, 24);
            this.angelSubcomboBox.TabIndex = 36;
            this.angelSubcomboBox.Visible = false;
            // 
            // animatedObjectcomboBox
            // 
            this.animatedObjectcomboBox.BackColor = System.Drawing.Color.Black;
            this.animatedObjectcomboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.animatedObjectcomboBox.FormattingEnabled = true;
            this.animatedObjectcomboBox.Location = new System.Drawing.Point(125, 37);
            this.animatedObjectcomboBox.Name = "animatedObjectcomboBox";
            this.animatedObjectcomboBox.Size = new System.Drawing.Size(147, 24);
            this.animatedObjectcomboBox.TabIndex = 37;
            this.animatedObjectcomboBox.Visible = false;
            // 
            // beHoldercomboBox
            // 
            this.beHoldercomboBox.BackColor = System.Drawing.Color.Black;
            this.beHoldercomboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.beHoldercomboBox.FormattingEnabled = true;
            this.beHoldercomboBox.Location = new System.Drawing.Point(125, 37);
            this.beHoldercomboBox.Name = "beHoldercomboBox";
            this.beHoldercomboBox.Size = new System.Drawing.Size(147, 24);
            this.beHoldercomboBox.TabIndex = 38;
            this.beHoldercomboBox.Visible = false;
            // 
            // blightComboBox
            // 
            this.blightComboBox.BackColor = System.Drawing.Color.Black;
            this.blightComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.blightComboBox.FormattingEnabled = true;
            this.blightComboBox.Location = new System.Drawing.Point(125, 37);
            this.blightComboBox.Name = "blightComboBox";
            this.blightComboBox.Size = new System.Drawing.Size(147, 24);
            this.blightComboBox.TabIndex = 39;
            this.blightComboBox.Visible = false;
            // 
            // bugBearComboBox
            // 
            this.bugBearComboBox.BackColor = System.Drawing.Color.Black;
            this.bugBearComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.bugBearComboBox.FormattingEnabled = true;
            this.bugBearComboBox.Location = new System.Drawing.Point(125, 37);
            this.bugBearComboBox.Name = "bugBearComboBox";
            this.bugBearComboBox.Size = new System.Drawing.Size(147, 24);
            this.bugBearComboBox.TabIndex = 40;
            this.bugBearComboBox.Visible = false;
            // 
            // demonComboBox
            // 
            this.demonComboBox.BackColor = System.Drawing.Color.Black;
            this.demonComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.demonComboBox.FormattingEnabled = true;
            this.demonComboBox.Location = new System.Drawing.Point(125, 37);
            this.demonComboBox.Name = "demonComboBox";
            this.demonComboBox.Size = new System.Drawing.Size(147, 24);
            this.demonComboBox.TabIndex = 41;
            this.demonComboBox.Visible = false;
            // 
            // devilComboBox
            // 
            this.devilComboBox.BackColor = System.Drawing.Color.Black;
            this.devilComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.devilComboBox.FormattingEnabled = true;
            this.devilComboBox.Location = new System.Drawing.Point(125, 37);
            this.devilComboBox.Name = "devilComboBox";
            this.devilComboBox.Size = new System.Drawing.Size(147, 24);
            this.devilComboBox.TabIndex = 42;
            this.devilComboBox.Visible = false;
            // 
            // dinoComboBox
            // 
            this.dinoComboBox.BackColor = System.Drawing.Color.Black;
            this.dinoComboBox.ForeColor = System.Drawing.SystemColors.Window;
            this.dinoComboBox.FormattingEnabled = true;
            this.dinoComboBox.Location = new System.Drawing.Point(125, 37);
            this.dinoComboBox.Name = "dinoComboBox";
            this.dinoComboBox.Size = new System.Drawing.Size(147, 24);
            this.dinoComboBox.TabIndex = 43;
            this.dinoComboBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(1152, 502);
            this.Controls.Add(this.dinoComboBox);
            this.Controls.Add(this.devilComboBox);
            this.Controls.Add(this.demonComboBox);
            this.Controls.Add(this.bugBearComboBox);
            this.Controls.Add(this.blightComboBox);
            this.Controls.Add(this.beHoldercomboBox);
            this.Controls.Add(this.animatedObjectcomboBox);
            this.Controls.Add(this.angelSubcomboBox);
            this.Controls.Add(this.typeLabel);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.npcLabel);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.miscCreatureLabel);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.npcComboBox);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.miscCreateComboBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.pageNumLabel);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.expLabel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.saveThrowLabel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.damageLabel);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.attackBLabel);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.hpLabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.profLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.acLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lvlLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "D&D 5e Monster Maker";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lvlLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label acLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label profLabel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label hpLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label attackBLabel;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label damageLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label saveThrowLabel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label expLabel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label pageNumLabel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox miscCreateComboBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox npcComboBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label miscCreatureLabel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label npcLabel;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label typeLabel;
        private System.Windows.Forms.ComboBox angelSubcomboBox;
        private System.Windows.Forms.ComboBox animatedObjectcomboBox;
        private System.Windows.Forms.ComboBox beHoldercomboBox;
        private System.Windows.Forms.ComboBox blightComboBox;
        private System.Windows.Forms.ComboBox bugBearComboBox;
        private System.Windows.Forms.ComboBox demonComboBox;
        private System.Windows.Forms.ComboBox devilComboBox;
        private System.Windows.Forms.ComboBox dinoComboBox;
    }
}

